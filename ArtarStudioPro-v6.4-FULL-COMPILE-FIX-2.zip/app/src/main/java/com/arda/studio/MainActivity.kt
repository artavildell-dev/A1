package com.arda.studio

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.*
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.googlecode.tesseract.android.TessBaseAPI
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.*
import kotlin.math.*

class MainActivity : AppCompatActivity() {
    private lateinit var editor: EditorView
    private lateinit var status: TextView
    private lateinit var rootScroll: ScrollView
    private var darkMode = false
    private var currentPreview: Bitmap? = null
    private var pendingAction: (() -> Unit)? = null
    private val openImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let { loadUri(it) } }
    private val openBatch = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { list -> if (list.isNotEmpty()) batch(list) }

    private val bg get() = if (darkMode) Color.rgb(10,13,20) else Color.rgb(246,248,252)
    private val card get() = if (darkMode) Color.rgb(20,24,34) else Color.WHITE
    private val text get() = if (darkMode) Color.WHITE else Color.rgb(23,31,53)
    private val muted get() = if (darkMode) Color.rgb(164,173,194) else Color.rgb(103,113,137)
    private val accent get() = Color.rgb(76,92,245)
    private val accent2 get() = Color.rgb(130,65,236)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkMode = getPreferences(MODE_PRIVATE).getBoolean("dark_mode", false)
        editor = EditorView(this)
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun rounded(fill: Int, stroke: Int = Color.TRANSPARENT, radius: Float = 20f): GradientDrawable =
        GradientDrawable().apply { setColor(fill); cornerRadius = dp(radius.toInt()).toFloat(); if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke) }

    private fun gradientButtonBackground(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(accent, accent2)
    ).apply { cornerRadius = dp(18).toFloat() }

    private fun textView(value: String, size: Float, color: Int = text, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    private fun imageThumb(seed: Int, size: Int = 62): Bitmap {
        val b = Bitmap.createBitmap(dp(size), dp(size), Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val colors = arrayOf(
            intArrayOf(Color.rgb(28,74,180), Color.rgb(117,55,230)),
            intArrayOf(Color.rgb(17,142,166), Color.rgb(42,87,205)),
            intArrayOf(Color.rgb(238,116,77), Color.rgb(121,52,194)),
            intArrayOf(Color.rgb(20,160,128), Color.rgb(42,70,176)),
            intArrayOf(Color.rgb(244,170,49), Color.rgb(232,76,126))
        )[seed % 5]
        p.shader = LinearGradient(0f,0f,b.width.toFloat(),b.height.toFloat(),colors[0],colors[1],Shader.TileMode.CLAMP)
        c.drawRect(0f,0f,b.width.toFloat(),b.height.toFloat(),p)
        p.shader = null
        p.color = Color.argb(55,255,255,255)
        c.drawCircle(b.width*.28f,b.height*.28f,b.width*.22f,p)
        p.color = Color.argb(45,255,255,255)
        c.drawCircle(b.width*.72f,b.height*.70f,b.width*.32f,p)
        p.color = Color.argb(95,255,255,255)
        c.drawRoundRect(b.width*.12f,b.height*.68f,b.width*.88f,b.height*.78f,b.width*.08f,b.width*.08f,p)
        return b
    }

    private fun resId(name: String): Int = resources.getIdentifier(name, "drawable", packageName)

    private fun previewBitmap(name: String): Bitmap? = try {
        BitmapFactory.decodeResource(resources, resId(name))
    } catch (_: Exception) { null }

    private fun requireImage(action: () -> Unit) {
        if (editor.baseBitmap == null) {
            pendingAction = action
            Toast.makeText(this, "اول یک تصویر باز کنید", Toast.LENGTH_SHORT).show()
            openImage.launch("image/*")
        } else {
            action()
        }
    }

    private fun trustStatus(title: String): String = when (title) {
        "OCR", "OCR فارسی", "OCR لاتین", "تشخیص چهره", "برچسب اشیا", "بارکد و QR",
        "ابزارهای AI", "AI بهبود هوشمند", "AI تحلیل تصویر" -> "MODEL-DEPENDENT"
        "حذف پس‌زمینه سریع" -> "IMPLEMENTED"
        "Generative Fill", "Super Resolution", "Deblur", "Colorization", "حذف پس‌زمینه مدل‌محور" -> "PLANNED"
        else -> "IMPLEMENTED"
    }

    private fun trustColor(status: String): Int = when (status) {
        "MODEL-DEPENDENT" -> Color.rgb(224, 139, 25)
        "PLANNED" -> Color.rgb(125, 134, 154)
        else -> Color.rgb(36, 157, 105)
    }

    private fun trustBadge(title: String): TextView = TextView(this).apply {
        val state = trustStatus(title)
        text = state
        textSize = 7.5f
        setTextColor(trustColor(state))
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(Color.TRANSPARENT, trustColor(state), 8f)
        setPadding(dp(4), dp(1), dp(4), dp(1))
        contentDescription = "وضعیت اعتماد: $state"
    }

    private fun toolCard(
        title: String,
        thumb: String,
        action: () -> Unit,
        compact: Boolean = false,
        icon: String = "✦"
    ): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(if (compact) 5 else 7), dp(6), dp(if (compact) 5 else 7), dp(6))
            background = rounded(card, if (darkMode) Color.rgb(43, 50, 68) else Color.rgb(224, 232, 247), 18f)
            elevation = dp(1).toFloat()
            isClickable = true
            isFocusable = true
            setOnClickListener {
                when (title) {
                    "افکت‌ها", "ابزارهای AI" -> action()
                    else -> requireImage { action(); showEditor() }
                }
            }
        }
        val image = ImageView(this).apply {
            val bmp = previewBitmap(thumb)
            if (bmp != null) setImageBitmap(bmp) else setImageResource(resId("sample_landscape"))
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = title
            clipToOutline = true
            background = rounded(Color.TRANSPARENT, Color.TRANSPARENT, 14f)
        }
        val imageFrame = FrameLayout(this).apply {
            background = rounded(Color.TRANSPARENT, Color.TRANSPARENT, 14f)
            clipChildren = false
        }
        imageFrame.addView(image, FrameLayout.LayoutParams(-1, dp(if (compact) 72 else 86)))
        val iconBadge = FunctionIconView(this, title).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(accent, accent2)).apply {
                shape = GradientDrawable.OVAL
            }
            elevation = dp(3).toFloat()
            contentDescription = "$title — آیکون عملکرد"
        }
        val iconLp = FrameLayout.LayoutParams(dp(if (compact) 34 else 38), dp(if (compact) 34 else 38), Gravity.BOTTOM or Gravity.START).apply {
            setMargins(dp(4), 0, 0, dp(4))
        }
        imageFrame.addView(iconBadge, iconLp)
        box.addView(imageFrame, LinearLayout.LayoutParams(-1, dp(if (compact) 72 else 86)))
        val label = textView(title, if (compact) 10.5f else 11.5f, text, true).apply {
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val meta = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        meta.addView(label, LinearLayout.LayoutParams(-1, dp(23)))
        meta.addView(trustBadge(title), LinearLayout.LayoutParams(-2, dp(16)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        box.addView(meta, LinearLayout.LayoutParams(-1, dp(42)))
        return box
    }

    private fun iconActionCard(title: String, icon: String, action: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(7), dp(6), dp(6))
            background = rounded(card, if (darkMode) Color.rgb(43,50,68) else Color.rgb(226,233,247), 18f)
            setOnClickListener { action() }
        }
        val iconBox = TextView(this).apply {
            text = icon
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(accent)
            background = rounded(if (darkMode) Color.rgb(28,34,48) else Color.rgb(239,244,255), Color.TRANSPARENT, 15f)
        }
        box.addView(iconBox, LinearLayout.LayoutParams(dp(52), dp(52)))
        box.addView(textView(title, 10.5f, text, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, dp(26)))
        box.addView(trustBadge(title), LinearLayout.LayoutParams(-2, dp(16)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        return box
    }

    private inner class FunctionIconView(context: Context, private val kind: String) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeWidth = dp(2).toFloat(); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val w = width.toFloat(); val h = height.toFloat(); val cx = w/2f; val cy = h/2f
            val r = min(w,h)*.27f
            when (kind) {
                "روشنایی" -> { c.drawCircle(cx,cy,r,p); for(i in 0 until 8){ val a=Math.toRadians(i*45.0); c.drawLine(cx+cos(a).toFloat()*r*1.45f,cy+sin(a).toFloat()*r*1.45f,cx+cos(a).toFloat()*r*1.9f,cy+sin(a).toFloat()*r*1.9f,p) } }
                "کنتراست" -> { c.drawCircle(cx,cy,r*1.25f,p); c.drawArc(cx-r*1.25f,cy-r*1.25f,cx+r*1.25f,cy+r*1.25f,-90f,180f,false,fill) }
                "اشباع رنگ" -> { c.drawCircle(cx,cy,r*1.25f,p); c.drawCircle(cx,cy,r*.35f,fill) }
                "سیاه‌وسفید" -> { c.drawRect(cx-r*1.2f,cy-r*1.2f,cx,cy+r*1.2f,p); c.drawRect(cx,cy-r*1.2f,cx+r*1.2f,cy+r*1.2f,fill) }
                "برش و چرخش" -> { c.drawLine(cx-r,cy-r,cx-r/2,cy-r,p); c.drawLine(cx-r,cy-r,cx-r,cy-r/2,p); c.drawLine(cx+r,cy+r,cx+r/2,cy+r,p); c.drawLine(cx+r,cy+r,cx+r,cy+r/2,p); c.drawArc(cx-r*1.5f,cy-r*1.5f,cx+r*1.5f,cy+r*1.5f,210f,190f,false,p) }
                "تنظیمات رنگ" -> { c.drawCircle(cx,cy,r*1.2f,p); c.drawCircle(cx-r*.55f,cy-r*.45f,r*.22f,fill); c.drawCircle(cx+r*.5f,cy+r*.45f,r*.22f,fill) }
                "متن" -> { p.textSize=min(w,h)*.55f;p.style=Paint.Style.FILL;c.drawText("T",cx-p.measureText("T")/2,cy+p.textSize*.35f,p);p.style=Paint.Style.STROKE }
                "براش" -> { c.drawLine(cx-r,cy+r*.55f,cx+r*.65f,cy-r*.7f,p); c.drawCircle(cx+r*.75f,cy-r*.8f,r*.22f,p) }
                "ماسک" -> { val path=Path().apply{moveTo(cx,cy-r*1.5f);lineTo(cx+r*1.15f,cy-r*.6f);lineTo(cx+r*.8f,cy+r*1.25f);lineTo(cx-r*.8f,cy+r*1.25f);lineTo(cx-r*1.15f,cy-r*.6f);close()};c.drawPath(path,p) }
                "لایه‌ها" -> { for(i in 0..2){ val yy=cy-r*.8f+i*r*.7f;c.drawRoundRect(cx-r,yy-r*.25f,cx+r,yy+r*.25f,r*.12f,r*.12f,p) } }
                "حذف پس‌زمینه" -> { c.drawLine(cx-r,cy-r,cx+r,cy+r,p);c.drawLine(cx+r,cy-r,cx-r,cy+r,p);c.drawCircle(cx,cy,r*1.15f,p) }
                "OCR", "OCR فارسی", "OCR لاتین" -> { c.drawRect(cx-r*1.2f,cy-r, cx+r*1.2f,cy+r,p); p.textSize=r*.9f;p.style=Paint.Style.FILL;c.drawText("A",cx-r*.75f,cy+r*.35f,p);p.style=Paint.Style.STROKE;c.drawLine(cx,cy-r*.55f,cx+r*.7f,cy-r*.55f,p);c.drawLine(cx,cy-r*.1f,cx+r*.7f,cy-r*.1f,p) }
                "قالب‌ها" -> { for(i in 0..1)for(j in 0..1)c.drawRoundRect(cx-r*1.2f+j*r*1.25f,cy-r*1.2f+i*r*1.25f,cx-r*.2f+j*r*1.25f,cy-r*.2f+i*r*1.25f,r*.12f,r*.12f,p) }
                "افکت‌ها", "گلیچ", "کالیدوسکوپ", "نوردهی", "پیکسلی", "طرح لبه", "حرارتی", "وینیت", "دانه فیلم", "شبح", "نگاتیو", "سپیا" -> { c.drawCircle(cx,cy,r*.55f,fill); for(i in 0 until 8){val a=Math.toRadians(i*45.0);c.drawLine(cx+cos(a).toFloat()*r,cy+sin(a).toFloat()*r,cx+cos(a).toFloat()*r*1.55f,cy+sin(a).toFloat()*r*1.55f,p)} }
                "بارکد و QR" -> { c.drawRect(cx-r*1.2f,cy-r*1.2f,cx+r*1.2f,cy+r*1.2f,p); for(i in 0 until 7){ val xx=cx-r+i*r*.34f; c.drawLine(xx,cy-r,xx,cy+r,p) } }
                "ابزارهای AI" -> { c.drawCircle(cx,cy,r,p);p.textSize=r*.8f;p.style=Paint.Style.FILL;c.drawText("AI",cx-p.measureText("AI")/2,cy+r*.28f,p);p.style=Paint.Style.STROKE; for(i in 0 until 4){c.drawLine(cx-r*1.5f,cy-r*.8f+i*r*.55f,cx-r*1.15f,cy-r*.8f+i*r*.55f,p);c.drawLine(cx+r*1.15f,cy-r*.8f+i*r*.55f,cx+r*1.5f,cy-r*.8f+i*r*.55f,p)} }
                "AI بهبود هوشمند" -> { c.drawCircle(cx,cy,r*1.2f,p); c.drawLine(cx,cy-r*1.55f,cx,cy-r*.95f,p); c.drawLine(cx,cy+r*.95f,cx,cy+r*1.55f,p); c.drawLine(cx-r*1.55f,cy,cx-r*.95f,cy,p); c.drawLine(cx+r*.95f,cy,cx+r*1.55f,cy,p); p.style=Paint.Style.FILL; c.drawCircle(cx,cy,r*.42f,fill); p.style=Paint.Style.STROKE }
                "AI تحلیل تصویر" -> { c.drawRect(cx-r*1.25f,cy-r*1.05f,cx+r*1.25f,cy+r*1.05f,p); c.drawCircle(cx-r*.45f,cy-r*.25f,r*.16f,fill); c.drawCircle(cx+r*.45f,cy-r*.25f,r*.16f,fill); c.drawArc(cx-r*.55f,cy-r*.05f,cx+r*.55f,cy+r*.65f,15f,150f,false,p); c.drawLine(cx-r*.9f,cy+r*.85f,cx+r*.9f,cy+r*.85f,p) }
                "تشخیص چهره" -> { c.drawCircle(cx,cy,r*1.25f,p);c.drawCircle(cx-r*.45f,cy-r*.2f,r*.1f,fill);c.drawCircle(cx+r*.45f,cy-r*.2f,r*.1f,fill);c.drawArc(cx-r*.55f,cy-r*.05f,cx+r*.55f,cy+r*.65f,15f,150f,false,p) }
                "برچسب اشیا" -> { c.drawRect(cx-r,cy-r,cx+r,cy+r,p); c.drawCircle(cx,cy,r*.22f,fill) }
                "فرمان آفلاین" -> { c.drawCircle(cx,cy,r*1.2f,p); c.drawLine(cx-r*.65f,cy,cx+r*.6f,cy,p);c.drawLine(cx+r*.6f,cy,cx+r*.2f,cy-r*.35f,p);c.drawLine(cx+r*.6f,cy,cx+r*.2f,cy+r*.35f,p) }
                else -> { c.drawCircle(cx,cy,r,p);c.drawLine(cx-r,cy,cx+r,cy,p);c.drawLine(cx,cy-r,cx,cy+r,p) }
            }
        }
    }

    private fun toolIcon(title: String): String = when (title) {
        "روشنایی" -> "☀"
        "کنتراست" -> "◐"
        "اشباع رنگ" -> "◉"
        "سیاه‌وسفید" -> "◑"
        "سینمایی" -> "▣"
        "گرم" -> "♨"
        "سرد" -> "❄"
        "گلیچ" -> "⚡"
        "کالیدوسکوپ" -> "✥"
        "نوردهی" -> "☼"
        "پیکسلی" -> "▦"
        "طرح لبه" -> "✎"
        "حرارتی" -> "♨"
        "وینیت" -> "◉"
        "دانه فیلم" -> "•"
        "شبح" -> "♧"
        "نگاتیو" -> "◒"
        "سپیا" -> "◍"
        "برش و چرخش" -> "⌗"
        "تنظیمات رنگ" -> "◉"
        "متن" -> "T"
        "براش" -> "✎"
        "ماسک" -> "⬟"
        "لایه‌ها" -> "▤"
        "حذف پس‌زمینه" -> "✂"
        "OCR" -> "Aa"
        "ویرایشگر" -> "✎"
        "قالب‌ها" -> "▧"
        "افکت‌ها" -> "✦"
        "ابزارهای AI" -> "AI"
        "AI بهبود هوشمند" -> "✦"
        "AI تحلیل تصویر" -> "⌕"
        "OCR فارسی" -> "فا"
        "OCR لاتین" -> "EN"
        "تشخیص چهره" -> "◉"
        "برچسب اشیا" -> "⌘"
        "فرمان آفلاین" -> "⌕"
        "بارکد و QR" -> "▥"
        "حذف پس‌زمینه سریع" -> "✂"
        else -> "✦"
    }

    private fun toolGrid(items: List<Triple<String, String, () -> Unit>>, compact: Boolean = false): GridLayout {
        return GridLayout(this).apply {
            columnCount = 3
            useDefaultMargins = false
            items.forEach { item ->
                val v = toolCard(item.first, item.second, item.third, compact, toolIcon(item.first))
                val lp = GridLayout.LayoutParams().apply {
                    width = 0
                    height = dp(if (compact) 132 else 150)
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                }
                addView(v, lp)
            }
        }
    }

    private fun showToolPanel(title: String, subtitle: String, items: List<Triple<String, String, () -> Unit>>) {
        val host = currentHost ?: return
        host.removeAllViews()
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(90))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val back = TextView(this).apply {
            text = "‹"
            textSize = 31f
            gravity = Gravity.CENTER
            setTextColor(this@MainActivity.text)
            setOnClickListener { showHome() }
        }
        bar.addView(back, LinearLayout.LayoutParams(dp(46), dp(52)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        titles.addView(textView(title, 18f, text, true), LinearLayout.LayoutParams(0, dp(27), 1f))
        titles.addView(textView(subtitle, 9.5f, muted, false), LinearLayout.LayoutParams(0, dp(20), 1f))
        bar.addView(titles, LinearLayout.LayoutParams(0, dp(52), 1f))
        bar.addView(TextView(this).apply { text = "↶"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(accent) }, LinearLayout.LayoutParams(dp(42), dp(52)))
        page.addView(bar)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(16)) }
        content.addView(toolGrid(items), LinearLayout.LayoutParams(-1, -2))
        val apply = TextView(this).apply {
            text = "‹  بازگشت به ویرایشگر"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = gradientButtonBackground()
            setOnClickListener {
                showEditor()
            }
        }
        content.addView(apply, LinearLayout.LayoutParams(-1, dp(50)).apply { setMargins(dp(5), dp(14), dp(5), 0) })
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        host.addView(page)
    }

    private var currentHost: FrameLayout? = null

    private fun showHome() {
        val host = currentHost ?: return
        host.removeAllViews()
        val scroll = ScrollView(this).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(18))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(card, Color.TRANSPARENT, 24f)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val image = ImageView(this).apply {
            setImageBitmap(currentPreview ?: previewBitmap("sample_landscape"))
            scaleType = ImageView.ScaleType.CENTER_CROP
            isClickable = true
            setOnClickListener { openImage.launch("image/*") }
        }
        hero.addView(image, LinearLayout.LayoutParams(-1, dp(172)))
        val open = TextView(this).apply {
            text = "▣  باز کردن تصویر"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = gradientButtonBackground()
            setOnClickListener { openImage.launch("image/*") }
        }
        hero.addView(open, LinearLayout.LayoutParams(-1, dp(48)).apply { setMargins(dp(8), dp(10), dp(8), 0) })
        content.addView(hero)

        content.addView(textView("دسترسی سریع", 16f, text, true).apply { gravity = Gravity.RIGHT }, LinearLayout.LayoutParams(-1, dp(38)).apply { setMargins(dp(2), dp(10), dp(2), 0) })
        val quick = listOf(
            Triple("ویرایشگر", "thumb_brightness") { requireImage { showEditor() } },
            Triple("قالب‌ها", "thumb_cinematic") { templatesDialog() },
            Triple("افکت‌ها", "thumb_glitch") { showEffects() },
            Triple("ابزارهای AI", "thumb_sketch") { showAiTools() }
        )
        content.addView(toolGrid(quick, compact = true), LinearLayout.LayoutParams(-1, dp(246)))

        content.addView(textView("ابزارهای اصلی", 16f, text, true).apply { gravity = Gravity.RIGHT }, LinearLayout.LayoutParams(-1, dp(38)).apply { setMargins(dp(2), dp(8), dp(2), 0) })
        val main = listOf(
            Triple("برش و چرخش", "thumb_brightness") { requireImage { editor.squareCrop(); status.text="برش مربع اعمال شد ✓"; showEditor() } },
            Triple("تنظیمات رنگ", "thumb_saturation") { showAdjustments() },
            Triple("متن", "thumb_warm") { requireImage { addText() } },
            Triple("براش", "thumb_sketch") { requireImage { editor.mode=EditorView.Mode.BRUSH; showEditor(); status.text="براش فعال است — روی تصویر بکشید" } },
            Triple("ماسک", "thumb_vignette") { requireImage { editor.mode=EditorView.Mode.MASK; showEditor(); status.text="ماسک فعال است — روی تصویر بکشید" } },
            Triple("لایه‌ها", "thumb_pixel") { showLayers() },
            Triple("حذف پس‌زمینه", "thumb_thermal") { requireImage { editor.quickBackgroundCut(); status.text="حذف پس‌زمینه سریع اعمال شد ✓"; showEditor() } },
            Triple("OCR", "thumb_bw") { requireImage { ocrOffline() } }
        )
        content.addView(toolGrid(main), LinearLayout.LayoutParams(-1, dp(290)))
        content.addView(toolGrid(listOf(
            Triple("برش شبکه‌های اجتماعی", "thumb_cinematic") { requireImage { showSocialCrops() } },
            Triple("پردازش دسته‌ای", "thumb_pixel") { openBatch.launch("image/*") },
            Triple("قالب‌ها", "thumb_warm") { requireImage { templatesDialog() } }
        ), compact = true), LinearLayout.LayoutParams(-1, dp(126)))
        content.addView(textView("● ${if (editor.baseBitmap == null) "آماده — یک تصویر باز کنید" else "تصویر آماده و قابل ویرایش"}", 10.5f, muted, false).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, dp(30)))
        scroll.addView(content)
        host.addView(scroll)
    }

    private fun showEditor() {
        val host = currentHost ?: return
        if (editor.baseBitmap == null) { showHome(); return }
        host.removeAllViews()
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(10))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val back = TextView(this).apply {
            text = "‹"; textSize = 30f; gravity = Gravity.CENTER; setTextColor(this@MainActivity.text)
            setOnClickListener { showHome() }
        }
        bar.addView(back, LinearLayout.LayoutParams(dp(46), dp(48)))
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        titleBox.addView(textView("ویرایش تصویر", 17f, text, true), LinearLayout.LayoutParams(-1, dp(25)))
        titleBox.addView(textView("ویرایش غیرمخرب با Undo / Redo", 9.5f, muted), LinearLayout.LayoutParams(-1, dp(18)))
        bar.addView(titleBox, LinearLayout.LayoutParams(0, dp(48), 1f))
        bar.addView(TextView(this).apply { text="↶"; textSize=22f; gravity=Gravity.CENTER; setTextColor(accent); setOnClickListener { editor.undo(); editor.invalidate(); status.text="Undo ✓" } }, LinearLayout.LayoutParams(dp(42),dp(48)))
        bar.addView(TextView(this).apply { text="↷"; textSize=22f; gravity=Gravity.CENTER; setTextColor(accent); setOnClickListener { editor.redo(); editor.invalidate(); status.text="Redo ✓" } }, LinearLayout.LayoutParams(dp(42),dp(48)))
        page.addView(bar)

        val frame = FrameLayout(this).apply { background = rounded(if(darkMode) Color.rgb(12,16,24) else Color.rgb(234,239,248), Color.TRANSPARENT, 22f); setPadding(dp(6),dp(6),dp(6),dp(6)) }
        frame.addView(editor, FrameLayout.LayoutParams(-1,-1))
        page.addView(frame, LinearLayout.LayoutParams(-1,0,1f))

        val actions = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setPadding(0,dp(8),0,0); layoutDirection=View.LAYOUT_DIRECTION_RTL }
        fun action(label:String, icon:String, fn:()->Unit) {
            val b = TextView(this).apply { text="$icon\n$label"; textSize=10f; gravity=Gravity.CENTER; setTextColor(this@MainActivity.text); background=rounded(card, if(darkMode) Color.rgb(43,50,68) else Color.rgb(224,232,247), 14f); setOnClickListener { fn(); editor.invalidate() } }
            actions.addView(b, LinearLayout.LayoutParams(0,dp(58),1f).apply { setMargins(dp(3),0,dp(3),0) })
        }
        action("روشنایی","☀") { editor.adjust(20f,1f,1f); status.text="روشنایی اعمال شد ✓" }
        action("B&W","◑") { editor.gray(); status.text="سیاه‌وسفید اعمال شد ✓" }
        action("برش","⌗") { editor.squareCrop(); status.text="برش مربع اعمال شد ✓" }
        action("متن","T") { addText() }
        action("ذخیره","↓") { saveImage(Bitmap.CompressFormat.PNG) }
        page.addView(actions, LinearLayout.LayoutParams(-1,dp(66)))
        host.addView(page)
        status.text = "● تصویر در حالت ویرایش"
    }

    private fun showAdjustments() {
        showToolPanel("تنظیمات تصویر", "هر کارت یک تنظیم واقعی روی تصویر اجرا می‌کند", listOf(
            Triple("روشنایی", "thumb_brightness") { editor.adjust(22f,1f,1f) },
            Triple("کنتراست", "thumb_contrast") { editor.adjust(0f,1.18f,1f) },
            Triple("اشباع رنگ", "thumb_saturation") { editor.adjust(0f,1f,1.18f) },
            Triple("سیاه‌وسفید", "thumb_bw") { editor.gray() },
            Triple("سینمایی", "thumb_cinematic") { editor.cinematic() },
            Triple("گرم", "thumb_warm") { editor.warm() },
            Triple("سرد", "thumb_cool") { editor.cool() },
            Triple("بهبود خودکار", "thumb_brightness") { editor.autoEnhance() },
            Triple("چرخش", "thumb_cinematic") { editor.rotate90() },
            Triple("برعکس افقی", "thumb_cool") { editor.flip() },
            Triple("مربع", "thumb_saturation") { editor.squareCrop() }
        ))
    }

    private fun showEffects() {
        showToolPanel("افکت‌ها", "هر کارت یک افکت واقعی روی تصویر اجرا می‌کند", listOf(
            Triple("گلیچ", "thumb_glitch") { editor.glitch() }, Triple("کالیدوسکوپ", "thumb_pixel") { editor.kaleido() }, Triple("نوردهی", "thumb_warm") { editor.relight() },
            Triple("پیکسلی", "thumb_pixel") { editor.pixelate() }, Triple("طرح لبه", "thumb_sketch") { editor.edgeSketch() }, Triple("حرارتی", "thumb_thermal") { editor.thermal() },
            Triple("وینیت", "thumb_vignette") { editor.vignette() }, Triple("دانه فیلم", "thumb_grain") { editor.grain() }, Triple("شبح", "thumb_ghost") { editor.ghost() },
            Triple("نگاتیو", "thumb_negative") { editor.negative() }, Triple("سپیا", "thumb_sepia") { editor.sepia() }, Triple("معکوس", "thumb_negative") { editor.invert() }, Triple("سیاه‌وسفید", "thumb_bw") { editor.gray() }
        ))
    }

    private fun showAiTools() {
        val host = currentHost ?: return
        host.removeAllViews()
        val page = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(10),dp(14),dp(18)); layoutDirection=View.LAYOUT_DIRECTION_RTL }
        val back=TextView(this).apply{text="‹";textSize=31f;gravity=Gravity.CENTER;setTextColor(this@MainActivity.text);setOnClickListener{showHome()}}
        page.addView(back,LinearLayout.LayoutParams(dp(46),dp(52)))
        page.addView(textView("ابزارهای هوشمند",18f,text,true),LinearLayout.LayoutParams(-1,dp(32)))
        page.addView(textView("فقط قابلیت‌هایی که واقعاً در نسخه فعلی وجود دارند",10f,muted,false),LinearLayout.LayoutParams(-1,dp(24)))
        page.addView(textView("قانون اعتماد: IMPLEMENTED = فعال  •  MODEL-DEPENDENT = وابسته به مدل/موتور  •  PLANNED = هنوز پیاده‌سازی نشده",9f,muted,true).apply {
            gravity=Gravity.CENTER
            setPadding(dp(6),dp(6),dp(6),dp(6))
            background=rounded(if(darkMode)Color.rgb(25,30,42) else Color.rgb(240,244,252),Color.TRANSPARENT,14f)
        },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,dp(6))})
        page.addView(toolGrid(listOf(
            Triple("AI بهبود هوشمند", "thumb_brightness") { aiSmartEnhance() },
            Triple("AI تحلیل تصویر", "thumb_saturation") { aiAnalyze() },
            Triple("OCR فارسی", "thumb_bw") { ocrOffline() }, Triple("OCR لاتین", "thumb_cinematic") { ocrLatin() },
            Triple("تشخیص چهره", "thumb_warm") { faceScan() }, Triple("برچسب اشیا", "thumb_saturation") { labelImage() },
            Triple("بارکد و QR", "thumb_pixel") { barcodeScan() },
            Triple("فرمان آفلاین", "thumb_warm") { commandDialog() }, Triple("حذف پس‌زمینه سریع", "thumb_thermal") { requireImage { editor.quickBackgroundCut(); status.text="حذف پس‌زمینه سریع اعمال شد ✓"; showEditor() } }
        )),LinearLayout.LayoutParams(-1,-2))
        page.addView(textView("PLANNED — Generative Fill • Super Resolution • Deblur • Colorization • حذف پس‌زمینه مدل‌محور",9.5f,muted,false).apply {
            gravity=Gravity.CENTER
            setPadding(dp(8),dp(8),dp(8),dp(8))
            background=rounded(if(darkMode)Color.rgb(25,30,42) else Color.rgb(245,247,251),Color.TRANSPARENT,14f)
        },LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,dp(8),0,dp(8))})
        host.addView(page)
    }

    private fun buildUi() {
        status = textView("● آماده — یک تصویر باز کنید", 10.5f, muted, false).apply { gravity = Gravity.CENTER }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val top = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(12),dp(6),dp(12),dp(6)); setBackgroundColor(if(darkMode)Color.rgb(14,17,25) else Color.WHITE) }
        top.addView(TextView(this).apply{text="☰";textSize=22f;gravity=Gravity.CENTER;setTextColor(this@MainActivity.text);contentDescription="منوی برنامه";setOnClickListener{showAppMenu()}},LinearLayout.LayoutParams(dp(46),dp(48)))
        val brand=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;layoutDirection=View.LAYOUT_DIRECTION_RTL}
        brand.addView(textView("♛ ARTAR STUDIO PRO",17f,text,true),LinearLayout.LayoutParams(-1,dp(25)))
        brand.addView(textView("v6.4  •  PHOTO · DESIGN · CREATE",9f,muted,false),LinearLayout.LayoutParams(-1,dp(18)))
        top.addView(brand,LinearLayout.LayoutParams(0,dp(48),1f))
        top.addView(TextView(this).apply{text=if(darkMode)"☀" else "◐";textSize=22f;gravity=Gravity.CENTER;setTextColor(accent);contentDescription="تغییر تم";setOnClickListener{toggleTheme()}},LinearLayout.LayoutParams(dp(46),dp(48)))
        root.addView(top, LinearLayout.LayoutParams(-1,dp(62)))

        currentHost = FrameLayout(this).apply { setBackgroundColor(bg) }
        root.addView(currentHost,LinearLayout.LayoutParams(-1,0,1f))

        val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(dp(8),dp(5),dp(8),dp(5));setBackgroundColor(if(darkMode)Color.rgb(14,17,25) else Color.WHITE);layoutDirection=View.LAYOUT_DIRECTION_RTL;elevation=dp(8).toFloat()}
        nav.addView(navButton("⌂","خانه",true){showHome()},LinearLayout.LayoutParams(0,dp(66),1f))
        nav.addView(navButton("▧","گالری",false){openImage.launch("image/*")},LinearLayout.LayoutParams(0,dp(66),1f))
        nav.addView(navButton("＋","تصویر",false){openImage.launch("image/*")},LinearLayout.LayoutParams(0,dp(66),1f))
        nav.addView(navButton("▣","پروژه‌ها",false){loadProject()},LinearLayout.LayoutParams(0,dp(66),1f))
        nav.addView(navButton("⚙","تنظیمات",false){showSettings()},LinearLayout.LayoutParams(0,dp(66),1f))
        root.addView(nav,LinearLayout.LayoutParams(-1,dp(76)))
        setContentView(root)
        showHome()
    }

    private fun toggleTheme(){
        val current=editor.baseBitmap?.copy(Bitmap.Config.ARGB_8888,true)
        val layers=editor.layersJson()
        darkMode=!darkMode
        getPreferences(MODE_PRIVATE).edit().putBoolean("dark_mode",darkMode).apply()
        buildUi()
        current?.let{editor.setBitmap(it);editor.restoreLayers(layers)}
    }

    private fun navButton(icon: String, label: String, selected: Boolean, action: () -> Unit): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            background = if (selected) rounded(if (darkMode) Color.rgb(28,34,52) else Color.rgb(239,244,255), Color.TRANSPARENT, 16f) else null
            setOnClickListener { action() }
            val i = TextView(this@MainActivity).apply { text = icon; textSize = 22f; gravity = Gravity.CENTER; setTextColor(accent) }
            addView(i, LinearLayout.LayoutParams(-1, dp(31)))
            addView(textView(label, 9.5f, text, selected).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, dp(24)))
        }
    }

    private fun showAppMenu(){
        val dialog = Dialog(this)
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(14),dp(18),dp(14)); background=rounded(card, Color.TRANSPARENT, 24f); layoutDirection=View.LAYOUT_DIRECTION_RTL }
        box.addView(textView("ARTAR STUDIO PRO",19f,text,true).apply{gravity=Gravity.CENTER;setPadding(0,0,0,dp(8))},LinearLayout.LayoutParams(-1,dp(42)))
        fun row(label:String, icon:String, action:()->Unit){ val r=TextView(this).apply{text="$icon   $label";textSize=15f;setTextColor(this@MainActivity.text);gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,dp(12),0);background=rounded(if(darkMode)Color.rgb(28,34,48) else Color.rgb(245,248,255),Color.TRANSPARENT,16f);isClickable=true;setOnClickListener{dialog.dismiss();action()}};box.addView(r,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,dp(5),0,dp(5))}) }
        row("تغییر تم","◐"){toggleTheme()}
        row("تنظیمات و خروجی","⚙"){showSettings()}
        row("درباره برنامه","ⓘ"){aboutDialog()}
        row("راهنما","? "){helpDialog()}
        row("حریم خصوصی","▣"){privacyDialog()}
        val close=TextView(this).apply{text="بازگشت";textSize=14f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=gradientButtonBackground();setOnClickListener{dialog.dismiss()}}
        box.addView(close,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(10),0,0)})
        dialog.setContentView(box);dialog.window?.setBackgroundDrawableResource(android.R.color.transparent);dialog.window?.setLayout(dp(330),WindowManager.LayoutParams.WRAP_CONTENT);dialog.show();dialog.window?.setLayout((resources.displayMetrics.widthPixels*.86f).roundToInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun showSettings(){
        val dialog=Dialog(this)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(14),dp(18),dp(14));background=rounded(card,Color.TRANSPARENT,24f);layoutDirection=View.LAYOUT_DIRECTION_RTL}
        box.addView(textView("تنظیمات و خروجی",19f,text,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(44)))
        fun row(label:String,action:()->Unit){val r=TextView(this).apply{text=label;textSize=14f;setTextColor(this@MainActivity.text);gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,dp(12),0);background=rounded(if(darkMode)Color.rgb(28,34,48) else Color.rgb(245,248,255),Color.TRANSPARENT,16f);setOnClickListener{dialog.dismiss();action()}};box.addView(r,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,dp(4))})}
        row(if(darkMode)"☀  فعال کردن حالت روشن" else "☾  فعال کردن حالت تاریک"){toggleTheme()}
        row("💾  ذخیره پروژه"){saveProject()}
        row("📂  بارگذاری پروژه"){loadProject()}
        row("PNG  خروجی"){requireImage{saveImage(Bitmap.CompressFormat.PNG)}}
        row("JPG  خروجی"){requireImage{saveImage(Bitmap.CompressFormat.JPEG)}}
        row("PDF  ساخت فایل"){requireImage{exportPdf()}}
        row("🗂  پردازش دسته‌ای"){openBatch.launch("image/*")}
        val close=TextView(this).apply{text="بازگشت";textSize=14f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=gradientButtonBackground();setOnClickListener{dialog.dismiss()}}
        box.addView(close,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(10),0,0)})
        dialog.setContentView(box);dialog.window?.setBackgroundDrawableResource(android.R.color.transparent);dialog.show();dialog.window?.setLayout((resources.displayMetrics.widthPixels*.86f).roundToInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun aboutDialog(){AlertDialog.Builder(this).setTitle("درباره Artar Studio Pro").setMessage("نسخه 6.4\nیک استودیوی ویرایش تصویر، طراحی و ابزارهای هوشمند روی موبایل.\n\nقانون محصول: قابلیت‌های AI پیشرفته فقط وقتی فعال اعلام می‌شوند که مدل واقعی آن‌ها در برنامه یکپارچه و تست شده باشد.").setPositiveButton("باشه",null).show()}
    private fun helpDialog(){AlertDialog.Builder(this).setTitle("راهنما").setMessage("۱) تصویر را باز کنید.\n۲) ابزار موردنظر را انتخاب کنید.\n۳) برای برگشت از Undo استفاده کنید.\n۴) پروژه را ذخیره کنید.\n۵) از بخش خروجی PNG/JPG/PDF بگیرید.").setPositiveButton("باشه",null).show()}
    private fun privacyDialog(){AlertDialog.Builder(this).setTitle("حریم خصوصی").setMessage("پردازش‌های محلی تا حد امکان روی دستگاه انجام می‌شوند. سرویس ابری برای قابلیت‌های فعلی لازم نیست.").setPositiveButton("باشه",null).show()}

    private fun loadUri(uri:Uri){
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                BitmapFactory.decodeStream(input)?.let { bmp ->
                    currentPreview=bmp.copy(Bitmap.Config.ARGB_8888,true)
                    editor.setBitmap(bmp)
                }
            }
            status.text="تصویر باز شد ✓"
            val pending = pendingAction
            pendingAction = null
            if (pending != null) { pending(); showEditor() } else showEditor()
        } catch (e: Exception) {
            status.text="باز کردن تصویر ناموفق بود"
            Toast.makeText(this, "خطا در باز کردن تصویر", Toast.LENGTH_SHORT).show()
        }
    }
    private fun addText(){ val input=EditText(this).apply{hint="متن فارسی یا انگلیسی"}; AlertDialog.Builder(this).setTitle("Text Layer واقعی").setView(input).setPositiveButton("افزودن"){_,_->editor.addText(input.text.toString());status.text="لایه متن ساخته شد؛ با کشیدن متن آن را جابه‌جا کنید"}.setNegativeButton("لغو",null).show() }

    private fun aiSmartEnhance(){
        requireImage {
            val b=editor.baseBitmap ?: return@requireImage
            status.text="AI در حال تحلیل تصویر است…"
            val image=InputImage.fromBitmap(b,0)
            val labelTask=ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS).process(image)
            val faceTask=FaceDetection.getClient(FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).build()).process(image)
            com.google.android.gms.tasks.Tasks.whenAllSuccess<Any>(labelTask,faceTask)
                .addOnSuccessListener { results ->
                    val labels=(results[0] as List<*>).filterIsInstance<com.google.mlkit.vision.label.ImageLabel>()
                    val faces=(results[1] as List<*>).filterIsInstance<com.google.mlkit.vision.face.Face>()
                    editor.faceBoxes=faces.map{it.boundingBox}
                    editor.autoEnhance()
                    if(faces.isNotEmpty()) editor.adjust(0f,1.05f,1.04f) else editor.adjust(0f,1.08f,1.03f)
                    editor.invalidate()
                    val top=labels.take(3).joinToString("، "){it.text}
                    status.text="AI بهبود شد ✓  • ${faces.size} چهره • ${if(top.isBlank()) "تحلیل تصویر انجام شد" else top}"
                    showEditor()
                }
                .addOnFailureListener { e ->
                    status.text="AI خطا داشت: ${e.message ?: "نامشخص"}"
                }
        }
    }

    private fun aiAnalyze(){
        requireImage {
            val b=editor.baseBitmap ?: return@requireImage
            status.text="AI در حال تحلیل…"
            val image=InputImage.fromBitmap(b,0)
            val labelTask=ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS).process(image)
            val faceTask=FaceDetection.getClient(FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE).build()).process(image)
            com.google.android.gms.tasks.Tasks.whenAllSuccess<Any>(labelTask,faceTask)
                .addOnSuccessListener { results ->
                    val labels=(results[0] as List<*>).filterIsInstance<com.google.mlkit.vision.label.ImageLabel>()
                    val faces=(results[1] as List<*>).filterIsInstance<com.google.mlkit.vision.face.Face>()
                    editor.faceBoxes=faces.map{it.boundingBox}
                    editor.invalidate()
                    val labelText=labels.take(8).joinToString("\n"){ "• ${it.text}: ${(it.confidence*100).roundToInt()}%" }
                    AlertDialog.Builder(this)
                        .setTitle("AI Image Analysis")
                        .setMessage("چهره‌ها: ${faces.size}\n\nبرچسب‌های تصویر:\n${if(labelText.isBlank()) "برچسبی پیدا نشد" else labelText}")
                        .setPositiveButton("باشه",null).show()
                    status.text="تحلیل AI کامل شد ✓"
                }
                .addOnFailureListener { e -> status.text="تحلیل AI ناموفق بود: ${e.message ?: "نامشخص"}" }
        }
    }

    private fun ocrLatin(){ val b=editor.baseBitmap?:return; TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(InputImage.fromBitmap(b,0)).addOnSuccessListener{r->editor.addText(r.text);status.text="OCR لاتین: ${r.text.length} نویسه"}.addOnFailureListener{status.text="OCR لاتین خطا داشت"} }
    private fun ocrOffline(){ val b=editor.baseBitmap?:return; Thread { try { val dir=File(filesDir,"tessdata");dir.mkdirs();val fas=File(dir,"fas.traineddata");val eng=File(dir,"eng.traineddata");if(!fas.exists()||fas.length()<1024)copyAsset("tessdata/fas.traineddata",fas);if(!eng.exists()||eng.length()<1024)copyAsset("tessdata/eng.traineddata",eng);if(fas.length()<1024||eng.length()<1024)throw IllegalStateException("مدل OCR در برنامه وجود ندارد");val tess=TessBaseAPI();val ok=tess.init(filesDir.absolutePath,"fas+eng");if(!ok)throw IllegalStateException("Tesseract init failed");tess.setImage(b);val text=tess.getUTF8Text() ?: "";tess.recycle();runOnUiThread{editor.addText(text);status.text="OCR آفلاین واقعی: ${text.length} نویسه ✓"}}catch(e:Exception){runOnUiThread{status.text="OCR فارسی آماده نشد: ${e.message}"}} }.start() }
    private fun copyAsset(path:String,to:File){if(!to.exists())assets.open(path).use{input->FileOutputStream(to).use{input.copyTo(it)}}}
    private fun faceScan(){ val b=editor.baseBitmap?:return; FaceDetection.getClient(FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE).build()).process(InputImage.fromBitmap(b,0)).addOnSuccessListener{faces->editor.faceBoxes=faces.map{it.boundingBox};editor.invalidate();status.text="${faces.size} چهره پیدا شد"}.addOnFailureListener{status.text="تشخیص چهره خطا داشت"} }
    private fun labelImage(){ val b=editor.baseBitmap?:return; ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS).process(InputImage.fromBitmap(b,0)).addOnSuccessListener{labels->status.text=labels.take(6).joinToString(" • "){it.text+" ${(it.confidence*100).roundToInt()}%"}}.addOnFailureListener{status.text="برچسب‌گذاری خطا داشت"} }
    private fun barcodeScan(){
        val b=editor.baseBitmap ?: return
        val options=BarcodeScannerOptions.Builder().setBarcodeFormats(
            com.google.mlkit.vision.barcode.common.Barcode.FORMAT_ALL_FORMATS
        ).build()
        BarcodeScanning.getClient(options).process(InputImage.fromBitmap(b,0))
            .addOnSuccessListener { codes ->
                val result=codes.mapNotNull { it.rawValue }.distinct()
                status.text=if(result.isEmpty()) "بارکد یا QR پیدا نشد" else "بارکد: ${result.joinToString(" • ")} "
            }.addOnFailureListener { status.text="اسکن بارکد خطا داشت" }
    }
    private fun commandDialog(){val input=EditText(this).apply{hint="مثلاً: گرم + روشن + کنتراست"};AlertDialog.Builder(this).setTitle("Arda Command • آفلاین").setView(input).setPositiveButton("اجرا"){_,_->runCommand(input.text.toString())}.setNegativeButton("لغو",null).show()}
    private fun runCommand(s:String){
        val actions=AiCommandParser.parse(s)
        if(actions.isEmpty()){status.text="فرمان شناخته نشد — مثال: گرم + روشن + کنتراست";return}
        actions.forEach {
            when(it){
                AiCommandParser.Action.GRAYSCALE -> editor.gray()
                AiCommandParser.Action.WARM -> editor.warm()
                AiCommandParser.Action.COOL -> editor.cool()
                AiCommandParser.Action.BRIGHTEN -> editor.adjust(25f,1f,1f)
                AiCommandParser.Action.CONTRAST -> editor.adjust(0f,1.2f,1f)
                AiCommandParser.Action.SQUARE_CROP -> editor.squareCrop()
                AiCommandParser.Action.ROTATE -> editor.rotate90()
                AiCommandParser.Action.BACKGROUND_CUT -> editor.quickBackgroundCut()
            }
        }
        editor.invalidate()
        status.text="فرمان آفلاین اجرا شد ✓ (${actions.size} عمل)"
    }
    private fun showLayers(){val names=editor.layerNames();AlertDialog.Builder(this).setTitle("Layers").setItems(names.toTypedArray(),null).setPositiveButton("باشه",null).show()}

    private fun showSocialCrops(){
        showToolPanel("برش شبکه‌های اجتماعی", "نسبت‌های استاندارد روی مرکز تصویر اعمال می‌شوند", listOf(
            Triple("1:1 مربع", "thumb_saturation") { editor.cropAspect(1f,1f) },
            Triple("4:5 پست", "thumb_cinematic") { editor.cropAspect(4f,5f) },
            Triple("9:16 استوری", "thumb_warm") { editor.cropAspect(9f,16f) },
            Triple("16:9 افقی", "thumb_cool") { editor.cropAspect(16f,9f) },
            Triple("3:4 پرتره", "thumb_warm") { editor.cropAspect(3f,4f) }
        ))
    }

    private fun templatesDialog(){
        val names=arrayOf("Instagram Post • Clean","Instagram Post • Cinematic","Story • Sale","Story • Quote","Poster • Dark","Poster • Minimal","Portrait • Warm","Landscape • Crisp","Film • Vintage","Neon • Cyber","Black & White","Product • Promo")
        AlertDialog.Builder(this).setTitle("ARTAR Template Library").setItems(names){_,which->
            when(which){
                0->{editor.squareCrop();editor.adjust(0f,1.08f,1.06f);editor.addText("YOUR TITLE")}
                1->{editor.squareCrop();editor.cinematic();editor.vignette();editor.addText("CINEMATIC")}
                2->{editor.cropAspect(9f,16f);editor.warm();editor.addText("SALE")}
                3->{editor.cropAspect(9f,16f);editor.gray();editor.addText("YOUR QUOTE")}
                4->{editor.poster();editor.vignette();editor.addText("POSTER")}
                5->{editor.poster();editor.adjust(0f,1.08f,1.02f);editor.addText("MINIMAL")}
                6->{editor.warm();editor.relight();editor.addText("PORTRAIT")}
                7->{editor.adjust(0f,1.12f,1.08f);editor.dehaze();editor.addText("EXPLORE")}
                8->{editor.grain();editor.warm();editor.addText("FILM") }
                9->{editor.glitch();editor.addText("NEON") }
                10->{editor.gray();editor.addText("BLACK / WHITE")}
                11->{editor.adjust(8f,1.15f,1.08f);editor.addText("NEW PRODUCT")}
            }
            status.text="قالب انتخاب‌شده به‌صورت واقعی روی تصویر اعمال شد"
        }.show()
    }


    private fun saveImage(format:Bitmap.CompressFormat){val b=editor.render();val ext=if(format==Bitmap.CompressFormat.PNG)"png"else"jpg";val name="Arda_${System.currentTimeMillis()}.$ext";val v=ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,name);put(MediaStore.Images.Media.MIME_TYPE,if(ext=="png")"image/png"else"image/jpeg");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/ArdaStudio")};contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v)?.let{u->contentResolver.openOutputStream(u)?.use{b.compress(format,95,it)}};status.text="خروجی واقعی در گالری ذخیره شد"}
    private fun exportPdf(){
        val b=editor.render()
        val name="Artar_${System.currentTimeMillis()}.pdf"
        try {
            val doc=android.graphics.pdf.PdfDocument()
            val pageW=595
            val pageH=842
            val page=doc.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageW,pageH,1).create())
            val pad=24f
            val scale=min((pageW-2*pad)/b.width.toFloat(),(pageH-2*pad)/b.height.toFloat())
            val dw=b.width*scale
            val dh=b.height*scale
            val left=(pageW-dw)/2f
            val top=(pageH-dh)/2f
            page.canvas.drawBitmap(b,null,android.graphics.RectF(left,top,left+dw,top+dh),null)
            doc.finishPage(page)
            if (android.os.Build.VERSION.SDK_INT>=29) {
                val values=ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME,name)
                    put(MediaStore.Downloads.MIME_TYPE,"application/pdf")
                    put(MediaStore.Downloads.RELATIVE_PATH,"Download/ArtarStudio")
                    put(MediaStore.Downloads.IS_PENDING,1)
                }
                val uri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values)
                    ?: throw IllegalStateException("ساخت فایل PDF ممکن نشد")
                try {
                    contentResolver.openOutputStream(uri)?.use{doc.writeTo(it)}
                        ?: throw IllegalStateException("باز کردن فایل PDF ممکن نشد")
                    values.clear();values.put(MediaStore.Downloads.IS_PENDING,0)
                    contentResolver.update(uri,values,null,null)
                } catch(e:Exception){ contentResolver.delete(uri,null,null); throw e }
            } else {
                val dir=java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS),"ArtarStudio")
                dir.mkdirs()
                val f=java.io.File(dir,name)
                java.io.FileOutputStream(f).use{doc.writeTo(it)}
            }
            doc.close()
            status.text="PDF واقعی ساخته و در پوشه Download/ArtarStudio ذخیره شد ✓"
            Toast.makeText(this,"PDF ذخیره شد: $name",Toast.LENGTH_LONG).show()
        } catch(e:Exception){
            status.text="ساخت PDF ناموفق بود: ${e.message ?: "خطای نامشخص"}"
            Toast.makeText(this,"خطا در ساخت PDF: ${e.message ?: "نامشخص"}",Toast.LENGTH_LONG).show()
        }
    }
    private fun saveProject(){val f=File(filesDir,"arda_project.json");val o=JSONObject();o.put("version",4);editor.baseBitmap?.let { bitmap -> val img=File(filesDir,"project.png"); FileOutputStream(img).use { out -> bitmap.compress(Bitmap.CompressFormat.PNG,100,out) }; o.put("image",img.name) };o.put("layers",editor.layersJson());f.writeText(o.toString());status.text="پروژه واقعی ذخیره شد"}
    private fun loadProject(){val f=File(filesDir,"arda_project.json");if(!f.exists()){status.text="پروژه‌ای نیست";Toast.makeText(this,"هنوز پروژه‌ای ذخیره نشده است",Toast.LENGTH_SHORT).show();return};val o=JSONObject(f.readText());val img=File(filesDir,o.optString("image"));if(img.exists()){editor.setBitmap(BitmapFactory.decodeFile(img.absolutePath));currentPreview=editor.baseBitmap?.copy(Bitmap.Config.ARGB_8888,true)};editor.restoreLayers(o.optJSONArray("layers"));status.text="پروژه بارگذاری شد ✓";if(editor.baseBitmap!=null)showEditor()}
    private fun batch(uris:List<Uri>){Thread{var done=0;uris.take(100).forEachIndexed{idx,u->contentResolver.openInputStream(u)?.use{ins->BitmapFactory.decodeStream(ins)?.let{b->val e=Bitmap.createBitmap(b.width,b.height,Bitmap.Config.ARGB_8888);Canvas(e).drawBitmap(b,0f,0f,null);val v=ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,"ArdaBatch_${System.currentTimeMillis()}_$idx.jpg");put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/ArdaStudio/Batch")};contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v)?.let{out->contentResolver.openOutputStream(out)?.use{e.compress(Bitmap.CompressFormat.JPEG,94,it)};done++}}}};runOnUiThread{status.text="Batch واقعی تمام شد: $done تصویر"}}.start()}

    class EditorView(c:Context):View(c){
        enum class Mode{MOVE,BRUSH,ERASER,MASK};var mode=Mode.MOVE;var baseBitmap:Bitmap?=null;private val history=ArrayDeque<Bitmap>();private val future=ArrayDeque<Bitmap>();var faceBoxes:List<Rect> = emptyList();private val textLayers=mutableListOf<TextLayer>();private var lastX=0f;private var lastY=0f;private var selected=-1
        data class TextLayer(var text:String,var x:Float,var y:Float,var size:Float=54f,var color:Int=Color.WHITE)
        fun setBitmap(b:Bitmap?){baseBitmap=b?.copy(Bitmap.Config.ARGB_8888,true);history.clear();future.clear();textLayers.clear();faceBoxes=emptyList();invalidate()}
        private fun snap(){baseBitmap?.let{history.addLast(it.copy(Bitmap.Config.ARGB_8888,true));if(history.size>15)history.removeFirst();future.clear()}}
        fun undo(){if(history.isNotEmpty()){baseBitmap?.let{future.addLast(it.copy(Bitmap.Config.ARGB_8888,true))};baseBitmap=history.removeLast();invalidate()}}
        fun redo(){if(future.isNotEmpty()){baseBitmap?.let{history.addLast(it.copy(Bitmap.Config.ARGB_8888,true))};baseBitmap=future.removeLast();invalidate()}}
        override fun onDraw(c:Canvas){c.drawColor(Color.rgb(18,21,28));val b=baseBitmap?:run{val p=Paint(Paint.ANTI_ALIAS_FLAG);p.color=Color.LTGRAY;p.textSize=22f;p.textAlign=Paint.Align.CENTER;c.drawText("یک تصویر باز کنید تا ویرایش را شروع کنید",width/2f,height/2f,p);return};val fit=min(width.toFloat()/b.width,height.toFloat()/b.height)*.9f;val left=(width-b.width*fit)/2f;val top=(height-b.height*fit)/2f;c.drawBitmap(b,null,RectF(left,top,left+b.width*fit,top+b.height*fit),null);val p=Paint(Paint.ANTI_ALIAS_FLAG);p.style=Paint.Style.FILL;textLayers.forEachIndexed{idx,t->p.color=t.color;p.textSize=t.size*fit;p.typeface=Typeface.DEFAULT_BOLD;c.drawText(t.text,left+t.x*fit,top+t.y*fit,p);if(idx==selected){p.style=Paint.Style.STROKE;p.color=Color.CYAN;p.strokeWidth=2f;val w=p.measureText(t.text);c.drawRect(left+t.x*fit-8,top+(t.y-t.size)*fit,left+(t.x*fit)+w+8,top+t.y*fit+8,p);p.style=Paint.Style.FILL}};p.style=Paint.Style.STROKE;p.color=Color.CYAN;p.strokeWidth=3f;faceBoxes.forEach{r->c.drawRect(left+r.left*fit,top+r.top*fit,left+r.right*fit,top+r.bottom*fit,p)}}
        override fun onTouchEvent(e:MotionEvent):Boolean{val b=baseBitmap?:return true;val fit=min(width.toFloat()/b.width,height.toFloat()/b.height)*.9f;val left=(width-b.width*fit)/2f;val top=(height-b.height*fit)/2f;val bx=(e.x-left)/fit;val by=(e.y-top)/fit;if(e.action==MotionEvent.ACTION_DOWN){selected=textLayers.indexOfLast{bx>=it.x-10&&bx<=it.x+max(80f,it.text.length*it.size*.55f)&&by>=it.y-it.size&&by<=it.y+10};lastX=bx;lastY=by;return true};if(e.action==MotionEvent.ACTION_MOVE){if(selected>=0&&mode==Mode.MOVE){textLayers[selected].x+=bx-lastX;textLayers[selected].y+=by-lastY;lastX=bx;lastY=by;invalidate();return true};if(mode==Mode.BRUSH||mode==Mode.ERASER||mode==Mode.MASK){stroke(lastX,lastY,bx,by);lastX=bx;lastY=by;return true}};return true}
        private fun stroke(x1:Float,y1:Float,x2:Float,y2:Float){val b=baseBitmap?:return;val p=Paint(Paint.ANTI_ALIAS_FLAG);p.strokeWidth=max(8f,min(b.width,b.height)*.012f);p.strokeCap=Paint.Cap.ROUND;p.color=if(mode==Mode.MASK) Color.argb(150,255,70,70) else Color.WHITE;if(mode==Mode.ERASER)p.xfermode=PorterDuffXfermode(PorterDuff.Mode.CLEAR);Canvas(b).drawLine(x1,y1,x2,y2,p);invalidate()}
        fun addText(s:String){if(s.isNotBlank()){textLayers.add(TextLayer(s,80f,100f+textLayers.size*70));selected=textLayers.lastIndex;invalidate()}}
        fun render():Bitmap{val b=baseBitmap?:return Bitmap.createBitmap(1,1,Bitmap.Config.ARGB_8888);val out=b.copy(Bitmap.Config.ARGB_8888,true);val c=Canvas(out);val p=Paint(Paint.ANTI_ALIAS_FLAG);textLayers.forEach{p.color=it.color;p.textSize=it.size;p.typeface=Typeface.DEFAULT_BOLD;c.drawText(it.text,it.x,it.y,p)};return out}
        fun layerNames()=listOf("Base Image")+textLayers.mapIndexed{index,it->"Text $index: ${it.text.take(28)}"}
        fun layersJson():JSONArray{val a=JSONArray();textLayers.forEach{a.put(JSONObject().apply{put("text",it.text);put("x",it.x);put("y",it.y);put("size",it.size);put("color",it.color)})};return a}
        fun restoreLayers(a:JSONArray?){textLayers.clear();if(a!=null)for(i in 0 until a.length()){val o=a.getJSONObject(i);textLayers.add(TextLayer(o.optString("text"),o.optDouble("x",80.0).toFloat(),o.optDouble("y",100.0).toFloat(),o.optDouble("size",54.0).toFloat(),o.optInt("color",Color.WHITE)))};selected=textLayers.lastIndex;invalidate()}
        private fun applyMatrix(cm:ColorMatrix){val b=baseBitmap?:return;snap();val out=Bitmap.createBitmap(b.width,b.height,Bitmap.Config.ARGB_8888);Canvas(out).drawBitmap(b,0f,0f,Paint().apply{colorFilter=ColorMatrixColorFilter(cm)});baseBitmap=out;invalidate()}
        fun adjust(br:Float,con:Float,sat:Float){val cm=ColorMatrix(floatArrayOf(con,0f,0f,0f,br,0f,con,0f,0f,br,0f,0f,con,0f,br,0f,0f,0f,1f,0f));if(sat!=1f){val s=ColorMatrix();s.setSaturation(sat);cm.postConcat(s)};applyMatrix(cm)}
        fun gray(){val c=ColorMatrix();c.setSaturation(0f);applyMatrix(c)};fun warm(){adjust(5f,1.02f,1.08f)};fun cool(){adjust(0f,1.02f,.94f)}
        fun cinematic(){applyMatrix(ColorMatrix(floatArrayOf(1.12f,0f,0f,0f,-7f,0f,1.04f,0f,0f,-3f,0f,0f,.92f,0f,6f,0f,0f,0f,1f,0f)))}
        fun autoEnhance(){val b=baseBitmap?:return;snap();var minV=255;var maxV=0;for(y in 0 until b.height step 4)for(x in 0 until b.width step 4){val p=b.getPixel(x,y);val v=(Color.red(p)+Color.green(p)+Color.blue(p))/3;minV=min(minV,v);maxV=max(maxV,v)};val scale=255f/max(1,maxV-minV);adjust(-minV*scale,scale,1f)}
        fun rotate90(){val b=baseBitmap?:return;snap();baseBitmap=Bitmap.createBitmap(b,0,0,b.width,b.height,Matrix().apply{postRotate(90f)},true);invalidate()};fun flip(){val b=baseBitmap?:return;snap();baseBitmap=Bitmap.createBitmap(b,0,0,b.width,b.height,Matrix().apply{postScale(-1f,1f)},true);invalidate()};fun squareCrop(){cropAspect(1f,1f)}
        fun cropAspect(wRatio:Float,hRatio:Float){val b=baseBitmap?:return;snap();val target=wRatio/hRatio;val current=b.width.toFloat()/b.height.toFloat();if(abs(current-target)<0.001f){invalidate();return};var nw=b.width;var nh=b.height;if(current>target){nw=(b.height*target).roundToInt()}else{nh=(b.width/target).roundToInt()};nw=nw.coerceAtLeast(1).coerceAtMost(b.width);nh=nh.coerceAtLeast(1).coerceAtMost(b.height);baseBitmap=Bitmap.createBitmap(b,(b.width-nw)/2,(b.height-nh)/2,nw,nh);invalidate()}
        fun negative(){val c=ColorMatrix(floatArrayOf(-1f,0f,0f,0f,255f,0f,-1f,0f,0f,255f,0f,0f,-1f,0f,255f,0f,0f,0f,1f,0f));applyMatrix(c)}
        fun sepia(){val c=ColorMatrix(floatArrayOf(.393f,.769f,.189f,0f,0f,.349f,.686f,.168f,0f,0f,.272f,.534f,.131f,0f,0f,0f,0f,0f,1f,0f));applyMatrix(c)}
        fun invert(){negative()}
        fun dehaze(){adjust(8f,1.12f,1.08f)}
        fun poster(){if(textLayers.isEmpty())addText("YOUR TITLE")}
        fun colorDna(){val b=baseBitmap?:return;val sum=LongArray(3);var count=0L;for(y in 0 until b.height step 8)for(x in 0 until b.width step 8){val p=b.getPixel(x,y);sum[0]+=Color.red(p);sum[1]+=Color.green(p);sum[2]+=Color.blue(p);count++};val r=(sum[0]/count).toInt();val g=(sum[1]/count).toInt();val bl=(sum[2]/count).toInt();applyMatrix(ColorMatrix(floatArrayOf(1.05f,0f,0f,0f,(128-r)*.12f,0f,1.05f,0f,0f,(128-g)*.12f,0f,0f,1.05f,0f,(128-bl)*.12f,0f,0f,0f,1f,0f)))}
        fun quickBackgroundCut(){val b=baseBitmap?:return;snap();val out=b.copy(Bitmap.Config.ARGB_8888,true);val edge=Color.red(out.getPixel(0,0))+Color.green(out.getPixel(0,0))+Color.blue(out.getPixel(0,0));val px=IntArray(out.width*out.height);out.getPixels(px,0,out.width,0,0,out.width,out.height);for(i in px.indices){val p=px[i];val s=Color.red(p)+Color.green(p)+Color.blue(p);if(abs(s-edge)<42)px[i]=Color.TRANSPARENT};out.setPixels(px,0,out.width,0,0,out.width,out.height);baseBitmap=out;invalidate()}
        fun pixelate(){val b=baseBitmap?:return;snap();val out=b.copy(Bitmap.Config.ARGB_8888,true);val c=Canvas(out);val p=Paint();val step=max(8,min(24,b.width/50));for(y in 0 until b.height step step)for(x in 0 until b.width step step){p.color=b.getPixel(x,y);c.drawRect(x.toFloat(),y.toFloat(),min((x+step).toFloat(),b.width.toFloat()),min((y+step).toFloat(),b.height.toFloat()),p)};baseBitmap=out;invalidate()}
        fun thermal(){val b=baseBitmap?:return;snap();val out=Bitmap.createBitmap(b.width,b.height,Bitmap.Config.ARGB_8888);val px=IntArray(b.width*b.height);b.getPixels(px,0,b.width,0,0,b.width,b.height);for(i in px.indices){val p=px[i];val v=(.299*Color.red(p)+.587*Color.green(p)+.114*Color.blue(p)).toInt();px[i]=Color.rgb((v*2.2).toInt().coerceIn(0,255),((v-55)*2.5).toInt().coerceIn(0,255),((120-v)*2.1).toInt().coerceIn(0,255))};out.setPixels(px,0,b.width,0,0,b.width,b.height);baseBitmap=out;invalidate()}
        fun edgeSketch(){val b=baseBitmap?:return;snap();val out=Bitmap.createBitmap(b.width,b.height,Bitmap.Config.ARGB_8888);for(y in 1 until b.height-1)for(x in 1 until b.width-1){val a=Color.red(b.getPixel(x-1,y));val d=Color.red(b.getPixel(x+1,y));val u=Color.red(b.getPixel(x,y-1));val v=Color.red(b.getPixel(x,y+1));val e=(abs(a-d)+abs(u-v)).coerceIn(0,255);out.setPixel(x,y,Color.rgb(255-e,255-e,255-e))};baseBitmap=out;invalidate()}
        fun glitch(){val b=baseBitmap?:return;snap();val out=b.copy(Bitmap.Config.ARGB_8888,true);val c=Canvas(out);val p=Paint();for(y in 0 until b.height step 22){p.color=Color.argb(35,255,0,80);c.drawRect(0f,y.toFloat(),b.width.toFloat(),(y+8).toFloat(),p)};baseBitmap=out;invalidate()}
        fun kaleido(){val b=baseBitmap?:return;snap();val n=min(b.width,b.height);val src=Bitmap.createBitmap(b,(b.width-n)/2,(b.height-n)/2,n,n);val out=Bitmap.createBitmap(n*2,n*2,Bitmap.Config.ARGB_8888);val c=Canvas(out);val p=Paint(Paint.ANTI_ALIAS_FLAG);c.drawBitmap(src,null,RectF(0f,0f,n.toFloat(),n.toFloat()),p);c.save();c.scale(-1f,1f,n.toFloat(),n.toFloat()/2);c.drawBitmap(src,null,RectF(0f,0f,n.toFloat(),n.toFloat()),p);c.restore();c.save();c.scale(1f,-1f,n.toFloat(),n.toFloat());c.drawBitmap(src,null,RectF(0f,0f,n.toFloat(),n.toFloat()),p);c.restore();c.save();c.scale(-1f,-1f,n.toFloat(),n.toFloat());c.drawBitmap(src,null,RectF(0f,0f,n.toFloat(),n.toFloat()),p);c.restore();baseBitmap=out;invalidate()}
        fun relight(){val b=baseBitmap?:return;snap();val out=b.copy(Bitmap.Config.ARGB_8888,true);val c=Canvas(out);val p=Paint(Paint.ANTI_ALIAS_FLAG);p.shader=RadialGradient(b.width*.25f,b.height*.22f,b.width*.8f,Color.argb(110,255,235,190),Color.TRANSPARENT,Shader.TileMode.CLAMP);p.xfermode=PorterDuffXfermode(PorterDuff.Mode.SCREEN);c.drawRect(0f,0f,b.width.toFloat(),b.height.toFloat(),p);baseBitmap=out;invalidate()}
        fun vignette(){val b=baseBitmap?:return;snap();val out=b.copy(Bitmap.Config.ARGB_8888,true);val c=Canvas(out);val p=Paint();p.shader=RadialGradient(b.width/2f,b.height/2f,min(b.width,b.height)*.72f,Color.TRANSPARENT,Color.argb(180,0,0,0),Shader.TileMode.CLAMP);c.drawRect(0f,0f,b.width.toFloat(),b.height.toFloat(),p);baseBitmap=out;invalidate()}
        fun grain(){val b=baseBitmap?:return;snap();val out=b.copy(Bitmap.Config.ARGB_8888,true);val px=IntArray(b.width*b.height);out.getPixels(px,0,b.width,0,0,b.width,b.height);val rnd=Random(4);for(i in px.indices){val n=rnd.nextInt(31)-15;px[i]=Color.rgb((Color.red(px[i])+n).coerceIn(0,255),(Color.green(px[i])+n).coerceIn(0,255),(Color.blue(px[i])+n).coerceIn(0,255))};out.setPixels(px,0,b.width,0,0,b.width,b.height);baseBitmap=out;invalidate()}
        fun ghost(){val b=baseBitmap?:return;snap();val out=b.copy(Bitmap.Config.ARGB_8888,true);val c=Canvas(out);val p=Paint(Paint.ANTI_ALIAS_FLAG);p.alpha=80;c.drawBitmap(b,Matrix().apply{postTranslate(b.width*.035f,b.height*.01f)},p);baseBitmap=out;invalidate()}
    }
}
