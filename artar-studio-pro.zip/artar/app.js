const $=s=>document.querySelector(s),cv=$('#cv'),ctx=cv.getContext('2d');
let img=null,rot=0,layers=[];
$('#start').onclick=()=>$('#splash').remove();
document.querySelectorAll('#tabs button').forEach(b=>b.onclick=()=>{
 document.querySelectorAll('#tabs button,.p').forEach(e=>e.classList.remove('on'));
 b.classList.add('on');$('#'+b.dataset.t).classList.add('on')});
function draw(){
 const f=`brightness(${$('#br').value}%) contrast(${$('#co').value}%) saturate(${$('#sa').value}%) blur(${$('#bl').value}px) grayscale(${$('#gr').value}%)`;
 ctx.save();ctx.filter='none';ctx.fillStyle='#fff';ctx.fillRect(0,0,cv.width,cv.height);
 if(img){ctx.filter=f;ctx.translate(cv.width/2,cv.height/2);ctx.rotate(rot*Math.PI/2);
  const sw=rot%2?cv.height:cv.width,sh=rot%2?cv.width:cv.height,k=Math.min(sw/img.width,sh/img.height);
  ctx.drawImage(img,-img.width*k/2,-img.height*k/2,img.width*k,img.height*k)}
 ctx.restore();ctx.filter='none';
 layers.forEach(l=>{ctx.fillStyle=l.c;if(l.t=='t'){ctx.font='bold 64px sans-serif';ctx.fillText(l.s,l.x,l.y)}
  else if(l.t=='r')ctx.fillRect(l.x,l.y,200,120);else{ctx.beginPath();ctx.arc(l.x,l.y,70,0,7);ctx.fill()}})}
function load(src){const i=new Image();i.crossOrigin='anonymous';i.onload=()=>{img=i;rot=0;cv.width=Math.min(i.width,1600);cv.height=Math.round(cv.width*i.height/i.width);draw()};i.src=src}
$('#file').onchange=e=>load(URL.createObjectURL(e.target.files[0]));
['br','co','sa','bl','gr'].forEach(id=>$('#'+id).oninput=draw);
$('#rot').onclick=()=>{rot=(rot+1)%4;draw()};
const save=(blob,n)=>{const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=n;a.click()};
$('#dl').onclick=()=>cv.toBlob(b=>save(b,'artar.png'));
// Design
const add=t=>{layers.push({t,s:$('#txt').value||'Artar',c:$('#col').value,x:cv.width/4,y:cv.height/2});draw()};
$('#addt').onclick=()=>add('t');$('#addr').onclick=()=>add('r');$('#addc').onclick=()=>add('c');
$('#clr').onclick=()=>{layers=[];draw()};
// Templates
document.querySelectorAll('#tpl button').forEach(b=>b.onclick=()=>{cv.width=+b.dataset.w;cv.height=+b.dataset.h;draw()});
// AI
['ep','key'].forEach(k=>{$('#'+k).value=localStorage.getItem(k)||'';$('#'+k).onchange=e=>localStorage.setItem(k,e.target.value)});
$('#bg').onclick=async()=>{
 if(!$('#ep').value)return alert('آدرس API را وارد کنید');
 const b=await new Promise(r=>cv.toBlob(r)),fd=new FormData();fd.append('image_file',b);
 try{const r=await fetch($('#ep').value,{method:'POST',headers:{'X-Api-Key':$('#key').value},body:fd});
  if(!r.ok)throw 0;load(URL.createObjectURL(await r.blob()))}catch{alert('درخواست ناموفق بود')}};
$('#enh').onclick=()=>{const d=ctx.getImageData(0,0,cv.width,cv.height),p=d.data;let lo=255,hi=0;
 for(let i=0;i<p.length;i+=4){const v=Math.max(p[i],p[i+1],p[i+2]);lo=Math.min(lo,v);hi=Math.max(hi,v)}
 const k=255/Math.max(hi-lo,1);for(let i=0;i<p.length;i+=4)for(let j=0;j<3;j++)p[i+j]=(p[i+j]-lo)*k;
 ctx.putImageData(d,0,0)};
// Video
const v=$('#vid');$('#vf').onchange=e=>v.src=URL.createObjectURL(e.target.files[0]);
$('#snap').onclick=()=>{cv.width=v.videoWidth;cv.height=v.videoHeight;ctx.drawImage(v,0,0);$('#tabs button').click()};
$('#trim').onclick=()=>{v.currentTime=+$('#vs').value;v.onseeked=()=>{v.onseeked=null;
 const rec=new MediaRecorder(v.captureStream()),ch=[];rec.ondataavailable=e=>ch.push(e.data);
 rec.onstop=()=>save(new Blob(ch,{type:'video/webm'}),'artar.webm');rec.start();v.play();
 const end=+$('#ve').value;const t=setInterval(()=>{if(v.currentTime>=end||v.ended){clearInterval(t);v.pause();rec.stop()}},100)}};
draw();
