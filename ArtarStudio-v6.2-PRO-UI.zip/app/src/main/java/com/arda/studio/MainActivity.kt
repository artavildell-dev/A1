package com.arda.studio

import android.app.*
import android.content.*
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.*
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.googlecode.tesseract.android.TessBaseAPI
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.*
import kotlin.math.*

class MainActivity : AppCompatActivity() {
    private lateinit var editor: EditorView
    private lateinit var status: TextView
    private val openImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let { loadUri(it) } }
    private val openBatch = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { list -> if (list.isNotEmpty()) batch(list) }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi() }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 10, 15))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
        // Premium header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setBackgroundColor(Color.rgb(15, 18, 27))
        }
        val brandBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "ARTAR STUDIO PRO"
            textSize = 19f
            setTextColor(Color.WHITE)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        }
        val version = TextView(this).apply {
            text = "IMAGE OPERATING SYSTEM  •  v6.2"
            textSize = 10f
            setTextColor(Color.rgb(150, 158, 178))
        }
        brandBox.addView(title)
        brandBox.addView(version)
        header.addView(brandBox, LinearLayout.LayoutParams(0, dp(58), 1f))
        header.addView(button("＋  باز کردن تصویر") { openImage.launch("image/*") }, LinearLayout.LayoutParams(dp(142), dp(50)))
        root.addView(header)

        // Editor area
        val editorCard = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(12, 15, 22))
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        editor = EditorView(this)
        editorCard.addView(editor, FrameLayout.LayoutParams(-1, -1))
        root.addView(editorCard, LinearLayout.LayoutParams(-1, 0, 0.43f))

        // Status + quick actions
        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setBackgroundColor(Color.rgb(13, 16, 24))
        }
        status = TextView(this).apply {
            text = "●  آماده — برای شروع یک تصویر باز کنید"
            textSize = 13f
            setTextColor(Color.rgb(183, 188, 205))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        statusCard.addView(status, LinearLayout.LayoutParams(-1, dp(34)))
        val quick = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        quick.addView(button("↶  برگشت") { editor.undo() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        quick.addView(button("↷  جلو") { editor.redo() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        quick.addView(button("☀  نور") { editor.adjust(22f, 1f, 1f) }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        quick.addView(button("◐  کنتراست") { editor.adjust(0f, 1.18f, 1f) }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        quick.addView(button("◑  B&W") { editor.gray() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        statusCard.addView(quick)
        root.addView(statusCard, LinearLayout.LayoutParams(-1, dp(92)))

        // All tools: clean 2-column grid inside category cards.
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(18))
        }

        fun section(titleText: String, actions: List<Triple<String, String, () -> Unit>>) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(10))
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat()
                    setColor(Color.rgb(16, 20, 29))
                    setStroke(dp(1), Color.rgb(35, 40, 54))
                }
            }
            val heading = TextView(this).apply {
                text = titleText
                textSize = 16f
                setTextColor(Color.rgb(210, 201, 255))
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                setPadding(dp(4), dp(2), dp(4), dp(8))
            }
            card.addView(heading)
            val grid = GridLayout(this).apply {
                columnCount = 2
                rowCount = ceil(actions.size / 2.0).toInt()
                alignmentMode = GridLayout.ALIGN_BOUNDS
                useDefaultMargins = false
            }
            actions.forEach { item ->
                val b = button("${item.first}\n${item.second}", item.third)
                val lp = GridLayout.LayoutParams().apply {
                    width = 0
                    height = dp(62)
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                }
                grid.addView(b, lp)
            }
            card.addView(grid)
            val outer = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) }
            panel.addView(card, outer)
        }

        section("✦ ویرایش تصویر", listOf(
            Triple("↶", "برگشت") { editor.undo() }, Triple("↷", "جلو") { editor.redo() },
            Triple("☀", "روشنایی") { editor.adjust(22f,1f,1f) }, Triple("◐", "کنتراست") { editor.adjust(0f,1.18f,1f) },
            Triple("◒", "اشباع") { editor.adjust(0f,1f,1.18f) }, Triple("◑", "سیاه‌وسفید") { editor.gray() },
            Triple("✦", "سینمایی") { editor.cinematic() }, Triple("☼", "گرم") { editor.warm() },
            Triple("❄", "سرد") { editor.cool() }, Triple("A", "بهبود خودکار") { editor.autoEnhance() },
            Triple("⟳", "چرخش") { editor.rotate90() }, Triple("↔", "آینه") { editor.flip() },
            Triple("□", "برش مربع") { editor.squareCrop() }
        ))

        section("✎ لایه و طراحی", listOf(
            Triple("T", "متن") { addText() }, Triple("✎", "براش") { editor.mode=EditorView.Mode.BRUSH; status.text="● براش فعال است — روی تصویر بکشید" },
            Triple("⌫", "پاک‌کن") { editor.mode=EditorView.Mode.ERASER; status.text="● پاک‌کن فعال است — روی تصویر بکشید" }, Triple("◉", "ماسک") { editor.mode=EditorView.Mode.MASK; status.text="● ماسک فعال است — روی تصویر بکشید" },
            Triple("▣", "پوستر") { editor.poster() }, Triple("DNA", "رنگ DNA") { editor.colorDna() },
            Triple("▤", "لایه‌ها") { showLayers() }, Triple("▦", "قالب‌ها") { templatesDialog() }
        ))

        section("◎ هوش مصنوعی آفلاین", listOf(
            Triple("OCR", "OCR فارسی/انگلیسی") { ocrOffline() }, Triple("ML", "OCR لاتین") { ocrLatin() },
            Triple("●", "تشخیص چهره") { faceScan() }, Triple("AI", "برچسب اشیا") { labelImage() },
            Triple("⌘", "فرمان آفلاین") { commandDialog() }, Triple("✂", "حذف پس‌زمینه") { editor.quickBackgroundCut() }
        ))

        section("▦ شبکه‌های اجتماعی", listOf(
            Triple("1:1", "پست مربعی") { editor.squareCrop(); status.text="پست 1:1 آماده شد" },
            Triple("4:5", "پست عمودی") { editor.cropAspect(4f,5f); status.text="پست 4:5 آماده شد" },
            Triple("9:16", "استوری") { editor.cropAspect(9f,16f); status.text="استوری 9:16 آماده شد" },
            Triple("REEL", "کاور ریل") { editor.cropAspect(9f,16f); addText(); status.text="کاور ریل آماده شد" },
            Triple("AD", "پوستر تبلیغاتی") { editor.poster(); editor.vignette(); status.text="پوستر تبلیغاتی آماده شد" },
            Triple("Q", "کارت نقل‌قول") { editor.poster(); editor.gray(); status.text="کارت نقل‌قول آماده شد" }
        ))

        section("⚡ افکت‌های خلاقانه", listOf(
            Triple("THERM", "حرارتی") { editor.thermal() }, Triple("GLITCH", "گلیچ") { editor.glitch() },
            Triple("EDGE", "طرح لبه") { editor.edgeSketch() }, Triple("PIX", "پیکسلی") { editor.pixelate() },
            Triple("K", "کالیدوسکوپ") { editor.kaleido() }, Triple("LIGHT", "نوردهی") { editor.relight() },
            Triple("V", "وینیت") { editor.vignette() }, Triple("G", "دانه فیلم") { editor.grain() },
            Triple("GHOST", "روح") { editor.ghost() }, Triple("DNA", "Color DNA") { editor.colorDna() },
            Triple("NEG", "نگاتیو") { editor.negative() }, Triple("SEP", "سپیا") { editor.sepia() },
            Triple("INV", "معکوس") { editor.invert() }
        ))

        section("⇩ پروژه و خروجی", listOf(
            Triple("BATCH", "پردازش گروهی") { openBatch.launch("image/*") }, Triple("PDF", "خروجی PDF") { exportPdf() },
            Triple("JPG", "ذخیره JPG") { saveImage(Bitmap.CompressFormat.JPEG) }, Triple("PNG", "ذخیره PNG") { saveImage(Bitmap.CompressFormat.PNG) },
            Triple("SAVE", "ذخیره پروژه") { saveProject() }, Triple("OPEN", "بارگذاری پروژه") { loadProject() }
        ))

        scroll.addView(panel)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 0.47f))
        setContentView(root)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = if (label.contains("\n")) 11f else 11.5f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        isAllCaps = false
        minHeight = 0
        minimumHeight = 0
        setPadding(4, 3, 4, 3)
        background = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = 13f * resources.displayMetrics.density
            setColor(Color.rgb(27, 32, 44))
            setStroke((1 * resources.displayMetrics.density).roundToInt(), Color.rgb(53, 60, 78))
        }
        stateListAnimator = null
        setOnClickListener { action() }
    }

    private fun loadUri(uri:Uri){ contentResolver.openInputStream(uri)?.use{editor.setBitmap(BitmapFactory.decodeStream(it))}; status.text="تصویر باز شد" }
    private fun addText(){ val input=EditText(this).apply{hint="متن فارسی یا انگلیسی"}; AlertDialog.Builder(this).setTitle("Text Layer واقعی").setView(input).setPositiveButton("افزودن"){_,_->editor.addText(input.text.toString());status.text="لایه متن ساخته شد؛ با کشیدن متن آن را جابه‌جا کنید"}.setNegativeButton("لغو",null).show() }

    private fun ocrLatin(){ val b=editor.baseBitmap?:return; TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(InputImage.fromBitmap(b,0)).addOnSuccessListener{r->editor.addText(r.text);status.text="OCR لاتین: ${r.text.length} نویسه"}.addOnFailureListener{status.text="OCR لاتین خطا داشت"} }
    private fun ocrOffline(){ val b=editor.baseBitmap?:return; Thread { try { val dir=File(filesDir,"tessdata");dir.mkdirs();copyAsset("tessdata/fas.traineddata",File(dir,"fas.traineddata"));copyAsset("tessdata/eng.traineddata",File(dir,"eng.traineddata"));val tess=TessBaseAPI();val ok=tess.init(filesDir.absolutePath,"fas+eng");if(!ok)throw IllegalStateException("Tesseract init failed");tess.setImage(b);val text=tess.getUTF8Text() ?: "";tess.recycle();runOnUiThread{editor.addText(text);status.text="OCR آفلاین: ${text.length} نویسه"}}catch(e:Exception){runOnUiThread{status.text="OCR فارسی آماده نشد: ${e.message}"}} }.start() }
    private fun copyAsset(path:String,to:File){if(!to.exists())assets.open(path).use{input->FileOutputStream(to).use{input.copyTo(it)}}}
    private fun faceScan(){ val b=editor.baseBitmap?:return; FaceDetection.getClient(FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE).build()).process(InputImage.fromBitmap(b,0)).addOnSuccessListener{faces->editor.faceBoxes=faces.map{it.boundingBox};editor.invalidate();status.text="${faces.size} چهره پیدا شد"}.addOnFailureListener{status.text="تشخیص چهره خطا داشت"} }
    private fun labelImage(){ val b=editor.baseBitmap?:return; ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS).process(InputImage.fromBitmap(b,0)).addOnSuccessListener{labels->status.text=labels.take(6).joinToString(" • "){it.text+" ${(it.confidence*100).roundToInt()}%"}}.addOnFailureListener{status.text="برچسب‌گذاری خطا داشت"} }
    private fun commandDialog(){val input=EditText(this).apply{hint="مثلاً: گرم + روشن + کنتراست"};AlertDialog.Builder(this).setTitle("Arda Command • آفلاین").setView(input).setPositiveButton("اجرا"){_,_->runCommand(input.text.toString())}.setNegativeButton("لغو",null).show()}
    private fun runCommand(s:String){val x=s.lowercase(Locale.getDefault());if("سیاه" in x || "black" in x) editor.gray(); if("گرم" in x || "warm" in x) editor.warm(); if("سرد" in x || "cool" in x) editor.cool(); if("روشن" in x || "bright" in x) editor.adjust(25f,1f,1f); if("کنتراست" in x || "contrast" in x) editor.adjust(0f,1.2f,1f); if("مربع" in x) editor.squareCrop(); if("چرخ" in x) editor.rotate90(); if("پس زمینه" in x || "background" in x) editor.quickBackgroundCut();status.text="فرمان آفلاین اجرا شد"}
    private fun showLayers(){val names=editor.layerNames();AlertDialog.Builder(this).setTitle("Layers").setItems(names.toTypedArray(),null).setPositiveButton("باشه",null).show()}

    private fun templatesDialog(){
        val names=arrayOf("Instagram Post • Clean","Instagram Post • Cinematic","Story • Sale","Story • Quote","Poster • Dark","Poster • Minimal","Portrait • Warm","Landscape • Crisp","Film • Vintage","Neon • Cyber","Black & White","Product • Promo")
        AlertDialog.Builder(this).setTitle("ARTAR Template Library").setItems(names){_,which->
            when(which){
                0->{editor.squareCrop();editor.adjust(0f,1.08f,1.06f);editor.addText("YOUR TITLE")}
                1->{editor.squareCrop();editor.cinematic();editor.vignette();editor.addText("CINEMATIC")}
                2->{editor.cropAspect(9f,16f);editor.warm();editor.addText("SALE")}
                3->{editor.cropAspect(9f,16f);editor.gray();editor.addText("YOUR QUOTE")}
                4->{editor.poster();editor.vignette();editor.addText("POSTER")}
                5->{editor.poster();editor.adjust(0f,1.08f,1.02f);editor.addText("MINIMAL")}
                6->{editor.warm();editor.relight();editor.addText("PORTRAIT")}
                7->{editor.adjust(0f,1.12f,1.08f);editor.dehaze();editor.addText("EXPLORE")}
                8->{editor.grain();editor.warm();editor.addText("FILM") }
                9->{editor.glitch();editor.addText("NEON") }
                10->{editor.gray();editor.addText("BLACK / WHITE")}
                11->{editor.adjust(8f,1.15f,1.08f);editor.addText("NEW PRODUCT")}
            }
            status.text="قالب انتخاب‌شده به‌صورت واقعی روی تصویر اعمال شد"
        }.show()
    }


    private fun saveImage(format:Bitmap.CompressFormat){val b=editor.render();val ext=if(format==Bitmap.CompressFormat.PNG)"png"else"jpg";val name="Arda_${System.currentTimeMillis()}.$ext";val v=ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,name);put(MediaStore.Images.Media.MIME_TYPE,if(ext=="png")"image/png"else"image/jpeg");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/ArdaStudio")};contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v)?.let{u->contentResolver.openOutputStream(u)?.use{b.compress(format,95,it)}};status.text="خروجی واقعی در گالری ذخیره شد"}
    private fun exportPdf(){val b=editor.render();val f=File(getExternalFilesDir(null),"Arda_${System.currentTimeMillis()}.pdf");val doc=android.graphics.pdf.PdfDocument();val page=doc.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(b.width,b.height,1).create());page.canvas.drawBitmap(b,0f,0f,null);doc.finishPage(page);FileOutputStream(f).use{doc.writeTo(it)};doc.close();status.text="PDF ساخته شد: ${f.name}"}
    private fun saveProject(){val f=File(filesDir,"arda_project.json");val o=JSONObject();o.put("version",4);editor.baseBitmap?.let { bitmap -> val img=File(filesDir,"project.png"); FileOutputStream(img).use { out -> bitmap.compress(Bitmap.CompressFormat.PNG,100,out) }; o.put("image",img.name) };o.put("layers",editor.layersJson());f.writeText(o.toString());status.text="پروژه واقعی ذخیره شد"}
    private fun loadProject(){val f=File(filesDir,"arda_project.json");if(!f.exists()){status.text="پروژه‌ای نیست";return};val o=JSONObject(f.readText());val img=File(filesDir,o.optString("image"));if(img.exists())editor.setBitmap(BitmapFactory.decodeFile(img.absolutePath));editor.restoreLayers(o.optJSONArray("layers"));status.text="پروژه بارگذاری شد"}
    private fun batch(uris:List<Uri>){Thread{var done=0;uris.take(100).forEachIndexed{idx,u->contentResolver.openInputStream(u)?.use{ins->BitmapFactory.decodeStream(ins)?.let{b->val e=Bitmap.createBitmap(b.width,b.height,Bitmap.Config.ARGB_8888);Canvas(e).drawBitmap(b,0f,0f,null);val v=ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,"ArdaBatch_${System.currentTimeMillis()}_$idx.jpg");put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/ArdaStudio/Batch")};contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v)?.let{out->contentResolver.openOutputStream(out)?.use{e.compress(Bitmap.CompressFormat.JPEG,94,it)};done++}}}};runOnUiThread{status.text="Batch واقعی تمام شد: $done تصویر"}}.start()}

    class EditorView(c:Context):View(c){
        enum class Mode{MOVE,BRUSH,ERASER,MASK};var mode=Mode.MOVE;var baseBitmap:Bitmap?=null;private val history=ArrayDeque<Bitmap>();private val future=ArrayDeque<Bitmap>();var faceBoxes:List<Rect> = emptyList();private val textLayers=mutableListOf<TextLayer>();private var lastX=0f;private var lastY=0f;private var selected=-1
        data class TextLayer(var text:String,var x:Float,var y:Float,var size:Float=54f,var color:Int=Color.WHITE)
        fun setBitmap(b:Bitmap?){baseBitmap=b?.copy(Bitmap.Config.ARGB_8888,true);history.clear();future.clear();textLayers.clear();faceBoxes=emptyList();invalidate()}
        private fun snap(){baseBitmap?.let{history.addLast(it.copy(Bitmap.Config.ARGB_8888,true));if(history.size>15)history.removeFirst();future.clear()}}
        fun undo(){if(history.isNotEmpty()){baseBitmap?.let{future.addLast(it.copy(Bitmap.Config.ARGB_8888,true))};baseBitmap=history.removeLast();invalidate()}}
        fun redo(){if(future.isNotEmpty()){baseBitmap?.let{history.addLast(it.copy(Bitmap.Config.ARGB_8888,true))};baseBitmap=future.removeLast();invalidate()}}
        override fun onDraw(c:Canvas){c.drawColor(Color.rgb(18,21,28));val b=baseBitmap?:run{val p=Paint(Paint.ANTI_ALIAS_FLAG);p.color=Color.LTGRAY;p.textSize=22f;p.textAlign=Paint.Align.CENTER;c.drawText("یک تصویر باز کنید تا ویرایش را شروع کنید",width/2f,height/2f,p);return};val fit=min(width.toFloat()/b.width,height.toFloat()/b.height)*.9f;val left=(width-b.width*fit)/2f;val top=(height-b.height*fit)/2f;c.drawBitmap(b,null,RectF(left,top,left+b.width*fit,top+b.height*fit),null);val p=Paint(Paint.ANTI_ALIAS_FLAG);p.style=Paint.Style.FILL;textLayers.forEachIndexed{idx,t->p.color=t.color;p.textSize=t.size*fit;p.typeface=Typeface.DEFAULT_BOLD;c.drawText(t.text,left+t.x*fit,top+t.y*fit,p);if(idx==selected){p.style=Paint.Style.STROKE;p.color=Color.CYAN;p.strokeWidth=2f;val w=p.measureText(t.text);c.drawRect(left+t.x*fit-8,top+(t.y-t.size)*fit,left+(t.x*fit)+w+8,top+t.y*fit+8,p);p.style=Paint.Style.FILL}};p.style=Paint.Style.STROKE;p.color=Color.CYAN;p.strokeWidth=3f;faceBoxes.forEach{r->c.drawRect(left+r.left*fit,top+r.top*fit,left+r.right*fit,top+r.bottom*fit,p)}}
        override fun onTouchEvent(e:MotionEvent):Boolean{val b=baseBitmap?:return true;val fit=min(width.toFloat()/b.width,height.toFloat()/b.height)*.9f;val left=(width-b.width*fit)/2f;val top=(height-b.height*fit)/2f;val bx=(e.x-left)/fit;val by=(e.y-top)/fit;if(e.action==MotionEvent.ACTION_DOWN){selected=textLayers.indexOfLast{bx>=it.x-10&&bx<=it.x+max(80f,it.text.length*it.size*.55f)&&by>=it.y-it.size&&by<=it.y+10};lastX=bx;lastY=by;return true};if(e.action==MotionEvent.ACTION_MOVE){if(selected>=0&&mode==Mode.MOVE){textLayers[selected].x+=bx-lastX;textLayers[selected].y+=by-lastY;lastX=bx;lastY=by;invalidate();return true};if(mode==Mode.BRUSH||mode==Mode.ERASER||mode==Mode.MASK){stroke(lastX,lastY,bx,by);lastX=bx;lastY=by;return true}};return true}
        private fun stroke(x1:Float,y1:Float,x2:Float,y2:Float){val b=baseBitmap?:return;val p=Paint(Paint.ANTI_ALIAS_FLAG);p.strokeWidth=max(8f,min(b.width,b.height)*.012f);p.strokeCap=Paint.Cap.ROUND;p.color=if(mode==Mode.MASK) Color.argb(150,255,70,70) else Color.WHITE;if(mode==Mode.ERASER)p.xfermode=PorterDuffXfermode(PorterDuff.Mode.CLEAR);Canvas(b).drawLine(x1,y1,x2,y2,p);invalidate()}
        fun addText(s:String){if(s.isNotBlank()){textLayers.add(TextLayer(s,80f,100f+textLayers.size*70));selected=textLayers.lastIndex;invalidate()}}
        fun render():Bitmap{val b=baseBitmap?:return Bitmap.createBitmap(1,1,Bitmap.Config.ARGB_8888);val out=b.copy(Bitmap.Config.ARGB_8888,true);val c=Canvas(out);val p=Paint(Paint.ANTI_ALIAS_FLAG);textLayers.forEach{p.color=it.color;p.textSize=it.size;p.typeface=Typeface.DEFAULT_BOLD;c.drawText(it.text,it.x,it.y,p)};return out}
        fun layerNames()=listOf("Base Image")+textLayers.mapIndexed{index,it->"Text $index: ${it.text.take(28)}"}
        fun layersJson():JSONArray{val a=JSONArray();textLayers.forEach{a.put(JSONObject().apply{put("text",it.text);put("x",it.x);put("y",it.y);put("size",it.size);put("color",it.color)})};return a}
        fun restoreLayers(a:JSONArray?){textLayers.clear();if(a!=null)for(i in 0 until a.length()){val o=a.getJSONObject(i);textLayers.add(TextLayer(o.optString("text"),o.optDouble("x",80.0).toFloat(),o.optDouble("y",100.0).toFloat(),o.optDouble("size",54.0).toFloat(),o.optInt("color",Color.WHITE)))};selected=textLayers.lastIndex;invalidate()}
        private fun applyMatrix(cm:ColorMatrix){val b=baseBitmap?:return;snap();val out=Bitmap.createBitmap(b.width,b.height,Bitmap.Config.ARGB_8888);Canvas(out).drawBitmap(b,0f,0f,Paint().apply{colorFilter=ColorMatrixColorFilter(cm)});baseBitmap=out;invalidate()}
        fun adjust(br:Float,con:Float,sat:Float){val cm=ColorMatrix(floatArrayOf(con,0f,0f,0f,br,0f,con,0f,0f,br,0f,0f,con,0f,br,0f,0f,0f,1f,0f));if(sat!=1f){val s=ColorMatrix();s.setSaturation(sat);cm.postConcat(s)};applyMatrix(cm)}
        fun gray(){val c=ColorMatrix();c.setSaturation(0f);applyMatrix(c)};fun warm(){adjust(5f,1.02f,1.08f)};fun cool(){adjust(0f,1.02f,.94f)}
        fun cinematic(){applyMatrix(ColorMatrix(floatArrayOf(1.12f,0f,0f,0f,-7f,0f,1.04f,0f,0f,-3f,0f,0f,.92f,0f,6f,0f,0f,0f,1f,0f)))}
        fun autoEnhance(){val b=baseBitmap?:return;snap();var minV=255;var maxV=0;for(y in 0 until b.height step 4)for(x in 0 until b.width step 4){val p=b.getPixel(x,y);val v=(Color.red(p)+Color.green(p)+Color.blue(p))/3;minV=min(minV,v);maxV=max(maxV,v)};val scale=255f/max(1,maxV-minV);adjust(-minV*scale,scale,1f)}
        fun rotate90(){val b=baseBitmap?:return;snap();baseBitmap=Bitmap.createBitmap(b,0,0,b.width,b.height,Matrix().apply{postRotate(90f)},true);invalidate()};fun flip(){val b=baseBitmap?:return;snap();baseBitmap=Bitmap.createBitmap(b,0,0,b.width,b.height,Matrix().apply{postScale(-1f,1f)},true);invalidate()};fun squareCrop(){cropAspect(1f,1f)}
        fun cropAspect(wRatio:Float,hRatio:Float){val b=baseBitmap?:return;snap();val target=wRatio/hRatio;val current=b.width.toFloat()/b.height.toFloat();if(abs(current-target)<0.001f){invalidate();return};var nw=b.width;var nh=b.height;if(current>target){nw=(b.height*target).roundToInt()}else{nh=(b.width/target).roundToInt()};nw=nw.coerceAtLeast(1).coerceAtMost(b.width);nh=nh.coerceAtLeast(1).coerceAtMost(b.height);baseBitmap=Bitmap.createBitmap(b,(b.width-nw)/2,(b.height-nh)/2,nw,nh);invalidate()}
        fun negative(){val c=ColorMatrix(floatArrayOf(-1f,0f,0f,0f,255f,0f,-1f,0f,0f,255f,0f,0f,-1f,0f,255f,0f,0f,0f,1f,0f));applyMatrix(c)}
        fun sepia(){val c=ColorMatrix(floatArrayOf(.393f,.769f,.189f,0f,0f,.349f,.686f,.168f,0f,0f,.272f,.534f,.131f,0f,0f,0f,0f,0f,1f,0f));applyMatrix(c)}
        fun invert(){negative()}
        fun dehaze(){adjust(8f,1.12f,1.08f)}
        fun poster(){if(textLayers.isEmpty())addText("YOUR TITLE")}
        fun colorDna(){val b=baseBitmap?:return;val sum=LongArray(3);var count=0L;for(y in 0 until b.height step 8)for(x in 0 until b.width step 8){val p=b.getPixel(x,y);sum[0]+=Color.red(p);sum[1]+=Color.green(p);sum[2]+=Color.blue(p);count++};val r=(sum[0]/count).toInt();val g=(sum[1]/count).toInt();val bl=(sum[2]/count).toInt();applyMatrix(ColorMatrix(floatArrayOf(1.05f,0f,0f,0f,(128-r)*.12f,0f,1.05f,0f,0f,(128-g)*.12f,0f,0f,1.05f,0f,(128-bl)*.12f,0f,0f,0f,1f,0f)))}
        fun quickBackgroundCut(){val b=baseBitmap?:return;snap();val out=b.copy(Bitmap.Config.ARGB_8888,true);val edge=Color.red(out.getPixel(0,0))+Color.green(out.getPixel(0,0))+Color.blue(out.getPixel(0,0));val px=IntArray(out.width*out.height);out.getPixels(px,0,out.width,0,0,out.width,out.height);for(i in px.indices){val p=px[i];val s=Color.red(p)+Color.green(p)+Color.blue(p);if(abs(s-edge)<42)px[i]=Color.TRANSPARENT};out.setPixels(px,0,out.width,0,0,out.width,out.height);baseBitmap=out;invalidate()}
        fun pixelate(){val b=baseBitmap?:return;snap();val out=b.copy(Bitmap.Config.ARGB_8888,true);val c=Canvas(out);val p=Paint();val step=max(8,min(24,b.width/50));for(y in 0 until b.height step step)for(x in 0 until b.width step step){p.color=b.getPixel(x,y);c.drawRect(x.toFloat(),y.toFloat(),min((x+step).toFloat(),b.width.toFloat()),min((y+step).toFloat(),b.height.toFloat()),p)};baseBitmap=out;invalidate()}
        fun thermal(){val b=baseBitmap?:return;snap();val out=Bitmap.createBitmap(b.width,b.height,Bitmap.Config.ARGB_8888);val px=IntArray(b.width*b.height);b.getPixels(px,0,b.width,0,0,b.width,b.height);for(i in px.indices){val p=px[i];val v=(.299*Color.red(p)+.587*Color.green(p)+.114*Color.blue(p)).toInt();px[i]=Color.rgb((v*2.2).toInt().coerceIn(0,255),((v-55)*2.5).toInt().coerceIn(0,255),((120-v)*2.1).toInt().coerceIn(0,255))};out.setPixels(px,0,b.width,0,0,b.width,b.height);baseBitmap=out;invalidate()}
        fun edgeSketch(){val b=baseBitmap?:return;snap();val out=Bitmap.createBitmap(b.width,b.height,Bitmap.Config.ARGB_8888);for(y in 1 until b.height-1)for(x in 1 until b.width-1){val a=Color.red(b.getPixel(x-1,y));val d=Color.red(b.getPixel(x+1,y));val u=Color.red(b.getPixel(x,y-1));val v=Color.red(b.getPixel(x,y+1));val e=(abs(a-d)+abs(u-v)).coerceIn(0,255);out.setPixel(x,y,Color.rgb(255-e,255-e,255-e))};baseBitmap=out;invalidate()}
        fun glitch(){val b=baseBitmap?:return;snap();val out=b.copy(Bitmap.Config.ARGB_8888,true);val c=Canvas(out);val p=Paint();for(y in 0 until b.height step 22){p.color=Color.argb(35,255,0,80);c.drawRect(0f,y.toFloat(),b.width.toFloat(),(y+8).toFloat(),p)};baseBitmap=out;invalidate()}
        fun kaleido(){val b=baseBitmap?:return;snap();val n=min(b.width,b.height);val src=Bitmap.createBitmap(b,(b.width-n)/2,(b.height-n)/2,n,n);val out=Bitmap.createBitmap(n*2,n*2,Bitmap.Config.ARGB_8888);val c=Canvas(out);val p=Paint(Paint.ANTI_ALIAS_FLAG);c.drawBitmap(src,null,RectF(0f,0f,n.toFloat(),n.toFloat()),p);c.save();c.scale(-1f,1f,n.toFloat(),n.toFloat()/2);c.drawBitmap(src,null,RectF(0f,0f,n.toFloat(),n.toFloat()),p);c.restore();c.save();c.scale(1f,-1f,n.toFloat(),n.toFloat());c.drawBitmap(src,null,RectF(0f,0f,n.toFloat(),n.toFloat()),p);c.restore();c.save();c.scale(-1f,-1f,n.toFloat(),n.toFloat());c.drawBitmap(src,null,RectF(0f,0f,n.toFloat(),n.toFloat()),p);c.restore();baseBitmap=out;invalidate()}
        fun relight(){val b=baseBitmap?:return;snap();val out=b.copy(Bitmap.Config.ARGB_8888,true);val c=Canvas(out);val p=Paint(Paint.ANTI_ALIAS_FLAG);p.shader=RadialGradient(b.width*.25f,b.height*.22f,b.width*.8f,Color.argb(110,255,235,190),Color.TRANSPARENT,Shader.TileMode.CLAMP);p.xfermode=PorterDuffXfermode(PorterDuff.Mode.SCREEN);c.drawRect(0f,0f,b.width.toFloat(),b.height.toFloat(),p);baseBitmap=out;invalidate()}
        fun vignette(){val b=baseBitmap?:return;snap();val out=b.copy(Bitmap.Config.ARGB_8888,true);val c=Canvas(out);val p=Paint();p.shader=RadialGradient(b.width/2f,b.height/2f,min(b.width,b.height)*.72f,Color.TRANSPARENT,Color.argb(180,0,0,0),Shader.TileMode.CLAMP);c.drawRect(0f,0f,b.width.toFloat(),b.height.toFloat(),p);baseBitmap=out;invalidate()}
        fun grain(){val b=baseBitmap?:return;snap();val out=b.copy(Bitmap.Config.ARGB_8888,true);val px=IntArray(b.width*b.height);out.getPixels(px,0,b.width,0,0,b.width,b.height);val rnd=Random(4);for(i in px.indices){val n=rnd.nextInt(31)-15;px[i]=Color.rgb((Color.red(px[i])+n).coerceIn(0,255),(Color.green(px[i])+n).coerceIn(0,255),(Color.blue(px[i])+n).coerceIn(0,255))};out.setPixels(px,0,b.width,0,0,b.width,b.height);baseBitmap=out;invalidate()}
        fun ghost(){val b=baseBitmap?:return;snap();val out=b.copy(Bitmap.Config.ARGB_8888,true);val c=Canvas(out);val p=Paint(Paint.ANTI_ALIAS_FLAG);p.alpha=80;c.drawBitmap(b,Matrix().apply{postTranslate(b.width*.035f,b.height*.01f)},p);baseBitmap=out;invalidate()}
    }
}
