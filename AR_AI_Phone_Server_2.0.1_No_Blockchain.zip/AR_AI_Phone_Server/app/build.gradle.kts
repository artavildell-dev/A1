plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.arai.offline"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.arai.offline"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "2.0.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
