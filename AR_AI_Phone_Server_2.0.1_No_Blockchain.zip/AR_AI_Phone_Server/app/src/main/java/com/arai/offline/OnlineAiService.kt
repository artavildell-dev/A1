package com.arai.offline

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** OpenAI-compatible online chat. Endpoint, model and key are user-configurable. */
object OnlineAiService {
    fun complete(endpoint: String, model: String, apiKey: String, system: String, user: String): String {
        require(apiKey.isNotBlank()) { "کلید API تنظیم نشده است. برای تنظیم، روی عنوان AR.AI چند لحظه نگه دارید." }
        val base = endpoint.trim().trimEnd('/')
        val url = if (base.endsWith("/chat/completions")) base else "$base/chat/completions"
        val body = JSONObject().put("model", model.trim().ifBlank { "gpt-4o-mini" })
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", system))
                .put(JSONObject().put("role", "user").put("content", user)))
            .put("temperature", 0.4)
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000; doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("سرویس آنلاین HTTP $code: ${raw.take(500)}")
            val root = JSONObject(raw)
            val content = root.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty()
            return content.ifBlank { "سرویس آنلاین پاسخ متنی برنگرداند." }
        } finally { conn.disconnect() }
    }
}
