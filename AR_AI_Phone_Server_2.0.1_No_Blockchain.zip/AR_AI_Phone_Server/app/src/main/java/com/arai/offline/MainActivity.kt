package com.arai.offline

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.InputType
import java.io.File
import java.io.FileOutputStream
import java.net.URLEncoder

class MainActivity : Activity() {
    private val bg = Color.rgb(3, 7, 22)
    private val cyan = Color.rgb(0, 220, 255)
    private val purple = Color.rgb(163, 57, 255)
    private val white = Color.rgb(242, 247, 255)
    private lateinit var root: LinearLayout
    private lateinit var messages: LinearLayout
    private lateinit var input: EditText
    private val history = mutableListOf<Pair<String, String>>()
    private val prefs by lazy { getSharedPreferences("arai_chat", MODE_PRIVATE) }
    private val learningPrefs by lazy { getSharedPreferences("arai_learning", MODE_PRIVATE) }
    private fun learnedFacts(): MutableList<String> = (learningPrefs.getString("facts", "") ?: "").split("\n").filter { it.isNotBlank() }.toMutableList()
    private var selectedFileName: String? = null
    private var selectedFileText: String? = null
    private val onlinePrefs by lazy { getSharedPreferences("arai_online", MODE_PRIVATE) }

    private fun loadHistory() {
        if (history.isNotEmpty()) return
        val raw = prefs.getString("history", null) ?: return
        raw.split("\n---ARAI---\n").forEach { item ->
            val idx = item.indexOf("\t")
            if (idx > 0) history.add(item.substring(0, idx) to item.substring(idx + 1))
        }
    }
    private fun saveHistory() {
        prefs.edit().putString("history", history.joinToString("\n---ARAI---\n") { it.first + "\t" + it.second }).apply()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun shape(stroke: Int = cyan, radius: Int = 18): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(10, 28, 65), Color.rgb(18, 10, 48))).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), stroke)
        }
    private fun label(s: String, size: Float, color: Int = white, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(dp(7), dp(6), dp(7), dp(6))
        }
    private fun btn(s: String, action: () -> Unit) = Button(this).apply {
        text = s; textSize = 15f; isAllCaps = false; setTextColor(white)
        background = shape(purple, 25); setOnClickListener { action() }
    }
    private fun newRoot() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
        setPadding(dp(16), dp(12), dp(16), dp(12))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LocalPhoneServer.start()
        loadHistory()
        showChat()
    }

    private fun showSplash() {
        root = newRoot()
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(label("◉", 64f, cyan, true), LinearLayout.LayoutParams(-1, dp(100)))
        root.addView(label("AR.AI", 46f, white, true))
        root.addView(label("OFFLINE  •  هوش مصنوعی آفلاین", 14f, cyan, true))
        root.addView(label("دستیار هوشمند چندمنظوره", 21f, white, true))
        root.addView(label("گفت‌وگو • کدنویسی • دانش • فایل • تصویر • ترجمه", 13f, Color.LTGRAY))
        val filler = View(this)
        root.addView(filler, LinearLayout.LayoutParams(1, 0, 1f))
        val features = listOf(
            "◈ گفت‌وگو و استدلال" to "⌘ کدنویسی و توسعه",
            "▧ تحلیل تصویر و OCR" to "▤ فایل‌ها و اسناد",
            "文 ترجمه چندزبانه" to "♫ ابزارهای صوتی"
        )
        features.forEach { (a, b) ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            listOf(a, b).forEach { v ->
                row.addView(label(v, 14f, white, true).apply { background = shape() },
                    LinearLayout.LayoutParams(0, dp(66), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
            root.addView(row)
        }
        root.addView(btn("شروع  →") { showChat() }, LinearLayout.LayoutParams(-1, dp(58)).apply {
            setMargins(dp(3), dp(20), dp(3), dp(10))
        })
        root.addView(label("یادگیری با اجازهٔ شما • حافظهٔ محلی و قابل حذف", 11f, Color.LTGRAY))
        setContentView(root)
    }

    private fun showChat() {
        root = newRoot()
        val top = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        top.addView(label("AR.AI", 30f, cyan, true).apply { setOnLongClickListener { showOnlineSettings(); true } })
        top.addView(label("دستیار هوشمند آنلاین • برای تنظیم اتصال، عنوان را نگه دارید", 12f, Color.LTGRAY))
        root.addView(top)
        val scroller = ScrollView(this)
        messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(8)) }
        scroller.addView(messages)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        if (history.isEmpty()) addBubble("AR.AI", "سلام! هر کاری لازم داری با زبان عادی بنویس. برای پاسخ هوشمند آنلاین، یک سرویس سازگار با OpenAI و کلید API لازم است. برای تنظیم، عنوان AR.AI را چند لحظه نگه دار.")
        else history.forEach { addBubble(it.first, it.second) }
        scroller.post { scroller.fullScroll(View.FOCUS_DOWN) }
        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = shape(cyan, 28); setPadding(dp(5), dp(4), dp(5), dp(4))
        }
        input = EditText(this).apply {
            hint = "درخواستت را بنویس…"; setHintTextColor(Color.GRAY); setTextColor(white); textSize = 16f
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            maxLines = 4; background = null; setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnEditorActionListener { _, _, _ -> send(); true }
        }
        composer.addView(input, LinearLayout.LayoutParams(0, dp(54), 1f))
        composer.addView(btn("➤") { send() }, LinearLayout.LayoutParams(dp(54), dp(54)))
        root.addView(composer, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(8), 0, dp(4)) })
        setContentView(root)
    }


    /** In-app research workflow: retrieve public web sources, then synthesize them instead of opening a browser. */
    private fun showWebResearch() {
        root = newRoot()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("جست‌وجو و تحلیل وب", 21f, cyan, true), LinearLayout.LayoutParams(0, dp(56), 1f))
        top.addView(btn("بازگشت") { showChat() })
        root.addView(top)
        root.addView(label("موضوع را وارد کن؛ AR.AI منابع را پیدا می‌کند، نکات را جمع‌بندی می‌کند و لینک منابع را نشان می‌دهد. این صفحه مرورگر نیست.", 13f, white))
        val query = EditText(this).apply {
            hint = "مثلاً: بهترین کتابخانه‌های متن‌باز تحلیل داده در اندروید"
            setHintTextColor(Color.GRAY); setTextColor(white); textSize = 15f
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL; minLines = 2; background = shape(cyan, 18)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        root.addView(query, LinearLayout.LayoutParams(-1, dp(82)).apply { setMargins(0, dp(8), 0, dp(8)) })
        val output = TextView(this).apply {
            text = "منابع جست‌وجو: Wikipedia، GitHub و Stack Exchange؛ بسته به موضوع ممکن است بعضی منابع نتیجه‌ای نداشته باشند. تحلیل عمیق‌تر با مدل محلی بارگذاری‌شده انجام می‌شود."
            setTextColor(white); textSize = 14f; gravity = Gravity.RIGHT; setPadding(dp(12), dp(12), dp(12), dp(12))
            background = shape(); setTextIsSelectable(true)
        }
        val scroll = ScrollView(this); scroll.addView(output)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(btn("جست‌وجو، تحلیل و ارائهٔ نتیجه") {
            val q = query.text.toString().trim()
            if (q.length < 2) { Toast.makeText(this, "موضوع جست‌وجو را وارد کن", Toast.LENGTH_SHORT).show(); return@btn }
            output.text = "در حال جست‌وجوی وب و بررسی منابع…"
            Thread {
                val result = try {
                    val sources = ResearchService.search(q)
                    if (sources.isEmpty()) "نتیجهٔ قابل استفاده‌ای از منابع پشتیبانی‌شده پیدا نشد. عبارت دیگری امتحان کن." else {
                        val raw = sources.joinToString("\n\n") { "عنوان: ${it.title}\nخلاصه: ${it.snippet}\nمنبع: ${it.url}" }
                        val analysis = try {
                            OnlineAiService.complete(
                                onlinePrefs.getString("endpoint", "https://api.openai.com/v1") ?: "https://api.openai.com/v1",
                                onlinePrefs.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini",
                                onlinePrefs.getString("key", "") ?: "",
                                "تو دستیار پژوهشگر AR.AI هستی. فارسی پاسخ بده، منابع را ترکیب و مقایسه کن، واقعیت را از عدم قطعیت جدا کن، محدودیت‌ها را بگو و منبع جدید جعل نکن.",
                                "پرسش: $q\nمنابع بازیابی‌شده:\n$raw\nخلاصه، تحلیل، نتیجهٔ کاربردی، محدودیت‌ها را بنویس."
                            )
                        } catch (e: Exception) { "تحلیل آنلاین ناموفق بود: ${e.message ?: "خطای نامشخص"}\n\nخلاصهٔ منابع:\n${sources.joinToString("\n\n") { it.title + ": " + it.snippet }}" }
                        analysis + "\n\nمنابع بازیابی‌شده:\n" + sources.joinToString("\n") { "• ${it.title} — ${it.url}" }
                    }
                } catch (e: Exception) { "جست‌وجوی اینترنتی ناموفق بود: ${e.message ?: "اتصال را بررسی کن"}. اگر اینترنت وصل است، بعداً دوباره تلاش کن." }
                runOnUiThread {
                    output.text = result
                    history.add("شما" to "جست‌وجوی وب: $q")
                    history.add("AR.AI — پژوهش" to result.take(12000))
                    saveHistory()
                }
            }.start()
        }, LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(0, dp(8), 0, dp(4)) })
        setContentView(root)
    }

    private fun showCapabilityCatalog() {
        root = newRoot()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("نقشهٔ ۱۲۰ قابلیت AR.AI", 21f, cyan, true), LinearLayout.LayoutParams(0, dp(56), 1f))
        top.addView(btn("بازگشت") { showChat() })
        root.addView(top)
        root.addView(label("وضعیت واقعی پروژه؛ نام قابلیت در فهرست به‌تنهایی به معنی پیاده‌سازی نیست. «آمادهٔ پایه» یعنی کد فعلی وجود دارد؛ «ناقص» نیازمند توسعه/آزمایش؛ «برنامه‌ریزی‌شده» هنوز پیاده‌سازی نشده.", 12f, Color.LTGRAY))
        val all = CapabilityCatalog.items
        val implemented = all.count { it.status == "آمادهٔ پایه" }
        val partial = all.count { it.status == "ناقص" }
        val planned = all.count { it.status == "برنامه‌ریزی‌شده" }
        root.addView(label("مجموع: ${all.size}  •  آمادهٔ پایه: $implemented  •  ناقص: $partial  •  برنامه‌ریزی‌شده: $planned", 14f, cyan, true))
        val filter = Spinner(this)
        val opts = listOf("همهٔ قابلیت‌ها", "آمادهٔ پایه", "ناقص", "برنامه‌ریزی‌شده")
        filter.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, opts)
        root.addView(filter)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        fun populate() {
            list.removeAllViews()
            val selected = filter.selectedItem?.toString() ?: opts[0]
            all.filter { selected == opts[0] || it.status == selected }.forEach { item ->
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; background = shape(
                        when(item.status) { "آمادهٔ پایه" -> cyan; "ناقص" -> Color.rgb(255, 185, 50); else -> Color.GRAY }, 14
                    ); setPadding(dp(10), dp(7), dp(10), dp(7))
                }
                card.addView(label("${item.id}. ${item.title}", 14f, white, true).apply { gravity = Gravity.RIGHT })
                card.addView(label("${item.group} • ${item.status}", 11f,
                    when(item.status) { "آمادهٔ پایه" -> cyan; "ناقص" -> Color.rgb(255, 185, 50); else -> Color.LTGRAY }, true).apply { gravity = Gravity.RIGHT })
                card.addView(label(item.note, 12f, Color.LTGRAY).apply { gravity = Gravity.RIGHT })
                list.addView(card, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(4), 0, dp(4)) })
            }
        }
        filter.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) = populate()
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        root.addView(btn("گزارش کامل وضعیت قابلیت‌ها") {
            val report = all.joinToString("\n") { "${it.id}. [${it.status}] ${it.title} — ${it.note}" }
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "گزارش قابلیت‌های AR.AI"); putExtra(Intent.EXTRA_TEXT, report)
            }
            startActivity(Intent.createChooser(intent, "اشتراک گزارش"))
        }, LinearLayout.LayoutParams(-1, dp(48)).apply { setMargins(0, dp(8), 0, 0) })
        setContentView(root)
    }

    private var pendingExportText: String = ""


    /** Deterministic on-device utilities that do not depend on an LLM. */
    private fun showTools() {
        root = newRoot()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("مرکز ابزارهای AR.AI", 21f, cyan, true), LinearLayout.LayoutParams(0, dp(54), 1f))
        top.addView(btn("بازگشت") { showChat() })
        root.addView(top)
        root.addView(label("ابزارهای قطعی روی گوشی؛ این بخش بدون اینترنت و بدون مدل هم کار می‌کند.", 12f, Color.LTGRAY))
        val field = EditText(this).apply {
            hint = "متن، اعداد، CSV یا مقدار تبدیل را وارد کن…"
            setHintTextColor(Color.GRAY); setTextColor(white); textSize = 15f
            gravity = Gravity.RIGHT or Gravity.TOP; minLines = 3; background = shape(cyan, 18)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        root.addView(field, LinearLayout.LayoutParams(-1, dp(112)).apply { setMargins(0, dp(8), 0, dp(8)) })
        val output = TextView(this).apply {
            text = "نتیجه در اینجا نمایش داده می‌شود."; setTextColor(white); textSize = 14f
            gravity = Gravity.RIGHT or Gravity.TOP; setPadding(dp(12), dp(12), dp(12), dp(12)); background = shape(); setTextIsSelectable(true)
        }
        val scroll = ScrollView(this); scroll.addView(output)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        fun runTool(name: String, fn: (String) -> String) {
            val raw = field.text.toString()
            output.text = try { fn(raw) } catch (e: Exception) { "ورودی قابل پردازش نیست: ${e.message ?: "خطای نامشخص"}" }
            prefs.edit().putString("last_tool_output", output.text.toString()).apply()
        }
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun addRow(vararg pair: Pair<String, () -> Unit>) {
            val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { (title, action) -> row.addView(btn(title, action), LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }) }
            grid.addView(row)
        }
        addRow("شمارش متن" to { runTool("شمارش") { t -> "تعداد نویسه: ${t.length}\nتعداد نویسه بدون فاصله: ${t.count { !it.isWhitespace() }}\nتعداد واژه: ${t.trim().split(Regex("\\s+")).count { it.isNotBlank() }}\nتعداد خط: ${if (t.isEmpty()) 0 else t.lines().size}" } },
            "مرتب‌سازی خطوط" to { runTool("مرتب‌سازی") { t -> t.lines().filter { it.isNotBlank() }.distinct().sorted().joinToString("\n") } })
        addRow("حذف فاصله‌های اضافی" to { runTool("پاک‌سازی متن") { t -> t.lines().joinToString("\n") { it.trim().replace(Regex("\\s+"), " ") }.trim() } },
            "حروف بزرگ/کوچک" to { runTool("تغییر حروف") { t -> if (t.any { it.isLetter() && it.isLowerCase() }) t.uppercase() else t.lowercase() } })
        addRow("تحلیل CSV" to { runTool("CSV") { t ->
            val lines = t.lines().filter { it.isNotBlank() }
            if (lines.isEmpty()) "یک متن CSV وارد کن." else {
                val rows = lines.map { it.split(',') }; val cols = rows.maxOf { it.size }
                val report = StringBuilder("ردیف‌ها: ${rows.size}\nبیشترین ستون: $cols\n")
                for (c in 0 until cols) {
                    val nums = rows.mapNotNull { it.getOrNull(c)?.trim()?.replace("\"", "")?.toDoubleOrNull() }
                    if (nums.isNotEmpty()) report.append("ستون ${c+1}: تعداد عدد=${nums.size}، مجموع=${nums.sum()}، میانگین=${nums.average()}، کمینه=${nums.minOrNull()}، بیشینه=${nums.maxOrNull()}\n")
                }
                report.toString()
            }
        } }, "تشخیص تقریبی زبان" to { runTool("زبان") { t ->
            when { t.any { it in '\u0600'..'\u06FF' } -> "احتمالاً فارسی/عربی؛ تشخیص دقیق‌تر به موتور زبان نیاز دارد."; t.any { it in 'а'..'я' || it in 'А'..'Я' } -> "احتمالاً روسی/سیریلیک."; t.any { it in 'a'..'z' || it in 'A'..'Z' } -> "متن دارای حروف لاتین است؛ زبان دقیق تضمین نمی‌شود."; else -> "برای تشخیص زبان، متن بیشتری وارد کن." }
        } })
        addRow("تبدیل واحد" to { runTool("واحد") { t ->
            val m = Regex("^\\s*(-?\\d+(?:\\.\\d+)?)\\s*(km|mi|m|cm|kg|lb|c|f)\\s*$", RegexOption.IGNORE_CASE).find(t)
                ?: return@runTool "قالب نمونه: 12 km یا 5 lb یا 20 C. واحدهای پشتیبانی‌شده: km, mi, m, cm, kg, lb, C, F."
            val v = m.groupValues[1].toDouble(); val u = m.groupValues[2].lowercase()
            when(u) { "km" -> "$v km = ${v*0.621371} mi"; "mi" -> "$v mi = ${v/0.621371} km"; "m" -> "$v m = ${v*100} cm"; "cm" -> "$v cm = ${v/100} m"; "kg" -> "$v kg = ${v*2.20462262} lb"; "lb" -> "$v lb = ${v/2.20462262} kg"; "c" -> "$v °C = ${(v*9/5)+32} °F"; else -> "$v °F = ${(v-32)*5/9} °C" }
        } }, "ذخیره خروجی" to {
            val txt = output.text.toString()
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/plain"; putExtra(Intent.EXTRA_TITLE, "arai-output.txt") }
            pendingExportText = txt; startActivityForResult(i, 42)
        })
        addRow("افزودن کار به فهرست" to { val t = field.text.toString().trim(); if (t.isNotEmpty()) { val tasks = prefs.getString("tasks", "") ?: ""; prefs.edit().putString("tasks", (tasks.lines().filter { it.isNotBlank() } + "[ ] $t").takeLast(200).joinToString("\n")).apply(); output.text = "کار ذخیره شد: $t" } },
            "نمایش فهرست کارها" to { output.text = (prefs.getString("tasks", "") ?: "").ifBlank { "هنوز کاری ذخیره نشده است." } })
        root.addView(grid)
        root.addView(btn("بازگشت به گفتگو") { showChat() }, LinearLayout.LayoutParams(-1, dp(46)).apply { setMargins(0, dp(6), 0, 0) })
        setContentView(root)
    }

    private fun showLearning() {
        root = newRoot()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("حافظه و یادگیری AR.AI", 21f, cyan, true), LinearLayout.LayoutParams(0, dp(58), 1f))
        top.addView(btn("بازگشت") { showChat() })
        root.addView(top)
        root.addView(label("چیزهایی را که می‌خواهی دستیار در گفت‌وگوهای بعدی به خاطر بسپارد، خودت اضافه کن. این حافظه روی همین گوشی ذخیره می‌شود و مدل را دوباره آموزش نمی‌دهد.", 14f, white))
        val field = EditText(this).apply {
            hint = "مثلاً: پاسخ‌ها را فارسی و ساده بنویس…"
            setHintTextColor(Color.GRAY); setTextColor(white); textSize = 16f
            gravity = Gravity.RIGHT or Gravity.TOP; minLines = 3; background = shape(cyan, 18)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        root.addView(field, LinearLayout.LayoutParams(-1, dp(120)).apply { setMargins(0, dp(12), 0, dp(8)) })
        root.addView(btn("ذخیره در حافظهٔ محلی") {
            val fact = field.text.toString().trim()
            if (fact.isNotEmpty()) {
                val facts = learnedFacts()
                if (!facts.contains(fact)) facts.add(fact)
                learningPrefs.edit().putString("facts", facts.takeLast(100).joinToString("\n")).apply()
                Toast.makeText(this, "در حافظهٔ محلی ذخیره شد", Toast.LENGTH_SHORT).show()
                showLearning()
            }
        }, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(label("موارد ذخیره‌شده (${learnedFacts().size}/100)", 16f, cyan, true))
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        learnedFacts().forEachIndexed { i, fact ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = shape(); setPadding(dp(6), dp(4), dp(6), dp(4)) }
            row.addView(label(fact, 13f, white), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(btn("حذف") {
                val facts = learnedFacts(); if (i in facts.indices) facts.removeAt(i)
                learningPrefs.edit().putString("facts", facts.joinToString("\n")).apply(); showLearning()
            })
            list.addView(row, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(4), 0, dp(4)) })
        }
        root.addView(btn("پاک‌کردن تمام حافظه") {
            learningPrefs.edit().remove("facts").apply(); showLearning()
        }, LinearLayout.LayoutParams(-1, dp(48)))
        setContentView(root)
    }

    private fun showHistory() {
        root = newRoot()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("تاریخچه گفتگو", 22f, cyan, true), LinearLayout.LayoutParams(0, dp(56), 1f))
        top.addView(btn("بازگشت") { showChat() })
        root.addView(top)
        root.addView(label("پیام‌های ذخیره‌شده روی همین دستگاه", 12f, Color.LTGRAY))
        val scroller = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroller.addView(list)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        if (history.isEmpty()) list.addView(label("هنوز گفت‌وگویی ذخیره نشده است.", 16f))
        history.forEachIndexed { index, item ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = shape(if (item.first == "شما") purple else cyan); setPadding(dp(8), dp(4), dp(8), dp(4)) }
            row.addView(label("${index + 1}. ${item.first}", 12f, cyan, true))
            row.addView(label(item.second, 14f, white))
            list.addView(row, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(4), 0, dp(4)) })
        }
        root.addView(btn("پاک‌کردن همه تاریخچه") {
            history.clear(); saveHistory(); selectedFileName = null; showHistory()
        }, LinearLayout.LayoutParams(-1, dp(50)))
        setContentView(root)
    }

    private fun addBubble(who: String, body: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = shape(if (who == "شما") purple else cyan)
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        box.addView(label(who, 12f, cyan, true))
        box.addView(label(body, 15f, white).apply { gravity = if (who == "شما") Gravity.RIGHT else Gravity.RIGHT })
        messages.addView(box, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, dp(5), 0, dp(5))
        })
    }
    private fun send() {
        val typed = input.text.toString().trim()
        if (typed.isEmpty()) return
        input.setText("")
        history.add("شما" to typed)
        history.add("AR.AI" to "در حال بررسی درخواست…")
        saveHistory(); showChat()
        Thread {
            val answer = try {
                routePrompt(typed)
            } catch (e: Exception) {
                "اجرای درخواست با خطا روبه‌رو شد: ${e.message ?: "خطای نامشخص"}"
            }
            runOnUiThread {
                if (history.isNotEmpty() && history.last().second == "در حال بررسی درخواست…") history.removeAt(history.lastIndex)
                history.add("AR.AI" to answer.trim().ifEmpty { "پاسخی تولید نشد. درخواست را واضح‌تر بنویس." })
                saveHistory(); showChat()
            }
        }.start()
    }

    /** Prompt-first router: capabilities are inferred from ordinary language, never exposed as tool buttons. */
    private fun routePrompt(userText: String): String {
        val q = userText.lowercase()
        val memory = learnedFacts().takeLast(20).joinToString("\n- ")
        if (listOf("تعداد کلمه", "شمارش کلمات", "تعداد واژه", "count words").any { q.contains(it) }) {
            val text = userText.substringAfter(":", userText).trim()
            return "تعداد واژه: ${text.split(Regex("\\s+")).count { it.isNotBlank() }}\nتعداد نویسه: ${text.length}\nتعداد خط: ${if (text.isEmpty()) 0 else text.lines().size}"
        }
        if (listOf("تبدیل واحد", "تبدیل کن", "convert units").any { q.contains(it) }) {
            val m = Regex("(-?\\d+(?:\\.\\d+)?)\\s*(km|mi|m|cm|kg|lb|c|f)\\b", RegexOption.IGNORE_CASE).find(userText)
            if (m != null) {
                val v=m.groupValues[1].toDouble(); val u=m.groupValues[2].lowercase()
                return when(u) { "km" -> "$v کیلومتر = ${v*0.621371} مایل"; "mi" -> "$v مایل = ${v/0.621371} کیلومتر"; "m" -> "$v متر = ${v*100} سانتی‌متر"; "cm" -> "$v سانتی‌متر = ${v/100} متر"; "kg" -> "$v کیلوگرم = ${v*2.20462262} پوند"; "lb" -> "$v پوند = ${v/2.20462262} کیلوگرم"; "c" -> "$v درجهٔ سانتی‌گراد = ${(v*9/5)+32} فارنهایت"; else -> "$v فارنهایت = ${(v-32)*5/9} سانتی‌گراد" }
            }
        }
        if (!isNetworkAvailable()) return "برای پاسخ هوشمند آنلاین اتصال اینترنت در دسترس نیست. اینترنت را بررسی کن و دوباره پیام بده."
        val endpoint = onlinePrefs.getString("endpoint", "https://api.openai.com/v1") ?: "https://api.openai.com/v1"
        val model = onlinePrefs.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini"
        val key = onlinePrefs.getString("key", "") ?: ""
        var prompt = userText
        if (selectedFileText != null) prompt += "\n\nمحتوای فایل انتخاب‌شده ($selectedFileName):\n${selectedFileText!!.take(80000)}"
        val researchIntent = listOf("جستجو کن", "در وب بگرد", "منابع اینترنتی", "تحقیق کن درباره", "آخرین اخبار", "search the web", "web research", "در اینترنت").any { q.contains(it) }
        if (researchIntent) {
            val sources = ResearchService.search(userText)
            if (sources.isNotEmpty()) prompt += "\n\nمنابع وب بازیابی‌شده (به این منابع استناد کن و URL نساز):\n" + sources.joinToString("\n\n") { "عنوان: ${it.title}\nمحتوا: ${it.snippet}\nURL: ${it.url}" }
        }
        val system = "تو AR.AI هستی، دستیار هوشمند چندمنظوره. به زبان کاربر پاسخ بده و درخواست را از متن طبیعی بفهم؛ منوی ابزار لازم نیست. در نوشتن، ترجمه، خلاصه‌سازی، برنامه‌نویسی، اشکال‌زدایی، برنامه‌ریزی و تحلیل داده کمک کن. صادق باش؛ هرگز ادعا نکن کاری را اجرا یا فایلی را خوانده‌ای مگر واقعاً داده شده باشد. اگر منابع وب همراه پیام آمده‌اند فقط به شواهد آن‌ها استناد کن و عدم قطعیت را مشخص کن. حافظهٔ مجاز کاربر:\n$memory"
        return try { LocalPhoneServer.chat(endpoint, model, key, system, prompt) + if (researchIntent) "\n\nمنابع وب:\n" + (ResearchService.search(userText).take(10).joinToString("\n") { "• ${it.title}: ${it.url}" }) else "" }
        catch (e: Exception) { "پاسخ آنلاین آماده نشد: ${e.message ?: "خطای اتصال"}\n\nبرای تنظیم یا اصلاح نشانی سرویس و کلید API، عنوان AR.AI را چند لحظه نگه دار. متن درخواستت در برنامه باقی مانده است." }
    }

    private fun showOnlineSettings() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        val endpoint = EditText(this).apply { hint = "نشانی API، پیش‌فرض https://api.openai.com/v1"; setSingleLine(true); setText(onlinePrefs.getString("endpoint", "https://api.openai.com/v1")) }
        val model = EditText(this).apply { hint = "نام مدل، پیش‌فرض gpt-4o-mini"; setSingleLine(true); setText(onlinePrefs.getString("model", "gpt-4o-mini")) }
        val key = EditText(this).apply { hint = "کلید API (روی دستگاه ذخیره می‌شود)"; setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setText(onlinePrefs.getString("key", "")) }
        panel.addView(label("تنظیم سرویس هوش مصنوعی آنلاین", 18f, cyan, true)); panel.addView(endpoint); panel.addView(model); panel.addView(key)
        android.app.AlertDialog.Builder(this).setTitle("اتصال آنلاین AR.AI").setView(panel)
            .setPositiveButton("ذخیره") { _, _ ->
                val e = endpoint.text.toString().trim().ifBlank { "https://api.openai.com/v1" }
                if (!e.startsWith("https://")) { Toast.makeText(this, "برای امنیت از نشانی HTTPS استفاده کن.", Toast.LENGTH_LONG).show(); return@setPositiveButton }
                onlinePrefs.edit().putString("endpoint", e).putString("model", model.text.toString().trim().ifBlank { "gpt-4o-mini" }).putString("key", key.text.toString().trim()).apply()
                Toast.makeText(this, "تنظیمات اتصال ذخیره شد.", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("لغو", null).show()
    }

    private fun isNetworkAvailable(): Boolean {
        return try {
            val cm = getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            cm.activeNetwork != null && cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        } catch (_: Exception) { false }
    }
    private fun chooseModel() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/octet-stream" }
        startActivityForResult(i, 41)
    }
    private fun chooseFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        startActivityForResult(i, 40)
    }
    @Deprecated("Deprecated in Android API, retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) try {
                contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(pendingExportText) }
                Toast.makeText(this, "خروجی ذخیره شد.", Toast.LENGTH_LONG).show()
            } catch (e: Exception) { Toast.makeText(this, "ذخیره ناموفق: ${e.message}", Toast.LENGTH_LONG).show() }
            return
        }
        if (requestCode == 40 && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            uri?.let {
                selectedFileName = it.lastPathSegment?.substringAfterLast('/') ?: "فایل انتخاب‌شده"
                selectedFileText = null
                try {
                    val name = selectedFileName.orEmpty().lowercase()
                    val supported = listOf(".txt", ".md", ".csv", ".json", ".xml", ".kt", ".java", ".py", ".html", ".css", ".js", ".yml", ".yaml", ".log")
                    if (supported.any { name.endsWith(it) }) {
                        contentResolver.openInputStream(it)?.bufferedReader(Charsets.UTF_8)?.use { reader ->
                            selectedFileText = reader.readText().take(120000)
                        }
                    }
                } catch (_: Exception) { selectedFileText = null }
                val msg = if (selectedFileText != null)
                    "متن فایل خوانده شد (${selectedFileText!!.length} نویسه). پیام بعدی همراه محتوای فایل برای تحلیل آنلاین همراه درخواست بعدی فرستاده می‌شود."
                else "فایل انتخاب شد، اما پیش‌نمایش متنی آن پشتیبانی نشد. فعلاً فایل‌های متنی، کد، CSV، JSON و لاگ خوانده می‌شوند."
                history.add("شما" to "فایل انتخاب شد: $selectedFileName")
                history.add("AR.AI" to msg)
                saveHistory()
                showChat()
            }
        }
    }
}
