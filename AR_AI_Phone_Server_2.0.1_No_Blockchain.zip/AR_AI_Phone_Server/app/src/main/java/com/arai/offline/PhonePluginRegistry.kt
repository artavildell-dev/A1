package com.arai.offline

/** Small, explicit registry: entries describe real local or online adapters, not pretend implementations. */
data class PhonePlugin(val id: String, val title: String, val mode: String, val status: String, val description: String)
object PhonePluginRegistry {
    val plugins = listOf(
        PhonePlugin("chat", "گفت‌وگوی هوشمند", "online", "READY_WITH_API_KEY", "ارسال درخواست به مدل آنلاین پیکربندی‌شده از طریق سرور محلی گوشی."),
        PhonePlugin("web-research", "جست‌وجوی وب", "online", "BASIC_ADAPTER", "بازیابی وب موجود در پروژه؛ نتایج باید بررسی شوند و پوشش جست‌وجو تضمین نیست."),
        PhonePlugin("file-context", "تحلیل متن فایل", "local", "LIMITED", "متن فایل انتخاب‌شده را به درخواست اضافه می‌کند؛ OCR و همه قالب‌ها پشتیبانی نشده‌اند."),
        PhonePlugin("conversation-history", "تاریخچه مکالمه", "local", "BASIC", "تاریخچه محلی برنامه."),
        PhonePlugin("external-tools", "افزونه‌های خارجی", "online", "PLANNED", "برای اتصال واقعی به MCP یا API شخص ثالث نیازمند تنظیمات و مجوز جداگانه است.")
    )
    fun asJson() = org.json.JSONArray().apply { plugins.forEach { p -> put(org.json.JSONObject().put("id",p.id).put("title",p.title).put("mode",p.mode).put("status",p.status).put("description",p.description)) } }
}
