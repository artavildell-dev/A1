package com.arai.offline

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

/** Small, keyless public-source research connector. Results are synthesized by the app, not shown as a browser page. */
data class ResearchSource(val title: String, val snippet: String, val url: String)

object ResearchService {
    private fun get(url: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection)
        connection.connectTimeout = 9000
        connection.readTimeout = 12000
        connection.setRequestProperty("User-Agent", "ARAI-Android-Research/1.0 (public-source research assistant)")
        connection.setRequestProperty("Accept", "application/json")
        return try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            body
        } finally { connection.disconnect() }
    }
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun search(query: String): List<ResearchSource> {
        val results = mutableListOf<ResearchSource>()
        val q = enc(query)
        // Wikipedia OpenSearch + REST summary
        try {
            val json = JSONArray(get("https://en.wikipedia.org/w/api.php?action=opensearch&search=$q&limit=4&namespace=0&format=json"))
            val titles = json.optJSONArray(1) ?: JSONArray()
            val snippets = json.optJSONArray(2) ?: JSONArray()
            val urls = json.optJSONArray(3) ?: JSONArray()
            for (i in 0 until titles.length()) {
                val title = titles.optString(i)
                var snippet = snippets.optString(i)
                var url = urls.optString(i)
                try {
                    val page = JSONObject(get("https://en.wikipedia.org/api/rest_v1/page/summary/${enc(title).replace("+", "%20")}"))
                    snippet = page.optString("extract", snippet)
                    url = page.optJSONObject("content_urls")?.optJSONObject("desktop")?.optString("page", url) ?: url
                } catch (_: Exception) { }
                if (title.isNotBlank() && url.startsWith("http")) results.add(ResearchSource(title, snippet, url))
            }
        } catch (_: Exception) { }
        // GitHub public repository search is useful for open-source/software queries.
        try {
            val json = JSONObject(get("https://api.github.com/search/repositories?q=$q&sort=stars&order=desc&per_page=4"))
            val items = json.optJSONArray("items") ?: JSONArray()
            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                val title = item.optString("full_name")
                val description = item.optString("description", "بدون توضیحات")
                val language = item.optString("language", "نامشخص")
                val stars = item.optInt("stargazers_count")
                val url = item.optString("html_url")
                if (title.isNotBlank() && url.startsWith("http")) results.add(ResearchSource("GitHub: $title", "$description | زبان: $language | ستاره‌ها: $stars", url))
            }
        } catch (_: Exception) { }
        // Stack Exchange public API adds practical Q&A/community troubleshooting evidence.
        try {
            val json = JSONObject(get("https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=relevance&q=$q&site=stackoverflow&pagesize=4"))
            val items = json.optJSONArray("items") ?: JSONArray()
            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                val title = android.text.Html.fromHtml(item.optString("title"), android.text.Html.FROM_HTML_MODE_LEGACY).toString()
                val url = item.optString("link")
                val score = item.optInt("score")
                val answers = item.optInt("answer_count")
                if (title.isNotBlank() && url.startsWith("http")) results.add(ResearchSource("Stack Overflow: $title", "امتیاز: $score | تعداد پاسخ‌ها: $answers", url))
            }
        } catch (_: Exception) { }
        return results.distinctBy { it.url }.take(12)
    }
}
