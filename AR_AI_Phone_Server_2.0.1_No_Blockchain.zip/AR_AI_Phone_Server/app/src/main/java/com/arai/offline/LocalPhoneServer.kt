package com.arai.offline

import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Loopback-only HTTP server. It is intentionally bound to 127.0.0.1, never exposed to Wi-Fi/LAN. */
object LocalPhoneServer {
    const val PORT = 18765
    @Volatile private var running = false
    private val clients = Executors.newCachedThreadPool()

    @Synchronized fun start() {
        if (running) return
        running = true
        Thread {
            try {
                ServerSocket(PORT, 20, java.net.InetAddress.getByName("127.0.0.1")).use { server ->
                    while (running) {
                        val socket = server.accept()
                        clients.execute { handle(socket) }
                    }
                }
            } catch (_: Exception) { running = false }
        }.apply { name = "ARAI-Phone-Server"; isDaemon = true }.start()
    }

    fun health(): Boolean = try {
        val c = URL("http://127.0.0.1:$PORT/health").openConnection() as HttpURLConnection
        c.connectTimeout = 500; c.readTimeout = 500
        val ok = c.responseCode == 200; c.disconnect(); ok
    } catch (_: Exception) { false }

    fun chat(endpoint: String, model: String, key: String, system: String, prompt: String): String {
        val body = JSONObject().put("endpoint", endpoint).put("model", model).put("key", key).put("system", system).put("prompt", prompt).toString().toByteArray(Charsets.UTF_8)
        val c = URL("http://127.0.0.1:$PORT/chat").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 3000; c.readTimeout = 70000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        return try {
            c.outputStream.use { it.write(body) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val obj = JSONObject(raw)
            if (code !in 200..299) error(obj.optString("error", "Local server error $code"))
            obj.optString("answer", "پاسخی دریافت نشد.")
        } finally { c.disconnect() }
    }

    private fun handle(socket: Socket) {
        socket.use { s ->
            s.soTimeout = 75000
            val input = BufferedInputStream(s.getInputStream())
            val output = BufferedOutputStream(s.getOutputStream())
            try {
                val headerBytes = java.io.ByteArrayOutputStream()
                var state = 0
                while (headerBytes.size() < 16384) {
                    val b = input.read(); if (b < 0) return
                    headerBytes.write(b)
                    state = when { state == 0 && b == 13 -> 1; state == 1 && b == 10 -> 2; state == 2 && b == 13 -> 3; state == 3 && b == 10 -> 4; b == 13 -> 1; else -> 0 }
                    if (state == 4) break
                }
                val headers = headerBytes.toString("ISO-8859-1")
                val first = headers.lineSequence().firstOrNull().orEmpty().split(" ")
                val method = first.getOrNull(0).orEmpty(); val path = first.getOrNull(1).orEmpty()
                val length = Regex("(?im)^Content-Length:\\s*(\\d+)").find(headers)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                val bodyBytes = ByteArray(length); var read = 0
                while (read < length) { val n = input.read(bodyBytes, read, length-read); if (n < 0) break; read += n }
                val response = when {
                    method == "GET" && path == "/health" -> JSONObject().put("status", "ok").put("server", "AR.AI Phone Server").put("bind", "127.0.0.1").put("port", PORT)
                    method == "GET" && path == "/plugins" -> JSONObject().put("plugins", PhonePluginRegistry.asJson())
                    method == "POST" && path == "/chat" -> try {
                        val j = JSONObject(String(bodyBytes, 0, read, Charsets.UTF_8))
                        val answer = OnlineAiService.complete(j.optString("endpoint"), j.optString("model"), j.optString("key"), j.optString("system"), j.optString("prompt"))
                        JSONObject().put("answer", answer)
                    } catch (e: Exception) { JSONObject().put("error", e.message ?: "AI request failed") }
                    else -> JSONObject().put("error", "Not found")
                }
                val status = if (response.has("error")) "400 Bad Request" else "200 OK"
                val bytes = response.toString().toByteArray(Charsets.UTF_8)
                val head = "HTTP/1.1 $status\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n\r\n"
                output.write(head.toByteArray(Charsets.US_ASCII)); output.write(bytes); output.flush()
            } catch (_: Exception) { }
        }
    }
}
