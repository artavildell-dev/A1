package com.arai.offline

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.FrameLayout
import android.widget.ImageView
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private val bg = Color.rgb(11,16,32)
    private val panel = Color.rgb(20,27,46)
    private val accent = Color.rgb(96,225,208)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var nav: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showSplash()
    }

    private fun showSplash() {
        val splash = FrameLayout(this).apply { setBackgroundColor(bg) }
        val art = ImageView(this).apply {
            setImageResource(com.arai.offline.R.drawable.ar_ai_splash)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "صفحه آغازین AR.AI"
        }
        splash.addView(art, FrameLayout.LayoutParams(-1, -1))
        val enter = Button(this).apply {
            text = "ورود به AR.AI  ✦"
            textSize = 17f
            setOnClickListener { showMainUi() }
        }
        val lp = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM)
        lp.setMargins(28, 0, 28, 34)
        splash.addView(enter, lp)
        splash.setOnClickListener { showMainUi() }
        setContentView(splash)
        Handler(Looper.getMainLooper()).postDelayed({
            if (splash.parent != null && !isFinishing) showMainUi()
        }, 4500)
    }

    private fun showMainUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(16,16,16,16) }
        val header = TextView(this).apply { text = "AR.AI\\nدستیار هوشمند شخصی"; textSize = 23f; setTextColor(accent); gravity = Gravity.CENTER; setPadding(8,12,8,18) }
        root.addView(header)
        nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("خانه","دستیار","تصویر","ویدیو","کدنویسی").forEachIndexed { i, label ->
            val b = Button(this).apply { text = label; textSize = 11f; setOnClickListener { showPage(i) } }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0,18,0,12) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        showPage(0)
    }

    private fun label(text: String, size: Float = 16f): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(Color.rgb(237,243,255)); setPadding(12,12,12,12)
    }
    private fun button(text: String, action: () -> Unit): Button = Button(this).apply { this.text = text; setOnClickListener { action() } }
    private fun field(hint: String, multiline: Boolean = false): EditText = EditText(this).apply {
        this.hint = hint; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setBackgroundColor(panel)
        setPadding(12,12,12,12)
        if (multiline) { minLines = 5; gravity = Gravity.TOP; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
    }
    private fun showPage(page: Int) {
        content.removeAllViews()
        when(page) {
            0 -> {
                content.addView(label("یک برنامه، چند ابزار", 22f))
                content.addView(label("گفت‌وگو • کدنویسی • تصویر • ویدیو\\n\\nاین نسخه اولیه رابط اندروید است. موتورهای مولد آفلاین هنوز به مدل‌های سازگار نیاز دارند."))
                content.addView(button("باز کردن دستیار") { showPage(1) })
                content.addView(button("باز کردن استودیوی تصویر") { showPage(2) })
                content.addView(button("باز کردن استودیوی ویدیو") { showPage(3) })
                content.addView(button("باز کردن کدنویسی") { showPage(4) })
            }
            1 -> {
                content.addView(label("دستیار هوشمند", 21f))
                val prompt = field("درخواستت را بنویس...", true); content.addView(prompt)
                content.addView(button("پردازش درخواست") {
                    val msg = if (prompt.text.isNullOrBlank()) "ابتدا درخواستت را وارد کن." else "درخواست در نسخه اولیه ثبت شد. برای پاسخ واقعی باید مدل زبانی محلی به برنامه متصل شود.\\n\\n" + prompt.text
                    content.addView(label(msg))
                })
                content.addView(label("وضعیت: رابط آماده است؛ مدل زبانی هنوز نصب و متصل نشده است.", 12f))
            }
            2 -> {
                content.addView(label("استودیوی تصویر", 21f))
                content.addView(label("در نسخه کامل: برش، چرخش، اصلاح رنگ، لایه‌ها، حذف پس‌زمینه، ترمیم و تولید تصویر با مدل محلی."))
                content.addView(label("این بیلد اولیه فقط رابط است؛ ابزار ویرایش تصویر هنوز پیاده‌سازی نشده‌اند.", 13f))
            }
            3 -> {
                content.addView(label("استودیوی ویدیو", 21f))
                content.addView(label("در نسخه کامل: برش و اتصال کلیپ، زیرنویس، صدا، فیلتر و تبدیل عکس به ویدیو با مدل سازگار."))
                content.addView(label("تولید ویدیوی مولد روی همه گوشی‌های ۲۰۲۰ به بالا تضمین‌پذیر نیست.", 13f))
            }
            4 -> {
                content.addView(label("همراه برنامه‌نویس", 21f))
                val code = field("کد خود را اینجا بنویس...", true); content.addView(code)
                content.addView(button("نمایش کد") { content.addView(label(code.text.toString())) })
                content.addView(label("تولید و اصلاح هوشمند کد پس از اتصال مدل کدنویسی محلی فعال می‌شود.", 13f))
            }
        }
    }
}