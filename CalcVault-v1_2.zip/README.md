# CalcVault v1.8 - engineering calculator with hidden vault

Opens straight to a scientific calculator named "Calculator". applicationId `com.calcvault.app`.
Unlock codes are NOT written here any more (only salted PBKDF2 hashes are in `GateHashes.kt`). Defaults are the
original codes you already have; change them in the app: dashboard -> "تغییر کد ورود من" (admin: panel -> codes).
Codes are per device, offline, stored as hashes. Rules: start with Sin/Cos/Tan/Cot, 8-24 chars, no parentheses,
and every "=" inside the code must hit an invalid expression (the calculator would otherwise evaluate it).

Levels: S/TEMP = text crypto + offline translator + Binary/Hex/Base64 (many national encodings).
A/M = + image stego (all image formats), file crypto (all formats), file-in-image, audio scrambler, SMS composer with contact picker.
ADMIN = + admin panel (themes, auto-lock time, codes, HTML/CSS/JS tool runner, maintenance).

Long-press the calculator display to cycle colour themes. Build: Android Studio or `gradle assembleDebug` (SDK 35, JDK 17).
Release builds need your own signing config.
