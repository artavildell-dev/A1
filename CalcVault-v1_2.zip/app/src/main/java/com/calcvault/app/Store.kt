package com.calcvault.app

import android.content.Context
import org.json.JSONObject
import java.io.File

/** A small user tool (HTML/CSS/JS). id == "" means "not saved yet". */
class Tool(val id: String, var name: String, var code: String, var onDash: Boolean)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("cv_settings", Context.MODE_PRIVATE)

    fun theme(c: Context) = p(c).getInt("theme", 0).coerceIn(0, Themes.ALL.size - 1)
    fun setTheme(c: Context, i: Int) { p(c).edit().putInt("theme", i).apply() }
    fun lockMin(c: Context) = p(c).getInt("lock_min", 30).coerceIn(1, 240)
    fun setLockMin(c: Context, m: Int) { p(c).edit().putInt("lock_min", m).apply() }

    private fun dir(c: Context) = File(c.filesDir, "tools").apply { mkdirs() }

    fun tools(c: Context): List<Tool> =
        (dir(c).listFiles { f: File -> f.name.endsWith(".cvt") } ?: emptyArray<File>())
            .mapNotNull { load(it) }.sortedBy { it.name }

    private fun load(f: File): Tool? = try {
        val j = JSONObject(String(Vault.decryptBytes(f.readBytes(), Vault.AAD_TOOL), Charsets.UTF_8))
        Tool(f.name.removeSuffix(".cvt"), j.getString("name"), j.getString("code"), j.optBoolean("dash", false))
    } catch (_: Exception) { null }

    /** Tools are stored AES-GCM encrypted with the Keystore key. */
    fun save(c: Context, t: Tool): Tool {
        val id = if (t.id.isEmpty()) "t" + System.nanoTime() else t.id
        val j = JSONObject().put("name", t.name).put("code", t.code).put("dash", t.onDash)
        val tmp = File(dir(c), "$id.tmp")
        val dst = File(dir(c), "$id.cvt")
        tmp.writeBytes(Vault.encryptBytes(j.toString().toByteArray(Charsets.UTF_8), Vault.AAD_TOOL))
        dst.delete()
        check(tmp.renameTo(dst)) { "ذخیره‌ی ابزار ناموفق بود." }
        return Tool(id, t.name, t.code, t.onDash)
    }

    fun delete(c: Context, id: String) { File(dir(c), "$id.cvt").delete() }
}
