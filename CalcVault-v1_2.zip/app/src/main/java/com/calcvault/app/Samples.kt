package com.calcvault.app

/** Starter templates for the admin tool runner (HTML + CSS + JavaScript, fully offline). */
object Samples {
    val BLANK = """<!DOCTYPE html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:sans-serif;padding:16px}</style></head>
<body>
<h3>ابزار من</h3>
<div id="out"></div>
<script>
document.getElementById('out').textContent = 'سلام! کد خود را اینجا بنویسید.';
</script>
</body></html>"""

    private val COUNTER = """<!DOCTYPE html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:sans-serif;text-align:center;padding:24px}
button{font-size:28px;padding:12px 28px;margin:8px;border-radius:12px}
#n{font-size:64px;margin:16px}</style></head>
<body><h3>شمارنده</h3><div id="n">0</div>
<button onclick="add(-1)">-</button><button onclick="add(1)">+</button>
<script>
var n = 0;
function add(d){ n += d; document.getElementById('n').textContent = n; }
</script></body></html>"""

    private val GUESS = """<!DOCTYPE html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:sans-serif;padding:16px;text-align:center}
input,button{font-size:20px;padding:8px;margin:6px}</style></head>
<body><h2>حدس عدد (۱ تا ۱۰۰)</h2>
<input id="g" type="number"><br><button onclick="go()">حدس بزن</button>
<p id="m"></p><p id="c"></p>
<script>
var n = Math.floor(Math.random()*100)+1, c = 0;
function go(){
  var v = parseInt(document.getElementById('g').value);
  if (isNaN(v)) return;
  c++;
  var m = document.getElementById('m');
  if (v < n) m.textContent = 'بالاتر برو';
  else if (v > n) m.textContent = 'پایین‌تر بیا';
  else { m.textContent = 'درست بود! 🎉'; n = Math.floor(Math.random()*100)+1; c = 0; }
  document.getElementById('c').textContent = 'تعداد حدس‌ها: ' + c;
}
</script></body></html>"""

    val ALL = listOf("قالب خالی" to BLANK, "شمارنده" to COUNTER, "بازی حدس عدد" to GUESS)
}
