package com.calcvault.app

import java.math.BigDecimal
import java.math.MathContext
import java.util.Locale
import kotlin.math.*

enum class Angle { DEG, RAD, GRAD }

/** Engineering calculator engine: full-precedence parser, trig/hyperbolic/log/combinatorics, DEG/RAD/GRAD. */
object Calc {
    fun eval(src: String, angle: Angle, ans: Double): Double {
        var t = src.trim()
        val open = t.count { it == '(' } - t.count { it == ')' }
        if (open > 0) t += ")".repeat(open)           // auto-close missing parentheses
        val p = Parser(t, angle, ans)
        val v = p.expr()
        if (p.peek() != null || !v.isFinite()) throw IllegalArgumentException("syntax")
        return v
    }

    /** fmt: 0 = normal, 1 = scientific, 2 = engineering */
    fun format(v: Double, fmt: Int): String {
        if (v == 0.0) return "0"
        val a = abs(v)
        return when (fmt) {
            1 -> sci(v, 10)
            2 -> {
                val e3 = floor(log10(a) / 3.0).toInt() * 3
                val m = BigDecimal(v / 10.0.pow(e3)).round(MathContext(10)).stripTrailingZeros().toPlainString()
                if (e3 == 0) m else "${m}E$e3"
            }
            else -> if (a >= 1e12 || a < 1e-9) sci(v, 10)
                    else BigDecimal(v).round(MathContext(12)).stripTrailingZeros().toPlainString()
        }
    }

    private fun sci(v: Double, digits: Int): String {
        val s = String.format(Locale.US, "%.${digits - 1}e", v)
        val (m, e) = s.split('e')
        val mant = if (m.contains('.')) m.trimEnd('0').trimEnd('.') else m
        return "${mant}E${e.toInt()}"
    }

    private class Parser(val s: String, val ang: Angle, val ans: Double) {
        var i = 0
        fun peek(): Char? { while (i < s.length && s[i].isWhitespace()) i++; return s.getOrNull(i) }
        fun bad(): Nothing = throw IllegalArgumentException("syntax")
        fun math(): Nothing = throw ArithmeticException("math")

        fun expr(): Double {
            var v = term()
            while (true) when (peek()) {
                '+' -> { i++; v += term() }
                '-' -> { i++; v -= term() }
                else -> return v
            }
        }

        fun term(): Double {
            var v = unary()
            while (true) {
                val c = peek() ?: return v
                when {
                    c == '*' -> { i++; v *= unary() }
                    c == '/' -> { i++; val d = unary(); if (d == 0.0) math(); v /= d }
                    c == '%' -> { i++; val d = unary(); if (d == 0.0) math(); v %= d }
                    c == '(' || c == '\u03c0' || c.isLetter() -> v *= unary()      // implicit multiplication
                    else -> return v
                }
            }
        }

        fun unary(): Double = when (peek()) {
            '-' -> { i++; -unary() }
            '+' -> { i++; unary() }
            else -> power()
        }

        fun power(): Double {
            val b = postfix()
            if (peek() == '^') { i++; return b.pow(unary()) }
            return b
        }

        fun postfix(): Double {
            var v = primary()
            while (peek() == '!') { i++; v = fact(v) }
            return v
        }

        fun primary(): Double {
            val c = peek() ?: bad()
            if (c == '(') { i++; val v = expr(); close(); return v }
            if (c.isDigit() || c == '.') return number()
            if (c == '\u03c0') { i++; return PI }
            if (!c.isLetter()) bad()
            val st = i
            while (i < s.length && s[i].isLetter() && s[i] != '\u03c0') i++
            var name = s.substring(st, i)
            if (name == "e") return E
            name = name.lowercase()
            if (name == "pi") return PI
            if (name == "ans") return ans
            if (name == "log" && s.getOrNull(i) == '2') { name = "log2"; i++ }
            if (peek() != '(') bad()
            i++
            val args = arrayListOf(expr())
            while (peek() == ',') { i++; args.add(expr()) }
            close()
            return fn(name, args)
        }

        fun close() { if (peek() != ')') bad(); i++ }

        fun number(): Double {
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (i < s.length && (s[i] == 'E' || s[i] == 'e')) {
                var j = i + 1
                if (j < s.length && (s[j] == '+' || s[j] == '-')) j++
                if (j < s.length && s[j].isDigit()) { while (j < s.length && s[j].isDigit()) j++; i = j }
            }
            return s.substring(st, i).toDouble()
        }

        // ---- angles ----
        fun toRad(x: Double) = when (ang) { Angle.DEG -> x * PI / 180; Angle.RAD -> x; Angle.GRAD -> x * PI / 200 }
        fun fromRad(x: Double) = when (ang) { Angle.DEG -> x * 180 / PI; Angle.RAD -> x; Angle.GRAD -> x * 200 / PI }
        fun snap(x: Double) = if (abs(x) < 1e-14) 0.0 else x

        fun fact(x: Double): Double {
            if (x < 0 || x != floor(x) || x > 170) math()
            var r = 1.0; for (k in 2..x.toInt()) r *= k; return r
        }

        fun fn(name: String, a: List<Double>): Double {
            fun one(): Double { if (a.size != 1) bad(); return a[0] }
            fun two(): Pair<Double, Double> { if (a.size != 2) bad(); return a[0] to a[1] }
            return when (name) {
                "sin" -> snap(sin(toRad(one())))
                "cos" -> snap(cos(toRad(one())))
                "tan" -> { val r = toRad(one()); if (abs(cos(r)) < 1e-14) math(); snap(tan(r)) }
                "cot" -> { val r = toRad(one()); if (abs(sin(r)) < 1e-14) math(); snap(cos(r) / sin(r)) }
                "asin" -> { val x = one(); if (abs(x) > 1) math(); fromRad(asin(x)) }
                "acos" -> { val x = one(); if (abs(x) > 1) math(); fromRad(acos(x)) }
                "atan" -> fromRad(atan(one()))
                "acot" -> { val x = one(); fromRad(if (x == 0.0) PI / 2 else atan(1 / x)) }
                "sinh" -> sinh(one())
                "cosh" -> cosh(one())
                "tanh" -> tanh(one())
                "coth" -> { val x = one(); if (x == 0.0) math(); 1 / tanh(x) }
                "asinh" -> asinh(one())
                "acosh" -> { val x = one(); if (x < 1) math(); acosh(x) }
                "atanh" -> { val x = one(); if (abs(x) >= 1) math(); atanh(x) }
                "acoth" -> { val x = one(); if (abs(x) <= 1) math(); 0.5 * ln((x + 1) / (x - 1)) }
                "ln" -> { val x = one(); if (x <= 0) math(); ln(x) }
                "log" -> { val x = one(); if (x <= 0) math(); log10(x) }
                "log2" -> { val x = one(); if (x <= 0) math(); log2(x) }
                "exp" -> exp(one())
                "sqrt" -> { val x = one(); if (x < 0) math(); sqrt(x) }
                "cbrt" -> Math.cbrt(one())
                "abs" -> abs(one())
                "fact" -> fact(one())
                "pow" -> { val (x, y) = two(); x.pow(y) }
                "root" -> {
                    val (x, n) = two(); if (n == 0.0) math()
                    if (x < 0 && n == floor(n) && n.toLong() % 2L != 0L) -((-x).pow(1 / n)) else { if (x < 0) math(); x.pow(1 / n) }
                }
                "mod" -> { val (x, y) = two(); if (y == 0.0) math(); x % y }
                "ncr" -> {
                    val (n, r) = two()
                    if (n < 0 || r < 0 || r > n || n != floor(n) || r != floor(r)) math()
                    var res = 1.0; for (k in 1..r.toInt()) res = res * (n - r + k) / k; round(res)
                }
                "npr" -> {
                    val (n, r) = two()
                    if (n < 0 || r < 0 || r > n || n != floor(n) || r != floor(r)) math()
                    var res = 1.0; for (k in 0 until r.toInt()) res *= (n - k); res
                }
                else -> bad()
            }
        }
    }
}
