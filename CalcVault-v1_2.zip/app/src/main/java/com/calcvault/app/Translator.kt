package com.calcvault.app

/**
 * Small OFFLINE phrasebook translator (built-in dictionary, no internet, no model download).
 * It translates known words/phrases only; unknown words are left unchanged.
 */
object Translator {
    val LANGS = listOf(
        "fa" to "فارسی", "en" to "English", "ar" to "العربية", "tr" to "Türkçe",
        "ru" to "Русский", "es" to "Español", "fr" to "Français", "de" to "Deutsch"
    )

    // order: fa | en | ar | tr | ru | es | fr | de
    private val DATA = listOf(
        "سلام|hello|مرحبا|merhaba|привет|hola|bonjour|hallo",
        "خداحافظ|goodbye|مع السلامة|hoşça kal|до свидания|adiós|au revoir|auf wiedersehen",
        "ممنون|thank you|شكرا|teşekkürler|спасибо|gracias|merci|danke",
        "لطفا|please|من فضلك|lütfen|пожалуйста|por favor|s'il vous plaît|bitte",
        "بله|yes|نعم|evet|да|sí|oui|ja",
        "نه|no|لا|hayır|нет|no|non|nein",
        "ببخشید|sorry|آسف|özür dilerim|извините|perdón|désolé|entschuldigung",
        "کمک|help|مساعدة|yardım|помощь|ayuda|aide|hilfe",
        "آب|water|ماء|su|вода|agua|eau|wasser",
        "غذا|food|طعام|yemek|еда|comida|nourriture|essen",
        "دوست|friend|صديق|arkadaş|друг|amigo|ami|freund",
        "خانه|house|بيت|ev|дом|casa|maison|haus",
        "پول|money|مال|para|деньги|dinero|argent|geld",
        "امروز|today|اليوم|bugün|сегодня|hoy|aujourd'hui|heute",
        "فردا|tomorrow|غدا|yarın|завтра|mañana|demain|morgen",
        "دیروز|yesterday|أمس|dün|вчера|ayer|hier|gestern",
        "شب بخیر|good night|تصبح على خير|iyi geceler|спокойной ночи|buenas noches|bonne nuit|gute nacht",
        "دوستت دارم|i love you|أحبك|seni seviyorum|я тебя люблю|te quiero|je t'aime|ich liebe dich",
        "اسم تو چیست|what is your name|ما اسمك|adın ne|как тебя зовут|cómo te llamas|comment tu t'appelles|wie heißt du",
        "حالت چطور است|how are you|كيف حالك|nasılsın|как дела|cómo estás|comment vas-tu|wie geht es dir",
        "کجا|where|أين|nerede|где|dónde|où|wo",
        "کی|when|متى|ne zaman|когда|cuándo|quand|wann",
        "چرا|why|لماذا|neden|почему|por qué|pourquoi|warum",
        "من|i|أنا|ben|я|yo|je|ich",
        "تو|you|أنت|sen|ты|tú|tu|du",
        "ما|we|نحن|biz|мы|nosotros|nous|wir",
        "خوب|good|جيد|iyi|хорошо|bueno|bon|gut",
        "بد|bad|سيء|kötü|плохо|malo|mauvais|schlecht",
        "بزرگ|big|كبير|büyük|большой|grande|grand|groß",
        "کوچک|small|صغير|küçük|маленький|pequeño|petit|klein",
        "یک|one|واحد|bir|один|uno|un|eins",
        "دو|two|اثنان|iki|два|dos|deux|zwei",
        "سه|three|ثلاثة|üç|три|tres|trois|drei",
        "کتاب|book|كتاب|kitap|книга|libro|livre|buch",
        "ماشین|car|سيارة|araba|машина|coche|voiture|auto",
        "تلفن|phone|هاتف|telefon|телефон|teléfono|téléphone|telefon",
        "امن|safe|آمن|güvenli|безопасный|seguro|sûr|sicher",
        "رمز عبور|password|كلمة المرور|şifre|пароль|contraseña|mot de passe|passwort",
        "پیام|message|رسالة|mesaj|сообщение|mensaje|message|nachricht",
        "عکس|photo|صورة|fotoğraf|фото|foto|photo|foto"
    )

    private val rows: List<List<String>> = DATA.map { it.split("|") }

    private val index: Map<String, Map<String, Int>> by lazy {
        LANGS.mapIndexed { li, l ->
            val m = HashMap<String, Int>()
            rows.forEachIndexed { ri, r -> r.getOrNull(li)?.let { m[norm(l.first, it)] = ri } }
            l.first to m
        }.toMap()
    }

    private fun norm(lang: String, s: String): String {
        var t = s.lowercase().trim().replace('’', '\'')
        t = t.replace(Regex("[.,!?؟،;:\"“”«»]"), "")
        t = if (lang == "fa") t.replace('ي', 'ی').replace('ك', 'ک') else if (lang == "ar") t.replace('ی', 'ي').replace('ک', 'ك') else t
        return t.replace(Regex("\\s+"), " ")
    }

    /** Returns the translation and the number of words that were not in the dictionary. */
    fun translate(text: String, from: String, to: String): Pair<String, Int> {
        val li = LANGS.indexOfFirst { it.first == to }
        val idx = index[from] ?: return text to 0
        var unknown = 0
        val out = text.lines().joinToString("\n") { line ->
            val orig = line.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            val nw = orig.map { norm(from, it) }
            val res = ArrayList<String>()
            var i = 0
            while (i < orig.size) {
                var hit = false
                for (n in minOf(4, orig.size - i) downTo 1) {
                    val ri = idx[nw.subList(i, i + n).joinToString(" ")] ?: continue
                    res.add(rows[ri].getOrNull(li) ?: orig[i])
                    i += n; hit = true; break
                }
                if (!hit) { res.add(orig[i]); unknown++; i++ }
            }
            res.joinToString(" ")
        }
        return out to unknown
    }
}
