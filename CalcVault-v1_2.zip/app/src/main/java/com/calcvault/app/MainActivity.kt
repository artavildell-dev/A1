package com.calcvault.app

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.provider.ContactsContract
import android.provider.OpenableColumns
import android.telephony.SmsManager
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsControllerCompat
import java.io.File
import java.io.OutputStream
import java.nio.ByteBuffer
import java.text.Normalizer
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val exec = Executors.newSingleThreadExecutor()        // heavy work (crypto, files, audio)
    private val gateExec = Executors.newSingleThreadExecutor()    // unlock checks never wait behind heavy work
    private val ui = Handler(Looper.getMainLooper())
    private var role: Role? = null
    private var onDash = false
    private var picking = false
    private val lockTask = Runnable { lock() }
    private var pal: Palette = Themes.ALL[0]
    private var web: WebView? = null

    // calculator state
    private var angle = Angle.DEG
    private var fmt = 0
    private var mem = 0.0
    private var ans = 0.0
    private val hist = ArrayList<String>()
    private val tracker = Gate.Tracker(this, gateExec, ui) { r -> enter(r) }

    private var image: Uri? = null
    private var carrier: Uri? = null
    private var file: Uri? = null
    private var onOpen: ((Uri) -> Unit)? = null
    private var onSave: ((Uri?) -> Unit)? = null
    private var onContact: ((Uri) -> Unit)? = null
    private var onPerm: ((Boolean) -> Unit)? = null
    private val sent = ArrayList<String>()
    private var trFrom = "fa"
    private var trTo = "en"
    private var csIdx = 0
    private var baseIdx = 0

    private class SaveContract : ActivityResultContract<Pair<String, String>, Uri?>() {
        override fun createIntent(context: Context, input: Pair<String, String>) =
            Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType(input.second).putExtra(Intent.EXTRA_TITLE, input.first)
        override fun parseResult(resultCode: Int, intent: Intent?): Uri? =
            if (resultCode == Activity.RESULT_OK) intent?.data else null
    }

    private val openDoc = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) handlePicked(u) }
    private val getContent = registerForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) handlePicked(u) }
    private val photoPick = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { u -> if (u != null) handlePicked(u) }
    private var pickMimes: Array<String> = arrayOf("*/*")
    private var pickCb: ((Uri) -> Unit)? = null
    private var pickTier = 0
    private var pickImage = false
    private val saver = registerForActivityResult(SaveContract()) { u -> onSave?.invoke(u) }
    private val contactPick = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val u = r.data?.data
        if (r.resultCode == Activity.RESULT_OK && u != null) onContact?.invoke(u)
    }
    private val permReq = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> onPerm?.invoke(ok) }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        pal = Themes.ALL[Store.theme(this)]
        applyTheme()
        cacheDir.listFiles()?.forEach { if (it.isFile) it.delete() }   // stale temp files from a killed session
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    role == null -> finish()
                    onDash -> lock()
                    else -> showDashboard()
                }
            }
        })
        showCalculator()
    }

    override fun onResume() { super.onResume(); picking = false }
    override fun onStop() { super.onStop(); if (!picking) lock() }
    override fun onDestroy() {
        exec.shutdownNow(); gateExec.shutdownNow(); ui.removeCallbacks(lockTask); killWeb(); super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun applyTheme() {
        window.decorView.setBackgroundColor(pal.bg)
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = pal.light
            isAppearanceLightNavigationBars = pal.light
        }
    }

    private fun enter(r: Role) {
        role = r
        ui.removeCallbacks(lockTask); ui.postDelayed(lockTask, Store.lockMin(this) * 60_000L)
        showDashboard()
    }

    private fun lock() {
        ui.removeCallbacks(lockTask)
        killWeb()
        if (role == null) return
        role = null; onDash = false
        image = null; carrier = null; file = null
        onOpen = null; pickCb = null; onSave = null; onContact = null; onPerm = null
        sent.clear(); hist.clear(); mem = 0.0; ans = 0.0
        showCalculator()
    }

    private fun killWeb() {
        web?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
        web = null
    }

    // ---------- tiny UI kit ----------
    private val BG: Int get() = pal.bg
    private val KEY: Int get() = pal.key
    private val ACC: Int get() = pal.acc
    private val RED: Int get() = pal.red
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun box(fill: Int, r: Int = 14) = GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(fill); setStroke(1, pal.line) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun text(t: String, size: Float = 15f, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(pal.text)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun page(title: String): LinearLayout {
        onDash = false; killWeb()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        col.addView(text(title, 21f, true))
        val sv = ScrollView(this).apply {
            setBackgroundColor(BG); fitsSystemWindows = true; filterTouchesWhenObscured = true; addView(col)
        }
        setContentView(sv)
        return col
    }

    private fun LinearLayout.btn(t: String, click: () -> Unit): Button {
        val b = Button(this@MainActivity).apply {
            text = t; isAllCaps = false; setTextColor(pal.text); background = box(KEY)
            setOnClickListener { click() }
        }
        addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        return b
    }

    private fun LinearLayout.back() = btn("↩ بازگشت") { showDashboard() }

    private fun field(hint: String, lines: Int) = EditText(this).apply {
        this.hint = hint; minLines = lines; gravity = Gravity.TOP; setTextColor(pal.text)
        setHintTextColor(pal.sub); background = box(pal.field)
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    private fun passField(hint: String) = field(hint, 1).apply {
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun LinearLayout.add(v: View) = addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

    /** select-all / copy / paste / clear bar for an input or output box */
    private fun LinearLayout.ioBar(f: EditText) {
        val r = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
        fun b(t: String, c: () -> Unit) = r.addView(Button(this@MainActivity).apply {
            text = t; isAllCaps = false; textSize = 12f; setTextColor(pal.text); background = box(KEY)
            setOnClickListener { c() }
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        b("انتخاب همه") { f.requestFocus(); f.selectAll() }
        b("کپی") { copy(f.text.toString()) }
        b("چسباندن") { pasteInto(f) }
        b("پاک کردن") { f.text.clear() }
        add(r)
    }

    private fun copy(t: String) {
        if (t.isEmpty()) { toast("چیزی برای کپی نیست"); return }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("", t)
        if (Build.VERSION.SDK_INT >= 33) clip.description.extras = PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE", true) }
        cm.setPrimaryClip(clip)
        toast("کپی شد (کلیپ‌بورد پس از ۶۰ ثانیه پاک می‌شود)")
        ui.postDelayed({ try { if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip() } catch (_: Exception) {} }, 60_000)
    }

    private fun pasteInto(f: EditText) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        if (t.isNullOrEmpty()) { toast("کلیپ‌بورد خالی است"); return }
        f.text.insert(f.selectionStart.coerceAtLeast(0), t)
    }

    private fun choose(title: String, items: List<String>, cb: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setItems(items.toTypedArray()) { d, i -> d.dismiss(); cb(i) }.show()
    }

    private fun confirm(msg: String, yes: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg).setPositiveButton("بله") { _, _ -> yes() }.setNegativeButton("خیر", null).show()
    }

    private fun friendly(e: Throwable): String {
        if (generateSequence(e) { it.cause }.any { it is javax.crypto.BadPaddingException })
            return "رمزگشایی ناموفق: رمز/کلید اشتباه است یا داده خراب شده."
        if (generateSequence(e) { it.cause }.any { it.message?.contains("ENOSPC") == true }) return "فضای ذخیره‌سازی پر است."
        if (e is SecurityException) return "اجازه‌ی دسترسی به این فایل داده نشد؛ دوباره آن را انتخاب کنید."
        if (e is OutOfMemoryError) return "حافظه کافی نیست؛ فایل یا تصویر کوچکتری انتخاب کنید."
        if (e is IllegalArgumentException && e.message?.startsWith("Illegal base64") == true) return "متن رمزنگاری‌شده ناقص یا نامعتبر است."
        return e.message ?: "عملیات ناموفق بود."
    }

    private fun work(msg: String, block: () -> Unit) {
        toast(msg)
        exec.execute { try { block() } catch (e: Throwable) { ui.post { toast(friendly(e)) } } }
    }

    // ---------- file helpers ----------
    /**
     * File picker with automatic fallbacks. Some vendor file managers (and the Downloads provider) hand back a URI the
     * app is not allowed to read. We test readability right away; if it fails we retry with GET_CONTENT, then (images)
     * with the system photo picker.
     */
    private fun pick(vararg mime: String, image: Boolean = false, cb: (Uri) -> Unit) {
        pickMimes = arrayOf(*mime); pickImage = image; pickCb = cb; pickTier = 0; picking = true
        openDoc.launch(pickMimes)
    }

    private fun canRead(u: Uri): Boolean = try { openIn(u).close(); true } catch (_: Exception) { false }

    private fun handlePicked(u: Uri) {
        if (role == null) return
        if (canRead(u)) { pickCb?.invoke(u); return }
        pickTier++
        val wantsImage = pickImage
        picking = true
        when {
            pickTier == 1 -> {
                toast("روش جایگزین انتخاب فایل…")
                getContent.launch("*/*")
            }
            pickTier == 2 && wantsImage ->
                photoPick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            else -> {
                picking = false
                AlertDialog.Builder(this)
                    .setMessage("دسترسی به فایل از این منبع ممکن نیست. فایل را به حافظه‌ی داخلی (مثلاً پوشه‌ی Documents یا Pictures) کپی کنید و دوباره انتخاب کنید.")
                    .setPositiveButton("باشه", null).show()
            }
        }
    }

    private fun mimeOf(name: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "application/octet-stream"

    private fun saveAs(name: String, cb: (Uri?) -> Unit) { onSave = cb; picking = true; saver.launch(name to mimeOf(name)) }

    private fun nameOf(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: "file"
            }
        } catch (_: Exception) {}
        return "file"
    }

    /** Opens a picked document; tries several ways because some providers (e.g. Downloads) reject one of them. */
    private fun openIn(u: Uri): java.io.InputStream {
        var denied = false
        val attempts = listOf<() -> java.io.InputStream?>(
            { contentResolver.openInputStream(u) },
            { contentResolver.openAssetFileDescriptor(u, "r")?.createInputStream() },
            { contentResolver.openFileDescriptor(u, "r")?.let { android.os.ParcelFileDescriptor.AutoCloseInputStream(it) } }
        )
        for (a in attempts) {
            try { a()?.let { return it } }
            catch (_: SecurityException) { denied = true }
            catch (_: Exception) { }
        }
        error(
            if (denied) "دسترسی به این فایل رد شد (معمولاً از پوشه‌ی Downloads). آن را از بخش «تصاویر / صوت» یا «فایل‌های دستگاه» انتخاب کنید، یا ابتدا به پوشه‌ی دیگری کپی کنید."
            else "فایل قابل خواندن نیست. اگر روی فضای ابری (Drive…) است، اول آن را دانلود کنید."
        )
    }

    /** Copies a picked document into app cache; every decoder then works on a plain local file. */
    private fun localCopy(u: Uri, prefix: String): File {
        val f = File(cacheDir, "${prefix}_${System.nanoTime()}")
        try { openIn(u).use { i -> f.outputStream().use { i.copyTo(it, 64 * 1024) } } }
        catch (e: Throwable) { f.delete(); throw e }
        return f
    }

    private fun loadImage(u: Uri, maxDim: Int = 0): Bitmap {
        val f = localCopy(u, "img")
        try { return Stego.decodeFile(f, maxDim) } finally { f.delete() }
    }

    private fun writeTo(u: Uri, block: (OutputStream) -> Unit) {
        val o = try { contentResolver.openOutputStream(u, "wt") } catch (_: Exception) { null }
            ?: try { contentResolver.openOutputStream(u, "w") } catch (_: Exception) { null }
            ?: error("مقصد قابل نوشتن نیست؛ جای دیگری ذخیره کنید.")
        o.use(block)
    }

    private fun finishSave(tmp: File, u: Uri?) {
        if (u == null) { tmp.delete(); return }
        work("در حال ذخیره…") {
            try { writeTo(u) { o -> tmp.inputStream().use { it.copyTo(o, 64 * 1024) } } } finally { tmp.delete() }
            ui.post { toast("ذخیره شد ✔") }
        }
    }

    // Only LOSSLESS formats can carry hidden data (JPEG and lossy WebP destroy it).
    private val outFormats: List<Pair<String, String>> =
        buildList {
            add("PNG (بدون افت کیفیت)" to "png")
            if (Build.VERSION.SDK_INT >= 30) add("WebP Lossless (بدون افت کیفیت، حجم کمتر)" to "webp")
            add("BMP (بدون فشرده‌سازی، سازگار با همه جا)" to "bmp")
        }
    private var outIdx = 0

    private fun LinearLayout.fmtBtn() {
        val b = btn("قالب خروجی: ${outFormats[outIdx.coerceIn(0, outFormats.size - 1)].first}") {}
        b.setOnClickListener {
            choose("قالب خروجی تصویر", outFormats.map { it.first }) { i -> outIdx = i; b.text = "قالب خروجی: ${outFormats[i].first}" }
        }
    }

    private fun writeBmp(bm: Bitmap, o: OutputStream) {
        val w = bm.width; val h = bm.height
        val stride = (w * 3 + 3) and 3.inv()
        val size = 54L + stride.toLong() * h
        require(size < 0x7FFFFFFFL) { "تصویر برای BMP خیلی بزرگ است؛ PNG را انتخاب کنید." }
        val hd = ByteBuffer.allocate(54).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        hd.put('B'.code.toByte()).put('M'.code.toByte()).putInt(size.toInt()).putInt(0).putInt(54)
        hd.putInt(40).putInt(w).putInt(h).putShort(1).putShort(24).putInt(0).putInt(stride * h).putInt(2835).putInt(2835).putInt(0).putInt(0)
        o.write(hd.array())
        val px = IntArray(w); val row = ByteArray(stride)
        for (y in h - 1 downTo 0) {
            bm.getPixels(px, 0, w, 0, y, w, 1)
            var k = 0
            for (x in 0 until w) { val p = px[x]; row[k++] = p.toByte(); row[k++] = (p shr 8).toByte(); row[k++] = (p shr 16).toByte() }
            o.write(row)
        }
    }

    private fun saveImage(out: Bitmap) {
        val ext = outFormats[outIdx.coerceIn(0, outFormats.size - 1)].second
        saveAs("IMG_${System.currentTimeMillis()}.$ext") { u ->
            if (u != null) work("در حال ذخیره…") {
                writeTo(u) { o ->
                    when (ext) {
                        "bmp" -> writeBmp(out, o)
                        "webp" -> @Suppress("NewApi") check(out.compress(Bitmap.CompressFormat.WEBP_LOSSLESS, 100, o)) { "ذخیره‌ی WebP ناموفق بود." }
                        else -> check(out.compress(Bitmap.CompressFormat.PNG, 100, o)) { "ذخیره‌ی PNG ناموفق بود." }
                    }
                }
                ui.post { toast("ذخیره شد ✔") }
            }
        }
    }

    // ---------- engineering calculator (the only thing visible by default) ----------
    private fun showCalculator() {
        tracker.reset(); onDash = false; killWeb()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(BG); fitsSystemWindows = true; layoutDirection = View.LAYOUT_DIRECTION_LTR
            filterTouchesWhenObscured = true
        }
        val history = text("", 12f).apply { gravity = Gravity.END or Gravity.BOTTOM; setTextColor(pal.sub); maxLines = 3 }
        val status = text("", 11f).apply { gravity = Gravity.START; setTextColor(pal.sub) }
        val display = text("", 32f).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL; setSingleLine(); ellipsize = TextUtils.TruncateAt.START
            setPadding(dp(12), 0, dp(12), 0); background = box(pal.field, 16)
            setOnLongClickListener {                       // long-press the display: next colour theme
                val n = (Store.theme(this@MainActivity) + 1) % Themes.ALL.size
                Store.setTheme(this@MainActivity, n); pal = Themes.ALL[n]; applyTheme(); showCalculator(); true
            }
        }
        root.addView(history, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(status, LinearLayout.LayoutParams(-1, dp(18)))
        root.addView(display, LinearLayout.LayoutParams(-1, dp(66)).apply { bottomMargin = dp(4) })

        var second = false; var hyp = false; var justEvaluated = false
        val relabel = ArrayList<() -> Unit>()
        fun fmtName() = arrayOf("NORM", "SCI", "ENG")[fmt]
        fun refresh() {
            status.text = "${angle.name}  ${fmtName()}${if (mem != 0.0) "  M" else ""}${if (second) "  2nd" else ""}${if (hyp) "  hyp" else ""}"
            relabel.forEach { it() }
        }
        fun showHist() { history.text = hist.takeLast(3).joinToString("\n") }
        showHist(); refresh()

        fun put(t: String, token: String) {
            if (justEvaluated) {
                if (t[0] !in "+-*/%^!") display.text = ""
                justEvaluated = false
            }
            display.append(t); tracker.key(token)
        }
        fun curValue(): Double = try { Calc.eval(display.text.toString(), angle, ans) } catch (_: Exception) { ans }
        fun fn(base: String, token: String?) {
            val name = (if (second) "a" else "") + base + (if (hyp) "h" else "")
            put("$name(", if (!second && !hyp && token != null) token else "#")
            second = false; hyp = false; refresh()
        }
        fun doEquals() {
            val expr = display.text.toString()
            tracker.key("=")
            if (expr.isBlank()) return
            try {
                val v = Calc.eval(expr, angle, ans)
                ans = v
                val r = Calc.format(v, fmt)
                hist.add("$expr = $r"); showHist()
                display.text = r; justEvaluated = true; tracker.reset(); refresh()
            } catch (_: Exception) { status.text = "Error" }
        }

        fun row(weightRow: Float = 1f, build: LinearLayout.() -> Unit) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.build()
            root.addView(r, LinearLayout.LayoutParams(-1, 0, weightRow))
        }
        fun LinearLayout.key(a: String, b: String? = null, fill: Int = KEY, dyn: (() -> String)? = null, h: () -> Unit) {
            val tv = TextView(this@MainActivity).apply {
                gravity = Gravity.CENTER; setTextColor(pal.text); background = box(fill, 14)
                setOnClickListener { h() }
            }
            val upd = {
                val t = dyn?.invoke() ?: if (second && b != null) b else a
                tv.text = t; tv.textSize = if (t.length > 3) 13f else 17f
            }
            upd(); relabel.add(upd)
            addView(tv, LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
        fun LinearLayout.num(c: String) = key(c) { put(c, c) }
        fun LinearLayout.op(label: String, ins: String) = key(label) { put(ins, ins) }
        fun LinearLayout.sym(label: String, ins: String, alt: String? = null, altIns: String? = null) =
            key(label, alt) { val t = if (second && altIns != null) altIns else ins; put(t, "#"); second = false; refresh() }

        row { key("2nd", fill = ACC) { second = !second; refresh() }; key("hyp", fill = ACC) { hyp = !hyp; refresh() }
              key("", dyn = { angle.name }) { angle = Angle.values()[(angle.ordinal + 1) % 3]; refresh() }
              key("", dyn = { fmtName() }) { fmt = (fmt + 1) % 3; refresh() }
              key("AC", fill = RED) { display.text = ""; justEvaluated = false; tracker.clear(); refresh() } }
        row { key("sin", "sin\u207b\u00b9") { fn("sin", "Sin") }; key("cos", "cos\u207b\u00b9") { fn("cos", "Cos") }
              key("tan", "tan\u207b\u00b9") { fn("tan", "Tan") }; key("cot", "cot\u207b\u00b9") { fn("cot", "Cot") }
              key("\u232b", fill = RED) {
                  if (justEvaluated) { display.text = ""; justEvaluated = false }
                  else { val t = display.text.toString(); display.text = Regex("[a-zA-Z]+\\($").replace(t, "").let { if (it.length < t.length) it else t.dropLast(1) }; tracker.back() }
              } }
        row { sym("ln", "ln(", "e\u02e3", "exp("); sym("log", "log(", "10\u02e3", "10^(")
              sym("\u221a", "sqrt(", "\u221b", "cbrt("); sym("x\u00b2", "^2", "x\u00b3", "^3"); sym("x\u02b8", "^", "\u02b8\u221ax", "root(") }
        row { op("(", "("); op(")", ")"); sym("\u03c0", "\u03c0"); sym("e", "e"); sym("n!", "!", "|x|", "abs(") }
        row { num("7"); num("8"); num("9"); op("\u00f7", "/"); key("MC") { mem = 0.0; refresh() } }
        row { num("4"); num("5"); num("6"); op("\u00d7", "*"); key("MR") { put(Calc.format(mem, 0), "#") } }
        row { num("1"); num("2"); num("3"); op("\u2212", "-"); key("M+") { mem += curValue(); refresh() } }
        row { num("0"); num("."); op("%", "%"); op("+", "+"); key("M\u2212") { mem -= curValue(); refresh() } }
        row { sym("nCr", "nCr(", "nPr", "nPr("); sym("1/x", "1/("); sym(",", ","); sym("Ans", "Ans"); key("=", fill = ACC) { doEquals() } }
        setContentView(root)
    }

    // ---------- dashboard ----------
    private fun showDashboard() {
        val r = role ?: return showCalculator()
        val root = page("ابزارها")
        onDash = true
        root.add(text("سطح دسترسی: ${r.title}", 13f).apply { setTextColor(pal.sub) })
        root.btn("🔐 رمزنگاری، رمزگشایی و ترجمه‌ی پیام") { showText() }
        root.btn("🔢 تبدیل متن ⇄ Binary / Hex / Base64") { showBinary() }
        if (r.files) {
            root.btn("🖼️ پیام رمزنگاری‌شده داخل تصویر") { showMsgStego() }
            root.btn("📦 رمزنگاری فایل (هر قالبی)") { showFileCrypto() }
            root.btn("🖼️📦 فایل رمزنگاری‌شده داخل تصویر") { showFileStego() }
            root.btn("🎵 صدای ناخوانا ⇄ بازگردانی") { showAudio() }
            root.btn("📨 ارسال پیام (با انتخاب مخاطب)") { showChat() }
        }
        Store.tools(this).filter { it.onDash }.forEach { t -> root.btn("🧩 ${t.name}") { showTool(t) { showDashboard() } } }
        if (r.admin) root.btn("⚙️ پنل مدیریت") { showAdmin() }
        if (r != Role.TEMPORARY) root.btn("🔑 تغییر کد ورود من") { showChangeCode(r) }
        root.btn("🛡️ وضعیت امنیتی") { showSecurity() }
        root.btn("🚪 خروج امن") { lock() }
    }

    // ---------- text crypto + offline translator ----------
    private fun showText() {
        val root = page("🔐 رمزنگاری و ترجمه")
        val input = field("متن (هر زبانی)…", 6); val output = field("خروجی…", 6)
        val pass = passField("رمز مشترک (اختیاری؛ برای ارسال به دستگاه دیگر)")
        root.add(text("ورودی", 13f)); root.add(input); root.ioBar(input)
        root.add(pass)
        root.btn("🔐 رمزنگاری") {
            val t = Normalizer.normalize(input.text.toString(), Normalizer.Form.NFC)
            if (t.isBlank()) { toast("متنی وارد نشده"); return@btn }
            val pw = pass.text.toString()
            work("در حال رمزنگاری…") {
                val e = if (pw.isEmpty()) Vault.encryptText(t) else Vault.encryptTextPass(t, pw)
                ui.post { output.setText(e) }
            }
        }
        root.btn("🔓 رمزگشایی") {
            val c = input.text.toString().ifBlank { output.text.toString() }
            if (c.isBlank()) { toast("متن رمزنگاری‌شده را وارد کنید"); return@btn }
            val pw = pass.text.toString()
            work("در حال رمزگشایی…") {
                val p = if (Vault.isPassText(c)) {
                    require(pw.isNotEmpty()) { "برای این متن باید رمز مشترک را وارد کنید." }
                    Vault.decryptTextPass(c, pw)
                } else Vault.decryptText(c)
                ui.post { output.setText(p) }
            }
        }
        fun lname(c: String) = Translator.LANGS.first { it.first == c }.second
        val fb = root.btn("از: ${lname(trFrom)}") {}
        val tb = root.btn("به: ${lname(trTo)}") {}
        fb.setOnClickListener { choose("زبان مبدأ", Translator.LANGS.map { it.second }) { i -> trFrom = Translator.LANGS[i].first; fb.text = "از: ${lname(trFrom)}" } }
        tb.setOnClickListener { choose("زبان مقصد", Translator.LANGS.map { it.second }) { i -> trTo = Translator.LANGS[i].first; tb.text = "به: ${lname(trTo)}" } }
        root.btn("🌐 ترجمه‌ی آفلاین (واژه‌نامه‌ی داخلی)") {
            val (res, unk) = Translator.translate(input.text.toString(), trFrom, trTo)
            output.setText(res)
            if (unk > 0) toast("$unk کلمه در واژه‌نامه نبود و بدون تغییر ماند")
        }
        root.add(text("خروجی", 13f)); root.add(output); root.ioBar(output)
        root.btn("↔️ انتقال خروجی به ورودی") { input.setText(output.text) }
        root.btn("🧹 پاک کردن ورودی و خروجی") { input.text.clear(); output.text.clear() }
        root.back()
    }

    private fun showBinary() {
        val root = page("🔢 تبدیل متن ⇄ کد")
        val cs = Codec.charsets()
        csIdx = csIdx.coerceIn(0, cs.size - 1); baseIdx = baseIdx.coerceIn(0, Codec.BASES.size - 1)
        val input = field("ورودی…", 5); val output = field("نتیجه…", 7)
        val csB = root.btn("زبان / کدگذاری: ${cs[csIdx].first}") {}
        val baseB = root.btn("مبنا: ${Codec.BASES[baseIdx].first}") {}
        csB.setOnClickListener { choose("زبان / کدگذاری", cs.map { it.first }) { i -> csIdx = i; csB.text = "زبان / کدگذاری: ${cs[i].first}" } }
        baseB.setOnClickListener { choose("مبنا", Codec.BASES.map { it.first }) { i -> baseIdx = i; baseB.text = "مبنا: ${Codec.BASES[i].first}" } }
        root.add(input); root.ioBar(input)
        root.btn("متن → کد") {
            try {
                val (res, lossy) = Codec.encode(input.text.toString(), cs[csIdx].second, Codec.BASES[baseIdx].second)
                output.setText(res)
                if (lossy) toast("برخی نویسه‌ها در این کدگذاری وجود ندارند و جایگزین شدند؛ UTF-8 را امتحان کنید")
            } catch (e: Exception) { toast(e.message ?: "تبدیل ناموفق بود") }
        }
        root.btn("کد → متن") {
            try { output.setText(Codec.decode(input.text.toString(), cs[csIdx].second, Codec.BASES[baseIdx].second)) }
            catch (_: Exception) { toast("ورودی برای مبنا/کدگذاری انتخاب‌شده معتبر نیست") }
        }
        root.add(output); root.ioBar(output)
        root.btn("↔️ انتقال نتیجه به ورودی") { input.setText(output.text) }
        root.back()
    }

    // ---------- image stego / file crypto ----------
    private fun showMsgStego() {
        val root = page("🖼️ پیام داخل تصویر")
        root.add(text("هر قالب تصویری (JPG, PNG, WebP, GIF, BMP, HEIC…) پذیرفته می‌شود؛ خروجی را می‌توانید PNG، WebP Lossless یا BMP انتخاب کنید (فقط قالب‌های بدون افت کیفیت می‌توانند داده نگه دارند؛ JPEG داده را از بین می‌برد). ارسال تصویر از طریق پیام‌رسان‌ها (که فشرده می‌کنند) داده را خراب می‌کند؛ آن را به‌صورت «فایل» بفرستید.", 13f))
        val msg = field("پیام…", 6); root.add(msg); root.ioBar(msg)
        val status = text(if (image == null) "تصویری انتخاب نشده (در صورت نیاز، تصویر خودکار ساخته می‌شود)" else "تصویر: ${nameOf(image!!)}", 13f); root.add(status)
        root.btn("🖼️ انتخاب تصویر") { pick("*/*", image = true) { image = it; status.text = "تصویر: ${nameOf(it)}" } }
        root.fmtBtn()
        root.btn("🔐 جاسازی و ذخیره تصویر") {
            val img = image
            val t = Normalizer.normalize(msg.text.toString(), Normalizer.Form.NFC)
            if (t.isBlank()) { toast("پیامی وارد نشده"); return@btn }
            work("در حال جاسازی…") {
                val blob = Vault.encryptBytes(t.toByteArray(Charsets.UTF_8), Vault.AAD_STEGO)
                var bm: Bitmap? = if (img != null) try { loadImage(img, 4096) } catch (_: Exception) { null } else null
                if (bm == null || Stego.maxPayload(bm) < blob.size) {
                    bm = Stego.makeCarrier(blob.size)
                    ui.post { toast("تصویر حامل خودکار ساخته شد") }
                }
                val out = Stego.embed(bm!!, Stego.TYPE_TEXT, blob)
                ui.post { saveImage(out) }
            }
        }
        root.btn("🔓 استخراج پیام") {
            val img = image ?: run { toast("ابتدا تصویر را انتخاب کنید"); return@btn }
            work("در حال استخراج…") {
                val (type, payload) = Stego.extract(loadImage(img))
                require(type == Stego.TYPE_TEXT) { "این تصویر حاوی فایل است نه پیام." }
                val plain = String(Vault.decryptBytes(payload, Vault.AAD_STEGO), Charsets.UTF_8)
                ui.post { msg.setText(plain); status.text = "پیام استخراج شد" }
            }
        }
        root.back()
    }

    private fun showFileCrypto() {
        val root = page("📦 رمزنگاری فایل")
        root.add(text("هر نوع فایلی (سند، عکس، ویدیو، صدا، فشرده، APK…) به‌صورت جریانی پردازش می‌شود. کلید فقط روی همین دستگاه است؛ فایل رمزنگاری‌شده روی دستگاه دیگر یا بعد از حذف برنامه باز نمی‌شود.", 13f))
        root.btn("🔐 انتخاب فایل و رمزنگاری") {
            pick("*/*") { src ->
                val name = nameOf(src)
                work("در حال رمزنگاری…") {
                    val tmp = File(cacheDir, "enc_${System.nanoTime()}")
                    try {
                        openIn(src).use { i -> tmp.outputStream().buffered().use { Vault.encryptStream(i, it) } }
                    } catch (e: Throwable) { tmp.delete(); throw e }
                    ui.post { saveAs("$name.cvf") { u -> finishSave(tmp, u) } }
                }
            }
        }
        root.btn("🔓 انتخاب فایل .cvf و رمزگشایی") {
            pick("*/*") { src ->
                val name = nameOf(src).removeSuffix(".cvf").ifBlank { "decrypted" }
                work("در حال رمزگشایی…") {
                    val tmp = File(cacheDir, "dec_${System.nanoTime()}")
                    try {
                        openIn(src).use { i -> tmp.outputStream().buffered().use { Vault.decryptStream(i, it) } }
                    } catch (e: Throwable) { tmp.delete(); throw e }
                    ui.post { saveAs(name) { u -> finishSave(tmp, u) } }
                }
            }
        }
        root.back()
    }

    private fun showFileStego() {
        val root = page("🖼️📦 فایل داخل تصویر")
        val st = text("", 13f); root.add(st)
        fun refresh() {
            st.text = "فایل: ${file?.let { nameOf(it) } ?: "—"}\nتصویر: ${carrier?.let { nameOf(it) } ?: "—"}"
        }
        refresh()
        root.btn("1) انتخاب فایل (هر قالبی)") { pick("*/*") { file = it; refresh() } }
        root.btn("2) انتخاب تصویر حامل (اختیاری؛ اگر نباشد خودکار ساخته می‌شود)") { pick("*/*", image = true) { carrier = it; refresh() } }
        root.fmtBtn()
        root.btn("3) رمزنگاری، جاسازی و ذخیره تصویر") {
            val f = file; val c = carrier
            if (f == null) { toast("ابتدا فایل را انتخاب کنید"); return@btn }
            work("در حال پردازش…") {
                val name = nameOf(f).toByteArray(Charsets.UTF_8)
                require(name.size < 60000) { "نام فایل خیلی بلند است." }
                val size = contentResolver.openAssetFileDescriptor(f, "r")?.use { it.length } ?: -1L
                require(size < 0 || size <= 6_000_000L) { "این فایل برای جاسازی در تصویر خیلی بزرگ است (حداکثر حدود ۶ مگابایت)؛ از «رمزنگاری فایل» استفاده کنید." }
                val raw = openIn(f).use { it.readBytes() }
                val blob = Vault.encryptBytes(raw, Vault.AAD_STEGO)
                val payload = ByteBuffer.allocate(2 + name.size + blob.size).putShort(name.size.toShort()).put(name).put(blob).array()
                var bm: Bitmap? = if (c != null) try { loadImage(c, 4096) } catch (_: Exception) { null } else null
                if (bm == null || Stego.maxPayload(bm) < payload.size) {
                    bm = Stego.makeCarrier(payload.size)
                    ui.post { toast("تصویر حامل خودکار ساخته شد") }
                }
                val out = Stego.embed(bm!!, Stego.TYPE_FILE, payload)
                ui.post { saveImage(out) }
            }
        }
        root.btn("4) استخراج فایل از تصویر") {
            pick("*/*", image = true) { img ->
                work("در حال استخراج…") {
                    val (type, payload) = Stego.extract(loadImage(img))
                    require(type == Stego.TYPE_FILE) { "این تصویر حاوی فایل نیست." }
                    val bb = ByteBuffer.wrap(payload)
                    val n = bb.short.toInt() and 0xFFFF
                    val nameBytes = ByteArray(n); bb.get(nameBytes)
                    val blob = ByteArray(bb.remaining()); bb.get(blob)
                    val plain = Vault.decryptBytes(blob, Vault.AAD_STEGO)
                    val tmp = File(cacheDir, "ext_${System.nanoTime()}"); tmp.writeBytes(plain)
                    val name = String(nameBytes, Charsets.UTF_8).replace(Regex("[\\\\/]"), "_").ifBlank { "extracted" }
                    ui.post { saveAs(name) { u -> finishSave(tmp, u) } }
                }
            }
        }
        root.back()
    }

    // ---------- audio ----------
    private fun showAudio() {
        val root = page("🎵 صدای ناخوانا ⇄ بازگردانی")
        root.add(text("هر فایل صوتی (MP3، AAC/M4A، OGG، FLAC، WAV، AMR…) یا ویدیو را انتخاب کنید. خروجی یک فایل WAV است که صدا در آن با رمز شما به نویزِ ناخوانا تبدیل شده. برای بازگرداندن، همان WAV خروجی را با همان رمز انتخاب کنید (تشخیص خودکار).\n⚠️ خروجی نویزِ بلند است؛ پیش از پخش صدا را کم کنید. رمز را فراموش نکنید؛ بازیابی ندارد.", 13f))
        val pass = passField("رمز صدا (حداقل ۴ نویسه)"); root.add(pass)
        root.btn("🎵 انتخاب فایل و تبدیل / بازگردانی") {
            val pw = pass.text.toString()
            if (pw.length < 4) { toast("رمز حداقل ۴ نویسه باشد"); return@btn }
            pick("*/*") { src ->
                work("در حال پردازش صدا…") {
                    val out = File(cacheDir, "aud_${System.nanoTime()}")
                    try {
                        val scrambled = Audio.process(this@MainActivity, localCopy(src, "aud"), pw, out)
                        if (Audio.lastRaw) ui.post { toast("قالب صوتی شناسایی نشد؛ بایت‌های فایل به‌صورت خام به نویز تبدیل شد") }
                        val base = nameOf(src).substringBeforeLast('.').ifBlank { "audio" }
                        ui.post { saveAs(if (scrambled) "$base.scrambled.wav" else "$base.restored.wav") { u -> finishSave(out, u) } }
                    } catch (e: Throwable) { out.delete(); throw e }
                }
            }
        }
        root.back()
    }

    // ---------- send message (SMS) with contact picker ----------
    private fun readContact(u: Uri): Pair<String, String>? =
        contentResolver.query(
            u, arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use { c -> if (c.moveToFirst()) (c.getString(0) ?: "") to (c.getString(1) ?: "") else null }

    private fun ensureSms(go: () -> Unit) {
        if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) { go(); return }
        picking = true
        onPerm = { ok -> if (ok) go() else toast("اجازه‌ی ارسال پیامک داده نشد") }
        permReq.launch(Manifest.permission.SEND_SMS)
    }

    @Suppress("DEPRECATION")
    private fun sendSms(num: String, body: String) {
        val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java) else SmsManager.getDefault()
        val parts = sm.divideMessage(body)
        if (parts.size > 1) sm.sendMultipartTextMessage(num, null, parts, null, null)
        else sm.sendTextMessage(num, null, body, null, null)
    }

    private fun showChat() {
        val root = page("📨 ارسال پیام")
        root.add(text("پیام همین‌جا و بدون رفتن به برنامه‌ی پیام‌ها به‌صورت پیامک ارسال می‌شود (هزینه‌ی پیامک اپراتور اعمال می‌شود). پیامک ذاته رمزنگاری‌شده نیست؛ برای محرمانگی «رمز مشترک» بگذارید تا متن قبل از ارسال رمزنگاری شود.", 13f))
        val who = field("شماره‌ی گیرنده (مثلاً +98912…)", 1).apply { inputType = InputType.TYPE_CLASS_PHONE }
        val nameT = text("", 13f).apply { setTextColor(pal.sub) }
        root.add(who); root.add(nameT)
        root.btn("📇 انتخاب از مخاطبین") {
            onContact = { u -> readContact(u)?.let { (n, num) -> who.setText(num); nameT.text = "گیرنده: $n" } }
            picking = true
            try { contactPick.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)) }
            catch (_: Exception) { picking = false; toast("برنامه‌ی مخاطبین پیدا نشد؛ شماره را دستی وارد کنید") }
        }
        val msg = field("متن پیام…", 5); root.add(msg); root.ioBar(msg)
        val pass = passField("رمز مشترک (اختیاری؛ گیرنده با همین برنامه و همین رمز بازش می‌کند)"); root.add(pass)
        val log = text(sent.joinToString("\n\n"), 13f).apply { setTextColor(pal.sub) }
        root.btn("📤 ارسال") {
            val num = who.text.toString().replace(Regex("[\\s\\-()]"), "")
            if (!Regex("^\\+?[0-9]{5,15}$").matches(num)) { toast("شماره‌ی گیرنده معتبر نیست"); return@btn }
            val t = msg.text.toString()
            if (t.isBlank()) { toast("پیامی وارد نشده"); return@btn }
            val pw = pass.text.toString()
            ensureSms {
                work("در حال ارسال…") {
                    val body = if (pw.isEmpty()) t else Vault.encryptTextPass(t, pw)
                    sendSms(num, body)
                    ui.post {
                        sent.add("→ $num: ${if (pw.isEmpty()) t else "🔒 (رمزنگاری‌شده)"}")
                        log.text = sent.joinToString("\n\n"); msg.text.clear(); toast("ارسال شد ✔")
                    }
                }
            }
        }
        root.add(log)
        root.back()
    }

    // ---------- tools (HTML/CSS/JS sandbox) ----------
    private val CSP = "<meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; media-src data:; font-src data:\">"

    private fun showTool(t: Tool, onBack: () -> Unit) {
        killWeb(); onDash = false
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); fitsSystemWindows = true
            setPadding(dp(8), dp(8), dp(8), dp(8)); filterTouchesWhenObscured = true
        }
        col.addView(text(t.name, 18f, true))
        val wv = WebView(this)
        wv.settings.apply {
            javaScriptEnabled = true; allowFileAccess = false; allowContentAccess = false
            domStorageEnabled = false; blockNetworkLoads = true; cacheMode = WebSettings.LOAD_NO_CACHE
            setGeolocationEnabled(false); javaScriptCanOpenWindowsAutomatically = false
        }
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: android.webkit.WebResourceRequest?) = true
        }
        wv.setBackgroundColor(0xFFFFFFFF.toInt())
        wv.loadDataWithBaseURL(null, CSP + t.code, "text/html", "UTF-8", null)
        col.addView(wv, LinearLayout.LayoutParams(-1, 0, 1f))
        col.addView(Button(this).apply {
            text = "↩ بازگشت"; isAllCaps = false; setTextColor(pal.text); background = box(KEY)
            setOnClickListener { killWeb(); onBack() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        web = wv
        setContentView(col)
    }

    private fun showToolEditor(t: Tool?) {
        val root = page(if (t == null || t.id.isEmpty()) "ابزار جدید" else "ویرایش ابزار")
        root.add(text("زبان‌های پشتیبانی‌شده: HTML + CSS + JavaScript. ابزار در یک محیط ایزوله‌ی کاملاً آفلاین (بدون اینترنت و بدون دسترسی به فایل‌ها و داده‌های برنامه) اجرا می‌شود. زبان‌هایی مانند پایتون یا لوا به مفسر جداگانه نیاز دارند و در این نسخه نیستند.", 12f).apply { setTextColor(pal.sub) })
        val name = field("نام ابزار", 1).apply { setText(t?.name ?: "") }
        val code = field("کد HTML / CSS / JavaScript", 14).apply {
            setText(t?.code ?: Samples.BLANK); typeface = Typeface.MONOSPACE
            textDirection = View.TEXT_DIRECTION_LTR; textSize = 12f
        }
        root.add(name); root.add(code); root.ioBar(code)
        fun draft(dash: Boolean) = Tool(t?.id ?: "", name.text.toString().trim(), code.text.toString(), dash)
        root.btn("📚 نمونه‌ها و قالب") {
            choose("نمونه", Samples.ALL.map { it.first }) { i ->
                code.setText(Samples.ALL[i].second); if (name.text.isBlank()) name.setText(Samples.ALL[i].first)
            }
        }
        root.btn("▶️ اجرا و آزمایش") {
            val d = draft(t?.onDash ?: false)
            showTool(Tool(d.id, d.name.ifBlank { "آزمایش" }, d.code, d.onDash)) { showToolEditor(d) }
        }
        fun save(dash: Boolean) {
            val d = draft(dash)
            if (d.name.isEmpty()) { toast("نام ابزار را وارد کنید"); return }
            work("در حال ذخیره…") {
                Store.save(this@MainActivity, d)
                ui.post { toast("ذخیره شد ✔"); showAdmin() }
            }
        }
        root.btn("💾 ذخیره (فقط در پنل مدیریت)") { save(false) }
        root.btn("📌 ذخیره و افزودن به منوی برنامه") { save(true) }
        root.btn("📤 خروجی گرفتن (فایل .html برای انتقال به دستگاه دیگر)") {
            val d = draft(false)
            val fn = (d.name.ifEmpty { "tool" }).replace(Regex("[\\\\/:*?\"<>|]"), "_") + ".html"
            saveAs(fn) { u -> if (u != null) work("در حال ذخیره…") { writeTo(u) { it.write(d.code.toByteArray(Charsets.UTF_8)) }; ui.post { toast("ذخیره شد ✔") } } }
        }
        if (t != null && t.id.isNotEmpty()) root.btn("🗑️ حذف ابزار") {
            confirm("این ابزار حذف شود؟") { Store.delete(this, t.id); showAdmin() }
        }
        root.btn("↩ بازگشت به پنل مدیریت") { showAdmin() }
    }

    // ---------- change unlock code ----------
    private fun showChangeCode(target: Role) {
        val me = role ?: return
        if (!me.admin && me != target) { showDashboard(); return }
        val root = page("🔑 تغییر کد ورود — ${target.title}")
        root.add(text("دقیقاً همان دنباله‌ای را با کلیدهای زیر بزنید که می‌خواهید روی ماشین‌حساب (بعد از AC) وارد کنید. کد باید با یکی از sin/cos/tan/cot شروع شود و ۸ تا ۲۴ نویسه باشد (هر کلید sin/cos/tan/cot سه نویسه حساب می‌شود). برای تأیید، کد را دوبار وارد کنید. کد فقط به‌صورت هش روی همین دستگاه ذخیره می‌شود و آفلاین کار می‌کند.", 13f))
        val toks = ArrayList<String>()
        var first: String? = null
        val info = text("", 15f, true)
        fun seq() = toks.joinToString("")
        fun refresh() { info.text = (if (first == null) "کد جدید" else "تکرار کد") + ":  " + "●".repeat(toks.size) + "   (${seq().length} نویسه)" }
        refresh(); root.add(info)
        fun keyRow(vararg ks: String) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
            ks.forEach { k ->
                r.addView(Button(this).apply {
                    text = k.lowercase(); isAllCaps = false; setTextColor(pal.text); background = box(KEY)
                    setOnClickListener {
                        if (seq().length + k.length > Gate.MAX_SEQ) toast("حداکثر ۲۴ نویسه") else { toks.add(k); refresh() }
                    }
                }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
            }
            root.add(r)
        }
        keyRow("Sin", "Cos", "Tan", "Cot")
        keyRow("7", "8", "9", "/")
        keyRow("4", "5", "6", "*")
        keyRow("1", "2", "3", "-")
        keyRow("0", ".", "=", "+")
        keyRow("%")
        root.btn("⌫ حذف آخرین کلید") { if (toks.isNotEmpty()) { toks.removeAt(toks.size - 1); refresh() } }
        root.btn("🧹 پاک کردن") { toks.clear(); refresh() }
        root.btn("✔ ثبت / تأیید") {
            val s = seq()
            if (first == null) {
                if (s.length < Gate.MIN_SEQ) { toast("حداقل ۸ نویسه لازم است"); return@btn }
                if (Gate.FUNCS.none { s.startsWith(it) }) { toast("کد باید با sin/cos/tan/cot شروع شود"); return@btn }
                first = s; toks.clear(); refresh()
            } else {
                if (s != first) { first = null; toks.clear(); refresh(); toast("دو کد یکسان نبود؛ از اول شروع کنید"); return@btn }
                work("در حال ذخیره…") {
                    val err = Gate.setCode(this@MainActivity, target, s)
                    ui.post {
                        if (err != null) { first = null; toks.clear(); refresh(); toast(err) }
                        else { toast("کد جدید ذخیره شد ✔"); if (me.admin) showAdmin() else showDashboard() }
                    }
                }
            }
        }
        root.btn("↩ بازگشت") { if (me.admin) showAdmin() else showDashboard() }
    }

    // ---------- admin panel ----------
    private fun showAdmin() {
        val me = role
        if (me == null || !me.admin) { showDashboard(); return }
        val root = page("⚙️ پنل مدیریت")
        root.add(text("قفل ورود: ${if (Gate.lockedForMs(this) > 0) "فعال" else "غیرفعال"}", 13f).apply { setTextColor(pal.sub) })

        root.add(text("🎨 تم برنامه (روی ماشین‌حساب هم اعمال می‌شود؛ نگه داشتن انگشت روی نمایشگر ماشین‌حساب هم تم را عوض می‌کند)", 14f, true))
        Themes.ALL.forEachIndexed { i, p ->
            val b = root.btn((if (i == Store.theme(this)) "✔ " else "") + p.name) {
                Store.setTheme(this, i); pal = p; applyTheme(); showAdmin()
            }
            b.setTextColor(p.text)
            b.background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(p.bg); setStroke(dp(3), p.acc) }
        }

        root.add(text("⏱️ قفل خودکار", 14f, true))
        root.btn("زمان قفل خودکار: ${Store.lockMin(this)} دقیقه") {
            val mins = intArrayOf(5, 15, 30, 60)
            choose("زمان قفل خودکار", mins.map { "$it دقیقه" }) { i -> Store.setLockMin(this, mins[i]); showAdmin() }
        }
        root.btn("🔓 پاک کردن شمارنده‌ی تلاش‌های ناموفق / قفل ورود") { Gate.clearLock(this); toast("انجام شد"); showAdmin() }

        root.add(text("🔑 کدهای ورود (هر دستگاه مستقل و آفلاین)", 14f, true))
        Role.values().forEach { r ->
            root.btn("تغییر کد «${r.title}»${if (Gate.isCustom(this, r)) " (سفارشی)" else ""}") { showChangeCode(r) }
        }
        root.btn("↩️ بازگرداندن همه‌ی کدها به پیش‌فرض") {
            confirm("همه‌ی کدهای سفارشی حذف و کدهای پیش‌فرض برنامه برگردانده شود؟") {
                Role.values().forEach { Gate.resetCode(this, it) }; toast("انجام شد"); showAdmin()
            }
        }

        root.add(text("🧩 ابزارها و بازی‌های کوچک (HTML/CSS/JS)", 14f, true))
        root.btn("➕ ابزار جدید") { showToolEditor(null) }
        Store.tools(this).forEach { t -> root.btn("${if (t.onDash) "📌 " else ""}${t.name}") { showToolEditor(t) } }
        root.btn("📥 وارد کردن ابزار از فایل (.html)") {
            pick("*/*") { src ->
                val nm = nameOf(src).substringBeforeLast('.').ifBlank { "ابزار وارد‌شده" }
                work("در حال وارد کردن…") {
                    val txt = openIn(src).use { it.readBytes() }
                    require(txt.size <= 2_000_000) { "فایل بیش از ۲ مگابایت است." }
                    Store.save(this@MainActivity, Tool("", nm, String(txt, Charsets.UTF_8), false))
                    ui.post { toast("وارد شد ✔"); showAdmin() }
                }
            }
        }

        root.add(text("🧹 نگهداری", 14f, true))
        root.btn("پاک‌سازی فایل‌های موقت") { cacheDir.listFiles()?.forEach { if (it.isFile) it.delete() }; toast("انجام شد") }
        root.btn("🛡️ وضعیت امنیتی") { showSecurity() }
        root.back()
    }

    private fun showSecurity() {
        val root = page("🛡️ وضعیت امنیتی")
        root.add(text(
            "• برنامه مجوز اینترنت ندارد و کاملاً آفلاین کار می‌کند (فقط اگر خودتان «ارسال پیامک» را بزنید، مجوز SMS خواسته می‌شود)\n" +
            "• ضبط صفحه و اسکرین‌شات مسدود است و پیش‌نمایش برنامه‌های اخیر خالی است\n" +
            "• بکاپ ابری غیرفعال است\n" +
            "• کلید رمزنگاری در Android Keystore است و از دستگاه خارج نمی‌شود\n" +
            "• کدهای ورود فقط به‌صورت هش PBKDF2 ذخیره می‌شوند؛ تلاش‌های ناموفق قفل افزایشی دارند\n" +
            "• با خروج از برنامه یا بعد از ${Store.lockMin(this)} دقیقه قفل خودکار فعال می‌شود\n" +
            "• ابزارهای سفارشی در محیط ایزوله‌ی بدون شبکه و بدون دسترسی به داده‌های برنامه اجرا می‌شوند\n" +
            "• فایل‌های موقت هنگام شروع برنامه پاک می‌شوند\n" +
            "هیچ برنامه‌ای «نفوذناپذیر» نیست؛ اگر گوشی روت‌شده یا آلوده باشد این حفاظت‌ها محدود می‌شوند.", 14f
        ))
        root.back()
    }
}
