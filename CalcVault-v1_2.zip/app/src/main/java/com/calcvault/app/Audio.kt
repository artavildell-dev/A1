package com.calcvault.app

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher

/**
 * Voice scrambler. Any audio (mp3, aac/m4a, ogg, flac, wav, amr, video soundtrack...) is decoded to 16-bit PCM
 * and XOR-ed with an AES-CTR keystream derived from a passphrase -> unintelligible noise stored as WAV.
 * Feeding that WAV back with the same passphrase restores the original PCM exactly (as a WAV file).
 */
object Audio {
    private class Wav(val ch: Int, val rate: Int, val bits: Int, val dataOff: Long, val dataLen: Long, val marker: ByteArray?)

    private fun check(key: ByteArray) =
        MessageDigest.getInstance("SHA-256").digest(key + "cvchk".toByteArray()).copyOf(8)

    /** Returns true if the output is scrambled noise, false if the original sound was restored. */
    fun process(ctx: Context, src: Uri, pass: String, dst: File): Boolean {
        val tmp = File(ctx.cacheDir, "au_${System.nanoTime()}")
        try {
            ctx.contentResolver.openInputStream(src)!!.use { i -> tmp.outputStream().use { i.copyTo(it, 64 * 1024) } }
            val w = parseWav(tmp)
            if (w != null) {
                require(w.bits == 16) { "فقط فایل WAV ۱۶ بیتی پشتیبانی می‌شود؛ آن را به MP3/M4A یا WAV ۱۶ بیتی تبدیل کنید." }
                val m = w.marker
                if (m != null) {                                   // restore
                    val salt = m.copyOfRange(0, 16); val iv = m.copyOfRange(16, 32)
                    val key = Vault.deriveKey(pass, salt)
                    require(MessageDigest.isEqual(check(key), m.copyOfRange(32, 40))) { "رمز اشتباه است." }
                    writeWav(tmp, w.dataOff, w.dataLen, w.ch, w.rate, null, dst, Vault.ctr(key, iv))
                    return false
                }
                scramble(tmp, w.dataOff, w.dataLen, w.ch, w.rate, pass, dst)
                return true
            }
            val pcm = File(ctx.cacheDir, "pcm_${System.nanoTime()}")
            try {
                val (rate, ch) = decodeToPcm(ctx, src, pcm)
                scramble(pcm, 0L, pcm.length(), ch, rate, pass, dst)
            } finally { pcm.delete() }
            return true
        } finally { tmp.delete() }
    }

    private fun scramble(f: File, off: Long, len: Long, ch: Int, rate: Int, pass: String, dst: File) {
        val rnd = SecureRandom()
        val salt = ByteArray(16).also { rnd.nextBytes(it) }
        val iv = ByteArray(16).also { rnd.nextBytes(it) }
        val key = Vault.deriveKey(pass, salt)
        writeWav(f, off, len, ch, rate, salt + iv + check(key), dst, Vault.ctr(key, iv))
    }

    private fun writeWav(src: File, off: Long, len: Long, ch: Int, rate: Int, marker: ByteArray?, dst: File, c: Cipher) {
        require(len in 0..1_500_000_000L) { "فایل صوتی خیلی بزرگ است." }
        val extra = if (marker != null) 8 + marker.size else 0
        val h = ByteBuffer.allocate(44 + extra).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()).putInt((36 + extra + len).toInt()).put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(ch.toShort()).putInt(rate)
        h.putInt(rate * ch * 2).putShort((ch * 2).toShort()).putShort(16)
        if (marker != null) h.put("cvlt".toByteArray()).putInt(marker.size).put(marker)
        h.put("data".toByteArray()).putInt(len.toInt())
        dst.outputStream().buffered().use { o ->
            o.write(h.array())
            RandomAccessFile(src, "r").use { r ->
                r.seek(off)
                val buf = ByteArray(64 * 1024)
                var left = len
                while (left > 0) {
                    val n = r.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (n <= 0) break
                    c.update(buf, 0, n)?.let { o.write(it) }
                    left -= n
                }
            }
        }
    }

    private fun parseWav(f: File): Wav? = RandomAccessFile(f, "r").use { r ->
        if (r.length() < 12) return null
        val h = ByteArray(12); r.readFully(h)
        if (String(h, 0, 4, Charsets.US_ASCII) != "RIFF" || String(h, 8, 4, Charsets.US_ASCII) != "WAVE") return null
        var ch = 0; var rate = 0; var bits = 0; var marker: ByteArray? = null
        var pos = 12L
        while (pos + 8 <= r.length()) {
            r.seek(pos)
            val hd = ByteArray(8); r.readFully(hd)
            val id = String(hd, 0, 4, Charsets.US_ASCII)
            val size = ByteBuffer.wrap(hd, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xFFFFFFFFL
            val body = pos + 8
            when (id) {
                "fmt " -> {
                    val b = ByteArray(16); r.readFully(b)
                    val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
                    val tag = bb.short.toInt() and 0xFFFF
                    ch = bb.short.toInt(); rate = bb.int; bb.int; bb.short; bits = bb.short.toInt()
                    require(tag == 1) { "این WAV از نوع PCM ساده نیست." }
                    require(ch in 1..8 && rate > 0) { "هدر WAV نامعتبر است." }
                }
                "cvlt" -> if (size >= 40) { val b = ByteArray(40); r.readFully(b); marker = b }
                "data" -> {
                    require(ch > 0) { "هدر WAV نامعتبر است." }
                    return Wav(ch, rate, bits, body, minOf(size, r.length() - body), marker)
                }
            }
            pos = body + size + (size and 1L)
        }
        null
    }

    /** MediaExtractor + MediaCodec -> raw 16-bit PCM file. Returns (sampleRate, channels). */
    private fun decodeToPcm(ctx: Context, src: Uri, out: File): Pair<Int, Int> {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, src, null)
            var idx = -1; var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { idx = i; fmt = f; break }
            }
            require(idx >= 0 && fmt != null) { "در این فایل صدایی پیدا نشد یا قالب آن پشتیبانی نمی‌شود." }
            ex.selectTrack(idx)
            var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val c = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec = c
            c.configure(fmt, null, null, 0); c.start()
            val info = MediaCodec.BufferInfo()
            var inDone = false; var outDone = false
            out.outputStream().buffered().use { os ->
                while (!outDone) {
                    if (!inDone) {
                        val i = c.dequeueInputBuffer(10_000)
                        if (i >= 0) {
                            val buf = c.getInputBuffer(i)!!
                            val n = ex.readSampleData(buf, 0)
                            if (n < 0) { c.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                            else { c.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance() }
                        }
                    }
                    val o = c.dequeueOutputBuffer(info, 10_000)
                    if (o >= 0) {
                        if (info.size > 0) {
                            val b = c.getOutputBuffer(o)!!
                            b.position(info.offset); b.limit(info.offset + info.size)
                            val bytes = ByteArray(info.size); b.get(bytes)
                            os.write(bytes)
                        }
                        c.releaseOutputBuffer(o, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                    } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val nf = c.outputFormat
                        rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        if (nf.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                            nf.getInteger(MediaFormat.KEY_PCM_ENCODING) != AudioFormat.ENCODING_PCM_16BIT)
                            throw IllegalArgumentException("خروجی دیکدر ۱۶ بیتی نیست و پشتیبانی نمی‌شود.")
                    }
                }
            }
            return rate to ch
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            ex.release()
        }
    }
}
