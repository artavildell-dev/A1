package com.calcvault.app

import java.nio.charset.Charset
import java.util.Base64

/** Text <-> bytes in many national encodings, shown as binary / octal / decimal / hex / Base64. */
object Codec {
    private val ALL = listOf(
        "UTF-8 (همه زبان‌ها)" to "UTF-8",
        "UTF-16 (همه زبان‌ها)" to "UTF-16BE",
        "UTF-32 (همه زبان‌ها)" to "UTF-32BE",
        "ASCII (انگلیسی)" to "US-ASCII",
        "ISO-8859-1 (فرانسوی، آلمانی، اسپانیایی، ایتالیایی…)" to "ISO-8859-1",
        "ISO-8859-2 (لهستانی، چکی، مجاری…)" to "ISO-8859-2",
        "ISO-8859-15 (اروپای غربی + یورو)" to "ISO-8859-15",
        "Windows-1256 (فارسی / عربی / اردو)" to "windows-1256",
        "ISO-8859-6 (عربی)" to "ISO-8859-6",
        "Windows-1251 (روسی، اوکراینی، بلغاری، صربی)" to "windows-1251",
        "KOI8-R (روسی)" to "KOI8-R",
        "Windows-1254 (ترکی)" to "windows-1254",
        "Windows-1253 (یونانی)" to "windows-1253",
        "Windows-1255 (عبری)" to "windows-1255",
        "Windows-1258 (ویتنامی)" to "windows-1258",
        "TIS-620 (تایلندی)" to "TIS-620",
        "Shift_JIS (ژاپنی)" to "Shift_JIS",
        "EUC-KR (کره‌ای)" to "EUC-KR",
        "GBK (چینی ساده)" to "GBK",
        "Big5 (چینی سنتی)" to "Big5"
    )

    val BASES = listOf("Binary (مبنای ۲)" to 2, "Octal (مبنای ۸)" to 8, "Decimal (مبنای ۱۰)" to 10, "Hex (مبنای ۱۶)" to 16, "Base64" to 64)

    /** Only encodings that exist on this device. */
    fun charsets(): List<Pair<String, String>> = ALL.filter {
        try { Charset.isSupported(it.second) } catch (_: Exception) { false }
    }

    /** Returns the code and whether some characters could not be represented in the chosen encoding. */
    fun encode(text: String, csName: String, radix: Int): Pair<String, Boolean> {
        val cs = Charset.forName(csName)
        val bytes = text.toByteArray(cs)
        val lossy = String(bytes, cs) != text
        val s = when (radix) {
            2 -> bytes.joinToString(" ") { (it.toInt() and 255).toString(2).padStart(8, '0') }
            8 -> bytes.joinToString(" ") { (it.toInt() and 255).toString(8).padStart(3, '0') }
            10 -> bytes.joinToString(" ") { (it.toInt() and 255).toString() }
            16 -> bytes.joinToString(" ") { (it.toInt() and 255).toString(16).padStart(2, '0') }
            else -> Base64.getEncoder().encodeToString(bytes)
        }
        return s to lossy
    }

    fun decode(code: String, csName: String, radix: Int): String {
        val cs = Charset.forName(csName)
        val bytes: ByteArray = if (radix == 64) {
            Base64.getDecoder().decode(code.replace(Regex("\\s"), ""))
        } else {
            var parts = code.trim().split(Regex("[\\s,;]+")).filter { it.isNotEmpty() }
            val w = when (radix) { 2 -> 8; 8 -> 3; 16 -> 2; else -> 0 }
            if (w > 0 && parts.size == 1 && parts[0].length > w && parts[0].length % w == 0) parts = parts[0].chunked(w)
            ByteArray(parts.size) {
                val v = parts[it].removePrefix("0x").toInt(radix)
                require(v in 0..255) { "مقدار خارج از محدوده‌ی بایت (۰ تا ۲۵۵) است." }
                v.toByte()
            }
        }
        return String(bytes, cs)
    }
}
