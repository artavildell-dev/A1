package com.calcvault.app

class Palette(
    val name: String, val bg: Int, val key: Int, val line: Int, val acc: Int, val red: Int,
    val field: Int, val sub: Int, val text: Int = 0xFFFFFFFF.toInt(), val light: Boolean = false
)

object Themes {
    val ALL = listOf(
        Palette("🟢 سبز (پیش‌فرض)", 0xFF0B1211.toInt(), 0xFF172827.toInt(), 0xFF38514D.toInt(), 0xFF287E6D.toInt(), 0xFF613D45.toInt(), 0xFF111C1B.toInt(), 0xFF8CA9A3.toInt()),
        Palette("🔵 آبی", 0xFF0A1220.toInt(), 0xFF152238.toInt(), 0xFF34507A.toInt(), 0xFF2D6CDF.toInt(), 0xFF5E3A48.toInt(), 0xFF0F1A2C.toInt(), 0xFF8CA3C9.toInt()),
        Palette("🟣 بنفش", 0xFF130E1F.toInt(), 0xFF221A38.toInt(), 0xFF4B3C78.toInt(), 0xFF7B4DD8.toInt(), 0xFF5E3350.toInt(), 0xFF1A1430.toInt(), 0xFFA99CCB.toInt()),
        Palette("🟠 نارنجی", 0xFF1A1109.toInt(), 0xFF2E2013.toInt(), 0xFF6B4A28.toInt(), 0xFFD9791F.toInt(), 0xFF6B3030.toInt(), 0xFF231809.toInt(), 0xFFCDA878.toInt()),
        Palette("🌸 صورتی", 0xFF1C0F16.toInt(), 0xFF33202B.toInt(), 0xFF74455D.toInt(), 0xFFD6477F.toInt(), 0xFF5A3A3A.toInt(), 0xFF26141D.toInt(), 0xFFD0A0B8.toInt()),
        Palette("⚫🟡 مشکی/طلایی", 0xFF0A0A0A.toInt(), 0xFF1C1C1C.toInt(), 0xFF5A4A1E.toInt(), 0xFFC9A227.toInt(), 0xFF5A2A2A.toInt(), 0xFF141414.toInt(), 0xFFB8A66A.toInt()),
        Palette("⚪ روشن", 0xFFF2F5F4.toInt(), 0xFFDCE5E3.toInt(), 0xFFA7B8B4.toInt(), 0xFF7FCDBB.toInt(), 0xFFE2B8BE.toInt(), 0xFFFFFFFF.toInt(), 0xFF55706B.toInt(), 0xFF101818.toInt(), true)
    )
}
