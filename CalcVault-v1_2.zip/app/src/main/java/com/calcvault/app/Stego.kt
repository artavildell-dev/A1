package com.calcvault.app

import android.graphics.Bitmap
import android.content.ContentResolver
import android.graphics.BitmapFactory
import android.graphics.ColorSpace
import android.graphics.ImageDecoder
import android.os.Build
import android.net.Uri
import java.nio.ByteBuffer
import java.security.MessageDigest

/** LSB steganography: 1 bit in each of R, G, B. Output must be saved as lossless PNG. */
object Stego {
    const val TYPE_TEXT = 1
    const val TYPE_FILE = 2
    private val MAGIC = "CVS1".toByteArray(Charsets.US_ASCII)
    private const val HEADER = 4 + 1 + 4 + 32

    fun capacity(w: Int, h: Int): Long = w.toLong() * h * 3 / 8
    fun maxPayload(bm: Bitmap): Long = capacity(bm.width, bm.height) - HEADER

    fun embed(src: Bitmap, type: Int, payload: ByteArray): Bitmap {
        val w = src.width; val h = src.height
        require(HEADER.toLong() + payload.size <= capacity(w, h)) { "ظرفیت تصویر کافی نیست." }
        val head = ByteBuffer.allocate(HEADER).put(MAGIC).put(type.toByte()).putInt(payload.size)
            .put(MessageDigest.getInstance("SHA-256").digest(payload)).array()
        val data = head + payload
        val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
        val total = data.size * 8
        var bit = 0
        for (i in px.indices) {
            var p = px[i] or (0xFF shl 24)                 // force opaque so RGB survives PNG round-trip
            if (bit < total) {
                for (shift in intArrayOf(16, 8, 0)) {
                    if (bit < total) {
                        val v = (data[bit ushr 3].toInt() ushr (7 - (bit and 7))) and 1
                        p = (p and (1 shl shift).inv()) or (v shl shift)
                        bit++
                    }
                }
            }
            px[i] = p
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setHasAlpha(false)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    fun extract(bm: Bitmap): Pair<Int, ByteArray> {
        val w = bm.width; val h = bm.height
        require(capacity(w, h) >= HEADER) { "تصویر خیلی کوچک است." }
        val px = IntArray(w * h); bm.getPixels(px, 0, w, 0, 0, w, h)
        val head = readBytes(px, 0, HEADER)
        require(head.copyOfRange(0, 4).contentEquals(MAGIC)) { "داده‌ای در این تصویر پیدا نشد." }
        val type = head[4].toInt()
        val len = ByteBuffer.wrap(head, 5, 4).int
        require(len >= 0 && HEADER.toLong() + len <= capacity(w, h)) { "طول داده نامعتبر است." }
        val payload = readBytes(px, HEADER, len)
        val ok = MessageDigest.isEqual(head.copyOfRange(9, 41), MessageDigest.getInstance("SHA-256").digest(payload))
        require(ok) { "داده‌ی داخل تصویر خراب یا دستکاری شده است." }
        return type to payload
    }

    private fun readBytes(px: IntArray, startByte: Int, len: Int): ByteArray {
        val out = ByteArray(len)
        var pos = startByte.toLong() * 8
        for (n in 0 until len) {
            var b = 0
            for (k in 0 until 8) {
                val p = px[(pos / 3).toInt()]
                val bit = (when ((pos % 3).toInt()) { 0 -> p ushr 16; 1 -> p ushr 8; else -> p }) and 1
                b = (b shl 1) or bit; pos++
            }
            out[n] = b.toByte()
        }
        return out
    }

    /** Decodes any image format the device supports (JPEG, PNG, WebP, GIF, BMP, ICO, HEIC/HEIF, AVIF...). */
    fun decode(cr: ContentResolver, uri: Uri): Bitmap {
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                val bm = ImageDecoder.decodeBitmap(ImageDecoder.createSource(cr, uri)) { dec, _, _ ->
                    dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    dec.setTargetColorSpace(ColorSpace.get(ColorSpace.Named.SRGB))
                }
                return if (bm.config == Bitmap.Config.ARGB_8888) bm else bm.copy(Bitmap.Config.ARGB_8888, false)
            } catch (_: Exception) { /* fall back to BitmapFactory */ }
        }
        val opts = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inPreferredColorSpace = ColorSpace.get(ColorSpace.Named.SRGB)
        }
        cr.openInputStream(uri)?.use { s ->
            return BitmapFactory.decodeStream(s, null, opts) ?: error("قالب این تصویر روی این دستگاه پشتیبانی نمی‌شود.")
        }
        error("تصویر قابل خواندن نیست.")
    }
}
