package com.calcvault.app

import android.content.Context
import android.os.Handler
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.Executor
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Hidden entry. The unlock code is a KEY SEQUENCE (sin/cos/tan/cot keys count as "Sin"/"Cos"/"Tan"/"Cot",
 * other keys as themselves, "=" included). Only salted PBKDF2 hashes of the codes are stored.
 * Codes can be replaced per device (stored in private prefs as hash only); defaults come from GateHashes.
 */
object Gate {
    private const val PREFS = "gate_guard"
    private const val CODES = "gate_codes"
    private const val FREE_TRIES = 5
    private const val BASE_LOCK_MS = 30_000L
    private const val MAX_LOCK_MS = 15 * 60_000L
    const val MAX_SEQ = 24
    const val MIN_SEQ = 8
    const val MIN_FAIL_LEN = 8
    val FUNCS = setOf("Sin", "Cos", "Tan", "Cot")

    fun entries(ctx: Context): List<GateHashes.Entry> {
        val p = ctx.getSharedPreferences(CODES, Context.MODE_PRIVATE)
        return GateHashes.ENTRIES.map { d ->
            val x = p.getString(d.role, null)?.split("|")
            val len = x?.getOrNull(0)?.toIntOrNull()
            if (x != null && x.size == 4 && len != null) GateHashes.Entry(d.role, len, x[1], x[2], x[3]) else d
        }
    }

    fun isCustom(ctx: Context, role: Role) =
        ctx.getSharedPreferences(CODES, Context.MODE_PRIVATE).contains(role.name)

    fun hasLength(ctx: Context, n: Int) = entries(ctx).any { it.len == n }

    fun lockedForMs(ctx: Context): Long {
        val until = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("until", 0L)
        return (until - System.currentTimeMillis()).coerceAtLeast(0L)
    }

    private fun pbkdf(seq: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(seq.toCharArray(), salt, GateHashes.ITER, 256)).encoded

    /** Blocking (PBKDF2): call off the UI thread. Wrong guesses are counted by the Tracker, not here. */
    fun verify(ctx: Context, seq: String): Role? {
        if (lockedForMs(ctx) > 0) return null
        var hit: Role? = null
        for (e in entries(ctx)) {
            if (e.len != seq.length || !seq.startsWith(e.prefix)) continue
            val h = pbkdf(seq, unhex(e.salt))
            if (MessageDigest.isEqual(h, unhex(e.hash)) && hit == null) hit = Role.valueOf(e.role)
        }
        if (hit != null) ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        return hit
    }

    /** Blocking. Returns an error message, or null when the new code was stored (hash only). */
    fun setCode(ctx: Context, role: Role, seq: String): String? {
        if (seq.length !in MIN_SEQ..MAX_SEQ) return "طول کد باید بین ۸ تا ۲۴ نویسه باشد."
        if (FUNCS.none { seq.startsWith(it) }) return "کد باید با یکی از کلیدهای sin / cos / tan / cot شروع شود."
        // A valid calculation ends the code attempt, so every "=" inside a code must hit an invalid expression.
        val sb = StringBuilder()
        for (m in Regex("Sin|Cos|Tan|Cot|.").findAll(seq)) {
            val t = m.value
            if (t == "(" || t == ")" || t == "#") return "کاراکتر نامعتبر در کد."
            if (t == "=") {
                val ok = sb.isNotEmpty() && try { Calc.eval(sb.toString(), Angle.DEG, 0.0); true } catch (_: Exception) { false }
                if (ok) return "این دنباله پیش از «=» یک عبارت ریاضی معتبر می‌سازد و ماشین‌حساب آن را محاسبه می‌کند؛ دنباله‌ی دیگری انتخاب کنید."
            } else sb.append(when (t) { "Sin" -> "sin("; "Cos" -> "cos("; "Tan" -> "tan("; "Cot" -> "cot("; else -> t })
        }
        for (e in entries(ctx)) {
            if (e.role == role.name) continue
            if (e.len <= seq.length && seq.startsWith(e.prefix)) {
                val h = pbkdf(seq.substring(0, e.len), unhex(e.salt))
                if (MessageDigest.isEqual(h, unhex(e.hash))) return "این کد با کد یک سطح دیگر تداخل دارد؛ کد دیگری انتخاب کنید."
            }
        }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = pbkdf(seq, salt)
        ctx.getSharedPreferences(CODES, Context.MODE_PRIVATE).edit()
            .putString(role.name, "${seq.length}|${seq.substring(0, 3)}|${hex(salt)}|${hex(hash)}").apply()
        return null
    }

    fun resetCode(ctx: Context, role: Role) {
        ctx.getSharedPreferences(CODES, Context.MODE_PRIVATE).edit().remove(role.name).apply()
    }

    fun clearLock(ctx: Context) { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply() }

    fun fail(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val n = p.getInt("fails", 0) + 1
        val ed = p.edit().putInt("fails", n)
        if (n >= FREE_TRIES) {
            val lock = (BASE_LOCK_MS shl (n - FREE_TRIES).coerceAtMost(10)).coerceAtMost(MAX_LOCK_MS)
            ed.putLong("until", System.currentTimeMillis() + lock)
        }
        ed.apply()
    }

    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    private fun unhex(s: String) = ByteArray(s.length / 2) {
        ((Character.digit(s[it * 2], 16) shl 4) or Character.digit(s[it * 2 + 1], 16)).toByte()
    }

    class Tracker(
        private val ctx: Context, private val exec: Executor, private val ui: Handler,
        private val onRole: (Role) -> Unit
    ) {
        private val tokens = ArrayList<String>()

        fun key(token: String) {
            if (token == "(" || token == ")") { tokens.clear(); return }       // real calculation, not a code
            if (tokens.isEmpty() && token !in FUNCS) return
            tokens.add(token)
            val seq = tokens.joinToString("")
            if (seq.length > MAX_SEQ) { fail(ctx); tokens.clear(); return }
            if (hasLength(ctx, seq.length)) exec.execute {
                val r = try { verify(ctx, seq) } catch (_: Throwable) { null }
                if (r != null) ui.post { tokens.clear(); onRole(r) }
            }
        }

        fun back() { if (tokens.isNotEmpty()) tokens.removeAt(tokens.size - 1) }

        /** AC pressed: an abandoned long sequence counts as one failed attempt. */
        fun clear() {
            if (tokens.joinToString("").length >= MIN_FAIL_LEN) fail(ctx)
            tokens.clear()
        }

        /** Silent reset (valid calculation finished, lock, start-up). */
        fun reset() = tokens.clear()
    }
}
