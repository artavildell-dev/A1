# keep enum names used for stored role keys
-keep class com.calcvault.app.Role { *; }
