# Artar Studio Pro — Trust Rule

Every capability is assigned exactly one status and the same status is shown in the Android UI.

- **IMPLEMENTED** — the capability is implemented in the Android code and does not require a separate ML model to claim the core operation.
- **MODEL-DEPENDENT** — the capability is implemented, but its real execution depends on an ML Kit/Tesseract/runtime model or engine.
- **PLANNED** — not implemented yet. It must not be described as working.

## Current status

### IMPLEMENTED
Brightness, Contrast, Saturation, B&W, Cinematic, Warm, Cool, Auto Enhance, Rotate, Flip, Crop, social crops, Glitch, Kaleidoscope, Relight, Pixelate, Edge Sketch, Thermal, Vignette, Film Grain, Ghost, Negative, Sepia, Invert, Text, Brush, Eraser, Mask, Layers, Templates, Batch, Save/Load Project, PNG, JPG, PDF, Offline Command, Quick Background Cut (heuristic).

### MODEL-DEPENDENT
AI Smart Enhance, AI Image Analysis, ML Kit Latin OCR, Tesseract Persian/English OCR, Face Detection, Image Labeling, Barcode/QR.

### PLANNED
Generative Fill, True Super Resolution, Deblur model, Colorization model, Generative/model-based background segmentation.

The UI uses these exact strings: `IMPLEMENTED`, `MODEL-DEPENDENT`, and `PLANNED`.
