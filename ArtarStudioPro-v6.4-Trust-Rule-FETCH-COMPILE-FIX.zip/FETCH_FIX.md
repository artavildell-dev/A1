# Fetch error fix

The previous workflow downloaded Tesseract models with `curl` from GitHub during the build. That network fetch could fail and stop the build before Gradle ran.

This version removes that runtime fetch completely. Both required model files are already bundled under:

`app/src/main/assets/tessdata/fas.traineddata`
`app/src/main/assets/tessdata/eng.traineddata`

The workflow verifies them with `test -s` instead of downloading them.
