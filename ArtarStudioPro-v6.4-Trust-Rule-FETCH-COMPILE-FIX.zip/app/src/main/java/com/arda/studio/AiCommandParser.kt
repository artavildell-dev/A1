package com.arda.studio

/** Pure, offline command parser used by the AI assistant command UI. */
object AiCommandParser {
    enum class Action { GRAYSCALE, WARM, COOL, BRIGHTEN, CONTRAST, SQUARE_CROP, ROTATE, BACKGROUND_CUT }

    fun parse(input: String): Set<Action> {
        val x = input.lowercase()
        return buildSet {
            if ("سیاه" in x || "سیاه‌وسفید" in x || "black" in x || "bw" in x) add(Action.GRAYSCALE)
            if ("گرم" in x || "warm" in x) add(Action.WARM)
            if ("سرد" in x || "cool" in x) add(Action.COOL)
            if ("روشن" in x || "bright" in x || "brightness" in x) add(Action.BRIGHTEN)
            if ("کنتراست" in x || "contrast" in x) add(Action.CONTRAST)
            if ("مربع" in x || "square" in x) add(Action.SQUARE_CROP)
            if ("چرخ" in x || "rotate" in x) add(Action.ROTATE)
            if ("پس زمینه" in x || "پس‌زمینه" in x || "background" in x) add(Action.BACKGROUND_CUT)
        }
    }
}
