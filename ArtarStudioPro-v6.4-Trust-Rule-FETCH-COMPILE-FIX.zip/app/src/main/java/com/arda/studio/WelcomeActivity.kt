package com.arda.studio

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

/** Branded first page shown before the editor. The artwork is bundled locally/offline. */
class WelcomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val artwork = ImageView(this).apply {
            setImageResource(R.drawable.artar_welcome)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Artar Studio Pro welcome screen"
        }
        root.addView(artwork, FrameLayout.LayoutParams(-1, -1))

        // Transparent hit area positioned over the baked-in “Get Started” button.
        val start = ImageButton(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            contentDescription = "Get Started"
            setOnClickListener {
                startActivity(Intent(this@WelcomeActivity, MainActivity::class.java))
                finish()
            }
        }
        val startLp = FrameLayout.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.62f).toInt(),
            (resources.displayMetrics.heightPixels * 0.075f).toInt().coerceAtLeast(dp(56))
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = (resources.displayMetrics.heightPixels * 0.115f).toInt()
        }
        root.addView(start, startLp)
        setContentView(root)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
