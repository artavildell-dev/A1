package com.arda.studio

import org.junit.Assert.assertTrue
import org.junit.Test

class AiCommandParserTest {
    @Test fun parsesPersianCommands() {
        val r = AiCommandParser.parse("گرم + روشن + کنتراست")
        assertTrue(r.contains(AiCommandParser.Action.WARM))
        assertTrue(r.contains(AiCommandParser.Action.BRIGHTEN))
        assertTrue(r.contains(AiCommandParser.Action.CONTRAST))
    }

    @Test fun parsesEnglishCommands() {
        val r = AiCommandParser.parse("warm + contrast + rotate")
        assertTrue(r.contains(AiCommandParser.Action.WARM))
        assertTrue(r.contains(AiCommandParser.Action.CONTRAST))
        assertTrue(r.contains(AiCommandParser.Action.ROTATE))
    }
}
