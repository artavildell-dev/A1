# Artar Studio Pro v6.4 — Trust Rule / Fetch Fix

This package is an Android Gradle project. It intentionally contains the Persian and English Tesseract models in `app/src/main/assets/tessdata/`, so the GitHub workflow does **not** fetch OCR models from a remote URL.

## Build
GitHub Actions workflow: `.github/workflows/build-android.yml`

The workflow installs Java 17, Android SDK 35 and Gradle 8.11.1, verifies the bundled OCR assets, runs unit tests, then builds debug and unsigned release APKs.

## Trust Rule
Every capability is labelled in the Android UI and documentation as exactly one of:
- `IMPLEMENTED`
- `MODEL-DEPENDENT`
- `PLANNED`

Do not claim `PLANNED` capabilities as working.
