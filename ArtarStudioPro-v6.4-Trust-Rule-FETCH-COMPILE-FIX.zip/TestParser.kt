import com.arda.studio.AiCommandParser
fun main(){
 val a=AiCommandParser.parse("گرم + روشن + کنتراست")
 check(a.contains(AiCommandParser.Action.WARM))
 check(a.contains(AiCommandParser.Action.BRIGHTEN))
 check(a.contains(AiCommandParser.Action.CONTRAST))
 val b=AiCommandParser.parse("warm + contrast + rotate")
 check(b.contains(AiCommandParser.Action.ROTATE))
 println("AI parser tests passed")
}
