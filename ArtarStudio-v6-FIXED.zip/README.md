# Arda Studio Pro v4

این نسخه از حالت دمو خارج شده و هسته قابل استفاده‌تری دارد:

- Canvas با مختصات واقعی تصویر و خروجی در اندازه اصلی
- Text Layer واقعی با جابه‌جایی لمسی و ذخیره پروژه
- Undo/Redo
- Brush / Eraser
- تنظیمات رنگ و Auto Enhance
- OCR لاتین آفلاین با ML Kit Bundled
- OCR فارسی/انگلیسی با Tesseract 5.5.1 و traineddata فارسی/انگلیسی که در GitHub Actions هنگام build به assets اضافه می‌شوند
- Face Detection و Image Labeling روی دستگاه
- فرمان‌های آفلاین فارسی/انگلیسی
- Batch export تا 100 تصویر
- JPG / PNG / PDF
- ذخیره و بازیابی پروژه
- Thermal / Glitch / Edge Sketch / Pixelate / Kaleidoscope / Relight / Vignette / Film Grain / Ghost Exposure
- Color DNA
- حذف سریع پس‌زمینه بر اساس رنگ گوشه‌ها (این ابزار AI عمومی نیست و عمداً با نام دقیق معرفی شده)

## نکته مهم
ML Kit متن فارسی را در Text Recognition v2 پشتیبانی نمی‌کند؛ برای فارسی در این نسخه Tesseract با `fas.traineddata` استفاده شده است. ML Kit برای Latin و مدل‌های اسکریپت‌های مشخص مناسب است.

## قابلیت‌های مرحله بعد
Subject Segmentation واقعی، Object Selection/Tracking، Clone/Healing حرفه‌ای، Mask واقعی غیرمخرب، Curves/Levels، Perspective Warp، Template Engine، Infinite Canvas، Shadow/Reflection Synthesizer و مدل‌های LiteRT سفارشی.
