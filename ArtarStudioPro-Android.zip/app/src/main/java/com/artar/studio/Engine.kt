package com.artar.studio

import android.graphics.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import kotlin.math.*
import kotlin.random.Random

data class Adj(val b: Float = 0f, val c: Float = 1f, val s: Float = 1f, val warm: Float = 0f, val hue: Float = 0f, val sharp: Float = 0f, val fade: Float = 0f)
data class TextL(val t: String, val x: Float, val y: Float, val size: Float, val color: Int)
data class Stroke(val pts: List<Pair<Float, Float>>, val color: Int, val w: Float)
data class Edit(
    val adj: Adj = Adj(), val filter: Int = 0, val fx: Int = -1, val rot: Int = 0, val flip: Boolean = false,
    val crop: Float = 0f, val texts: List<TextL> = emptyList(), val strokes: List<Stroke> = emptyList()
)
class Fx(val name: String, val sub: String, val icon: String, val m: ColorMatrix? = null, val op: String = "")

private fun sat(s: Float) = ColorMatrix().apply { setSaturation(s) }
private fun scl(r: Float, g: Float, b: Float) = ColorMatrix().apply { setScale(r, g, b, 1f) }
private fun con(c: Float, b: Float = 0f) = ColorMatrix(floatArrayOf(
    c, 0f, 0f, 0f, (1 - c) * 128 + b, 0f, c, 0f, 0f, (1 - c) * 128 + b,
    0f, 0f, c, 0f, (1 - c) * 128 + b, 0f, 0f, 0f, 1f, 0f))
private fun cat(vararg m: ColorMatrix) = ColorMatrix().also { r -> m.forEach { r.postConcat(it) } }
private fun hue(d: Float): ColorMatrix {
    val r = Math.toRadians(d.toDouble()); val c = cos(r).toFloat(); val s = sin(r).toFloat()
    return ColorMatrix(floatArrayOf(
        .213f + c * .787f - s * .213f, .715f - c * .715f - s * .715f, .072f - c * .072f + s * .928f, 0f, 0f,
        .213f - c * .213f + s * .143f, .715f + c * .285f + s * .140f, .072f - c * .072f - s * .283f, 0f, 0f,
        .213f - c * .213f - s * .787f, .715f - c * .715f + s * .715f, .072f + c * .928f + s * .072f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f))
}
private val SEPIA = ColorMatrix(floatArrayOf(.393f, .769f, .189f, 0f, 0f, .349f, .686f, .168f, 0f, 0f, .272f, .534f, .131f, 0f, 0f, 0f, 0f, 0f, 1f, 0f))
private val INV = ColorMatrix(floatArrayOf(-1f, 0f, 0f, 0f, 255f, 0f, -1f, 0f, 0f, 255f, 0f, 0f, -1f, 0f, 255f, 0f, 0f, 0f, 1f, 0f))
private fun cl(v: Int) = if (v < 0) 0 else if (v > 255) 255 else v

fun Bitmap.fit(m: Int): Bitmap {
    val k = m.toFloat() / max(width, height)
    return if (k >= 1f) this else Bitmap.createScaledBitmap(this, max(1, (width * k).toInt()), max(1, (height * k).toInt()), true)
}

object Lib {
    val filters: List<Pair<String, ColorMatrix?>> = listOf(
        "طبیعی" to null, "گرم" to cat(sat(1.3f), scl(1.1f, 1f, .88f)), "سرد" to cat(sat(1.1f), scl(.9f, 1f, 1.12f)),
        "سیاه و سفید" to sat(0f), "فیلمی" to cat(con(1.15f), sat(.85f), scl(1.04f, 1f, .95f)),
        "کلاسیک" to cat(SEPIA, con(1.1f)), "آبی" to cat(hue(30f), sat(1.4f)), "طلایی" to cat(sat(1.6f), scl(1.15f, 1.05f, .8f)),
        "درامایی" to cat(con(1.5f), sat(1.2f)), "بارانی" to cat(sat(.7f), con(.95f, -10f), scl(.95f, 1f, 1.05f)),
        "مات" to cat(con(.9f, 15f), sat(.8f)), "شب" to cat(con(1f, -60f), hue(200f), sat(1.3f)))
    val fx = listOf(
        Fx("حرارتی", "نقشه گرمایی", "🔥", cat(hue(180f), sat(2f), con(1.2f))),
        Fx("گلیچ", "اعوجاج رنگی", "📺", cat(hue(300f), sat(2.5f), con(1.2f))),
        Fx("طرح خطی", "Edge Sketch", "✏️", cat(sat(0f), con(3f, 40f))),
        Fx("پیکسلی", "Pixelate", "🔲", op = "px"),
        Fx("کالیدوسکوپ", "تقارن آینه‌ای", "🔮", op = "kal"),
        Fx("نورپردازی", "Relight", "💡", con(1.1f, 30f)),
        Fx("وینیت", "تیره‌کردن لبه‌ها", "⭕", op = "vg"),
        Fx("دانه فیلم", "Film Grain", "🎞️", con(1.1f), "gr"),
        Fx("منفی", "Negative", "🌗", INV),
        Fx("سپیا", "Sepia", "🟤", SEPIA),
        Fx("رنگ DNA", "Color DNA", "🧬", cat(hue(90f), sat(2f))),
        Fx("دورنگ", "Duotone", "🎭", cat(sat(0f), scl(.95f, .5f, 1.2f))),
        Fx("جداسازی RGB", "RGB Split", "🌈", op = "rgb"),
        Fx("VHS", "نوار قدیمی", "📼", cat(sat(1.4f), con(1.1f)), "vhs"))
    val tpl = listOf("پایه", "سینمایی", "فروش", "نقل‌قول", "پوستر", "مینیمال", "پرتره", "فیلم", "نئون", "سیاه و سفید", "محصول", "عروسی", "سفر", "طبیعت")
}

object Engine {
    private val R = floatArrayOf(1f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)
    private val G = floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)
    private val B = floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)

    fun render(src: Bitmap, e: Edit, maxSide: Int = 0): Bitmap {
        var cw = src.width; var ch = src.height; var cx = 0; var cy = 0
        if (e.crop > 0f) {
            val r = e.crop
            if (r > cw.toFloat() / ch) ch = (cw / r).toInt() else cw = (ch * r).toInt()
            cw = max(1, cw); ch = max(1, ch)
            cx = (src.width - cw) / 2; cy = (src.height - ch) / 2
        }
        val m = Matrix()
        if (e.flip) m.postScale(-1f, 1f, cw / 2f, ch / 2f)
        m.postRotate(e.rot.toFloat(), cw / 2f, ch / 2f)
        var part = Bitmap.createBitmap(src, cx, cy, cw, ch, m, true)
        if (maxSide > 0) part = part.fit(maxSide)
        val w = part.width; val h = part.height; val a = e.adj
        val cm = cat(con(a.c, a.b * 1.28f), sat(a.s), hue(a.hue), scl(1f + a.warm / 200f, 1f, 1f - a.warm / 200f), con(1f - a.fade * .004f, a.fade * .5f))
        Lib.filters.getOrNull(e.filter)?.second?.let { cm.postConcat(it) }
        val fx = Lib.fx.getOrNull(e.fx)
        fx?.m?.let { cm.postConcat(it) }
        var out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(part, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(cm) })
        val op = fx?.op ?: ""
        if (op == "kal") {
            val cp = out.copy(Bitmap.Config.ARGB_8888, false)
            c.save(); c.clipRect(0f, 0f, w / 2f, h.toFloat()); c.scale(-1f, 1f, w / 2f, h / 2f); c.drawBitmap(cp, 0f, 0f, null); c.restore()
        }
        if (op == "px") {
            val s = Bitmap.createScaledBitmap(out, max(8, w / 14), max(8, h / 14), true)
            c.drawBitmap(s, null, Rect(0, 0, w, h), Paint().apply { isFilterBitmap = false })
        }
        if (op == "vg") {
            val p = Paint().apply { shader = RadialGradient(w / 2f, h / 2f, max(w, h) * .75f, intArrayOf(0, 0, 0xCC000000.toInt()), floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP) }
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        }
        if (op == "gr") {
            val px = IntArray(w * h); out.getPixels(px, 0, w, 0, 0, w, h); val rnd = Random(7)
            for (i in px.indices) {
                val n = rnd.nextInt(41) - 20; val v = px[i]
                px[i] = (v and 0xFF000000.toInt()) or (cl((v shr 16 and 255) + n) shl 16) or (cl((v shr 8 and 255) + n) shl 8) or cl((v and 255) + n)
            }
            out.setPixels(px, 0, w, 0, 0, w, h)
        }
        if (op == "rgb" || op == "vhs") {
            val cp = out.copy(Bitmap.Config.ARGB_8888, false); val q = max(2f, w / (if (op == "vhs") 140f else 70f))
            c.drawColor(Color.BLACK)
            fun chan(mat: FloatArray, dx: Float) {
                val pa = Paint().apply { colorFilter = ColorMatrixColorFilter(ColorMatrix(mat)); xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD) }
                c.drawBitmap(cp, dx, 0f, pa)
            }
            chan(R, -q); chan(G, 0f); chan(B, q)
            if (op == "vhs") { val lp = Paint().apply { color = 0x44000000 }; var y = 0; while (y < h) { c.drawRect(0f, y.toFloat(), w.toFloat(), y + 1f, lp); y += 3 } }
        }
        if (a.sharp > 0f) out = sharpen(out, a.sharp / 100f)
        val oc = Canvas(out)
        val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        e.strokes.forEach { s ->
            sp.color = s.color; sp.strokeWidth = s.w * w
            val path = Path()
            s.pts.forEachIndexed { i, (x, y) -> if (i == 0) path.moveTo(x * w, y * h) else path.lineTo(x * w, y * h) }
            if (s.pts.size == 1) path.lineTo(s.pts[0].first * w + .1f, s.pts[0].second * h)
            oc.drawPath(path, sp)
        }
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD; setShadowLayer(8f, 0f, 2f, 0x88000000.toInt()) }
        e.texts.forEach { t -> tp.color = t.color; tp.textSize = t.size * w; oc.drawText(t.t, t.x * w, t.y * h, tp) }
        return out
    }

    private fun sharpen(b: Bitmap, k: Float): Bitmap {
        val w = b.width; val h = b.height; val s = IntArray(w * h); b.getPixels(s, 0, w, 0, 0, w, h); val o = s.copyOf()
        fun chn(i: Int, sh: Int) = (s[i] shr sh) and 255
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x; var px = s[i] and 0xFF000000.toInt()
            for (sh in intArrayOf(16, 8, 0)) {
                val v = chn(i, sh) * (1 + 4 * k) - k * (chn(i - 1, sh) + chn(i + 1, sh) + chn(i - w, sh) + chn(i + w, sh))
                px = px or (cl(v.toInt()) shl sh)
            }
            o[i] = px
        }
        val r = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); r.setPixels(o, 0, w, 0, 0, w, h); return r
    }
}

object Sample {
    fun make(): Bitmap {
        val b = Bitmap.createBitmap(1000, 750, Bitmap.Config.ARGB_8888); val c = Canvas(b); val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, 420f, intArrayOf(0xFF3B4A9C.toInt(), 0xFFF2788A.toInt(), 0xFFFFC46B.toInt()), floatArrayOf(0f, .6f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, 1000f, 420f, p); p.shader = null
        p.color = 0xFFFFE9A8.toInt(); c.drawCircle(700f, 320f, 60f, p)
        p.color = 0xFF34406E.toInt()
        c.drawPath(Path().apply { moveTo(0f, 420f); lineTo(175f, 250f); lineTo(300f, 340f); lineTo(500f, 110f); lineTo(650f, 290f); lineTo(810f, 210f); lineTo(1000f, 420f); close() }, p)
        p.color = 0xFF1C3B3A.toInt(); c.drawRect(0f, 390f, 1000f, 430f, p)
        val top = Bitmap.createBitmap(b, 0, 0, 1000, 420)
        c.save(); c.scale(1f, -1f, 0f, 420f); c.drawBitmap(top, 0f, 0f, Paint().apply { alpha = 190 }); c.restore()
        p.color = 0x331F6FB5; c.drawRect(0f, 420f, 1000f, 750f, p)
        return b
    }
}

class EditorVM : ViewModel() {
    var src by mutableStateOf<Bitmap?>(null); private set
    var preview by mutableStateOf<Bitmap?>(null); private set
    var rendered by mutableStateOf<Bitmap?>(null); private set
    var edit by mutableStateOf(Edit()); private set
    var canUndo by mutableStateOf(false); private set
    var canRedo by mutableStateOf(false); private set
    var reqTab by mutableStateOf(-1)
    private var committed = Edit()
    private val undoS = ArrayList<Edit>(); private val redoS = ArrayList<Edit>()
    private var job: Job? = null

    init { setImage(Sample.make()) }

    fun setImage(b: Bitmap, e: Edit = Edit()) {
        src = b; preview = b.fit(1280); edit = e; committed = e
        undoS.clear(); redoS.clear(); flags(); draw()
    }
    private fun flags() { canUndo = undoS.isNotEmpty(); canRedo = redoS.isNotEmpty() }
    private fun draw() {
        val p = preview ?: return; val e = edit; job?.cancel()
        job = viewModelScope.launch(Dispatchers.Default) { val r = Engine.render(p, e); withContext(Dispatchers.Main) { rendered = r } }
    }
    fun live(e: Edit) { edit = e; draw() }
    fun commit() { if (edit != committed) { undoS.add(committed); redoS.clear(); committed = edit; flags() } }
    fun apply(e: Edit) { live(e); commit() }
    fun undo() { if (undoS.isNotEmpty()) { redoS.add(committed); committed = undoS.removeAt(undoS.lastIndex); edit = committed; flags(); draw() } }
    fun redo() { if (redoS.isNotEmpty()) { undoS.add(committed); committed = redoS.removeAt(redoS.lastIndex); edit = committed; flags(); draw() } }
}
