package com.artar.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = getSharedPreferences("artar", MODE_PRIVATE)
        setContent {
            var mode by remember { mutableIntStateOf(prefs.getInt("theme", 0)) }
            ArtarTheme(mode) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    App(mode) { mode = it; prefs.edit().putInt("theme", it).apply() }
                }
            }
        }
    }
}

@Composable
fun App(mode: Int, setMode: (Int) -> Unit) {
    val nav = rememberNavController(); val vm: EditorVM = viewModel(); val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { u -> Store.decode(ctx, u)?.let { vm.setImage(it); nav.navigate("editor") { launchSingleTop = true } } }
    }
    val open = { picker.launch("image/*") }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        NavHost(nav, "welcome") {
            composable("welcome") { Welcome { nav.navigate("home") { popUpTo("welcome") { inclusive = true } } } }
            composable("home") { Home(nav, open) }
            composable("editor") { Editor(nav, vm) }
            composable("filters") { FiltersScreen(nav, vm) }
            composable("effects") { EffectsScreen(nav, vm) }
            composable("tpl") { TemplatesScreen(nav, vm) }
            composable("design") { DesignScreen(nav, vm) }
            composable("ai") { AiScreen(nav, vm) }
            composable("lab") { LabScreen(nav, vm) }
            composable("social") { SocialScreen(nav, vm) }
            composable("projects") { ProjectsScreen(nav, vm) }
            composable("settings") { SettingsScreen(nav, mode, setMode) }
            composable("export") { ExportScreen(nav, vm) }
            composable("about") { AboutScreen(nav) }
        }
    }
}
