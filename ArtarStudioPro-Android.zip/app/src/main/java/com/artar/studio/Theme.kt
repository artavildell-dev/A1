package com.artar.studio

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Brand = Brush.linearGradient(listOf(Color(0xFF22B8FF), Color(0xFF6A5CFF), Color(0xFFC04DFF), Color(0xFFFF4FA3)))

private val Light = lightColorScheme(
    primary = Color(0xFF4F6BFF), secondary = Color(0xFF8A4DFF), background = Color(0xFFF3F1FB),
    surface = Color.White, onBackground = Color(0xFF14122B), onSurface = Color(0xFF14122B),
    surfaceVariant = Color(0xFFE9E6FA), onSurfaceVariant = Color(0xFF716F93)
)
private val Dark = darkColorScheme(
    primary = Color(0xFF6F8DFF), secondary = Color(0xFFB07BFF), background = Color(0xFF07080F),
    surface = Color(0xFF181A2C), onBackground = Color(0xFFF1F2FC), onSurface = Color(0xFFF1F2FC),
    surfaceVariant = Color(0xFF242848), onSurfaceVariant = Color(0xFF9A9CC0)
)

/** mode: 0 = system, 1 = light, 2 = dark */
@Composable
fun ArtarTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
