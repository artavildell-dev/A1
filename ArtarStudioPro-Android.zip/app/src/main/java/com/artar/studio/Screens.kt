package com.artar.studio

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

// ---------- shared components ----------
@Composable fun Chip(t: String, on: Boolean = false, onClick: () -> Unit) {
    val bg = if (on) Modifier.background(Brand) else Modifier.background(MaterialTheme.colorScheme.surfaceVariant)
    Text(t, modifier = Modifier.padding(end = 8.dp).clip(RoundedCornerShape(20.dp)).then(bg).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        color = if (on) Color.White else MaterialTheme.colorScheme.primary, fontSize = 13.sp)
}
@Composable fun IconBtn(t: String, enabled: Boolean = true, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface).clickable(enabled = enabled, onClick = onClick), Alignment.Center) {
        Text(t, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = if (enabled) 1f else .35f))
    }
}
@Composable fun GradBtn(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(18.dp)).background(Brand).clickable(onClick = onClick), Alignment.Center) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold)
    }
}
@Composable fun HRow(content: @Composable RowScope.() -> Unit) = Row(Modifier.horizontalScroll(rememberScrollState()), content = content)
@Composable fun SL(label: String, v: Float, r: ClosedFloatingPointRange<Float>, onV: (Float) -> Unit, done: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(84.dp), fontSize = 13.sp)
        Slider(v, onV, Modifier.weight(1f), valueRange = r, onValueChangeFinished = done)
    }
}
@Composable fun Page(title: String, nav: NavController?, right: @Composable RowScope.() -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(12.dp, 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (nav != null) IconBtn("→") { nav.popBackStack() } else Spacer(Modifier.size(40.dp))
            Text(title, Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), content = right)
        }
        content()
    }
}
@Composable fun RowCard(icon: String, color: Color, title: String, sub: String, badge: String? = null, warn: Boolean = false, onClick: (() -> Unit)? = null) {
    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 3.dp,
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(color), Alignment.Center) { Text(icon, fontSize = 22.sp) }
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            badge?.let {
                Text(it, fontSize = 10.sp, color = if (warn) Color(0xFFE08600) else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 8.dp, vertical = 2.dp))
            }
        }
    }
}
@Composable fun Tile(icon: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 3.dp, modifier = modifier.clickable(onClick = onClick)) {
        Column(Modifier.padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(56.dp).clip(RoundedCornerShape(19.dp)).background(MaterialTheme.colorScheme.surfaceVariant), Alignment.Center) { Text(icon, fontSize = 26.sp) }
            Text(label, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp), textAlign = TextAlign.Center)
        }
    }
}
@Composable fun Thumb(img: ImageBitmap?, label: String, sel: Boolean, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(68.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
            .then(if (sel) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp)) else Modifier)) {
            img?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        }
        Text(label, fontSize = 11.sp, color = if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
@Composable fun ColorRow(sel: Color, onPick: (Color) -> Unit) {
    HRow { listOf(0xFFFF3B6B, 0xFF2F6BFF, 0xFF17B26A, 0xFFFFCF33, 0xFFFFFFFF, 0xFF111111).forEach {
        val c = Color(it)
        Box(Modifier.padding(end = 10.dp).size(30.dp).clip(CircleShape).background(c).border(3.dp, if (sel == c) MaterialTheme.colorScheme.primary else Color.Gray.copy(.4f), CircleShape).clickable { onPick(c) })
    } }
}
@Composable fun rememberThumbs(vm: EditorVM): Pair<List<ImageBitmap>, List<ImageBitmap>> {
    val p = vm.preview
    return remember(p) {
        if (p == null) Pair<List<ImageBitmap>, List<ImageBitmap>>(emptyList(), emptyList()) else {
            val s = p.fit(96)
            Pair(Lib.filters.indices.map { Engine.render(s, Edit(filter = it)).asImageBitmap() }, Lib.fx.indices.map { Engine.render(s, Edit(fx = it)).asImageBitmap() })
        }
    }
}
private fun nrm(o: Offset, sz: IntSize, bm: Bitmap): Pair<Float, Float> {
    val k = min(sz.width / bm.width.toFloat(), sz.height / bm.height.toFloat()); val dw = bm.width * k; val dh = bm.height * k
    return Pair(((o.x - (sz.width - dw) / 2) / dw).coerceIn(0f, 1f), ((o.y - (sz.height - dh) / 2) / dh).coerceIn(0f, 1f))
}

// ---------- welcome ----------
@Composable fun Welcome(onStart: () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        BoxWithConstraints(Modifier.fillMaxSize().background(Color(0xFF04050D))) {
            val r = 1220f / 2555f
            val iw = max(maxWidth.value, maxHeight.value * r).dp; val ih = iw / r
            Box(Modifier.requiredSize(iw, ih).align(Alignment.Center)) {
                Image(painterResource(R.drawable.welcome), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                Box(Modifier.align(Alignment.TopStart).offset(iw * .217f, ih * .844f).size(iw * .564f, ih * .058f).clip(CircleShape).clickable(onClick = onStart))
            }
        }
    }
}

// ---------- home ----------
@Composable fun Home(nav: NavController, open: () -> Unit) {
    val tools = listOf(Triple("🖼️", "ویرایش تصویر", "editor"), Triple("🛠️", "ابزارهای طراحی", "design"), Triple("🤖", "هوش مصنوعی", "ai"),
        Triple("✨", "افکت‌ها", "effects"), Triple("🎨", "فیلترها", "filters"), Triple("📱", "شبکه‌های اجتماعی", "social"),
        Triple("🧪", "آزمایشگاه", "lab"), Triple("🧩", "قالب‌ها", "tpl"), Triple("📁", "پروژه‌ها", "projects"), Triple("⬇️", "خروجی", "export"))
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconBtn("⚙") { nav.navigate("settings") }
                Text("ARTAR STUDIO PRO", Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold)
                IconBtn("ⓘ") { nav.navigate("about") }
            }
            Spacer(Modifier.height(14.dp))
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Brand).padding(20.dp)) {
                Column {
                    Text("ویرایش حرفه‌ای تصویر", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                    Text("ابزارهای قدرتمند، افکت، قالب و هوش مصنوعی آفلاین", color = Color.White.copy(.85f), fontSize = 13.sp, modifier = Modifier.padding(vertical = 6.dp))
                    Box(Modifier.clip(RoundedCornerShape(16.dp)).background(Color.White).clickable(onClick = open).padding(horizontal = 18.dp, vertical = 10.dp)) {
                        Text("🖼 باز کردن تصویر", color = Color(0xFF2A3A8F), fontWeight = FontWeight.Bold)
                    }
                }
            }
            Text("ابزارها", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
            tools.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { (i, l, r) -> Tile(i, l, Modifier.weight(1f)) { nav.navigate(r) } }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        Row(Modifier.padding(14.dp, 0.dp, 14.dp, 10.dp).fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(MaterialTheme.colorScheme.surface).padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
            NavItem("⌂", "خانه") {}; NavItem("🖼", "گالری", open)
            Box(Modifier.size(52.dp).clip(CircleShape).background(Brand).clickable(onClick = open), Alignment.Center) { Text("+", color = Color.White, fontSize = 28.sp) }
            NavItem("📁", "پروژه‌ها") { nav.navigate("projects") }; NavItem("⚙", "تنظیمات") { nav.navigate("settings") }
        }
    }
}
@Composable fun NavItem(i: String, l: String, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick).padding(horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(i, fontSize = 20.sp); Text(l, fontSize = 11.sp) }
}

// ---------- editor ----------
@Composable fun Editor(nav: NavController, vm: EditorVM) {
    var tab by remember { mutableIntStateOf(0) }
    var draw by remember { mutableStateOf(false) }
    var col by remember { mutableStateOf(Color(0xFFFF3B6B)) }
    var bs by remember { mutableFloatStateOf(.012f) }
    var dlg by remember { mutableStateOf(false) }
    var txt by remember { mutableStateOf("زندگی زیبا") }
    LaunchedEffect(vm.reqTab) { if (vm.reqTab >= 0) { tab = vm.reqTab; vm.reqTab = -1 } }
    val e = vm.edit; val a = e.adj; val th = rememberThumbs(vm)
    Page("ویرایش تصویر", nav, right = { IconBtn("↶", vm.canUndo) { vm.undo() }; IconBtn("↷", vm.canRedo) { vm.redo() }; IconBtn("💾") { nav.navigate("export") } }) {
        var sz by remember { mutableStateOf(IntSize.Zero) }
        var cur by remember { mutableStateOf(listOf<Pair<Float, Float>>()) }
        var base by remember { mutableStateOf(listOf<Stroke>()) }
        val bm = vm.rendered; val bmS by rememberUpdatedState(bm)
        Box(Modifier.weight(1f).fillMaxWidth().padding(12.dp), Alignment.Center) {
            if (bm != null) Image(bm.asImageBitmap(), null,
                Modifier.fillMaxSize().onSizeChanged { sz = it }.pointerInput(draw, col, bs) {
                    if (draw) detectDragGestures(
                        onDragStart = { o -> base = vm.edit.strokes; cur = listOf(nrm(o, sz, bmS!!)); vm.live(vm.edit.copy(strokes = base + Stroke(cur, col.toArgb(), bs))) },
                        onDrag = { c, _ -> cur = cur + nrm(c.position, sz, bmS!!); vm.live(vm.edit.copy(strokes = base + Stroke(cur, col.toArgb(), bs))) },
                        onDragEnd = { vm.commit() })
                }, contentScale = ContentScale.Fit)
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp, 26.dp, 0.dp, 0.dp)).background(MaterialTheme.colorScheme.surface).padding(12.dp)) {
            val tabs = listOf("☀️ تنظیمات", "🎨 فیلتر", "✨ افکت", "✂️ برش", "🔤 متن", "🖌️ نقاشی", "🗂️ لایه", "🤖 هوش مصنوعی", "🧩 قالب", "📱 شبکه")
            LazyRow { items(tabs.size) { i -> Chip(tabs[i], tab == i) { tab = i } } }
            Column(Modifier.heightIn(max = 230.dp).verticalScroll(rememberScrollState()).padding(top = 8.dp)) {
                when (tab) {
                    0 -> {
                        SL("روشنایی", a.b, -100f..100f, { vm.live(e.copy(adj = a.copy(b = it))) }) { vm.commit() }
                        SL("کنتراست", a.c, .4f..1.8f, { vm.live(e.copy(adj = a.copy(c = it))) }) { vm.commit() }
                        SL("اشباع", a.s, 0f..2.2f, { vm.live(e.copy(adj = a.copy(s = it))) }) { vm.commit() }
                        SL("دما", a.warm, -50f..50f, { vm.live(e.copy(adj = a.copy(warm = it))) }) { vm.commit() }
                        SL("رنگ‌مایه", a.hue, -90f..90f, { vm.live(e.copy(adj = a.copy(hue = it))) }) { vm.commit() }
                        SL("وضوح", a.sharp, 0f..100f, { vm.live(e.copy(adj = a.copy(sharp = it))) }) { vm.commit() }
                        SL("محوشدگی", a.fade, 0f..60f, { vm.live(e.copy(adj = a.copy(fade = it))) }) { vm.commit() }
                        HRow {
                            Chip("↻ چرخش") { vm.apply(e.copy(rot = (e.rot + 90) % 360)) }
                            Chip("↔ آینه") { vm.apply(e.copy(flip = !e.flip)) }
                            Chip("⚡ خودکار") { vm.apply(e.copy(adj = Adj(8f, 1.12f, 1.18f, 0f, 0f, 25f, 0f))) }
                            Chip("بازنشانی") { vm.apply(e.copy(adj = Adj(), filter = 0, fx = -1)) }
                        }
                    }
                    1 -> LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(Lib.filters.size) { i -> Thumb(th.first.getOrNull(i), Lib.filters[i].first, e.filter == i && e.fx < 0) { vm.apply(e.copy(filter = i, fx = -1)) } }
                    }
                    2 -> LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        item { Thumb(null, "بدون", e.fx < 0) { vm.apply(e.copy(fx = -1)) } }
                        items(Lib.fx.size) { i -> Thumb(th.second.getOrNull(i), Lib.fx[i].name, e.fx == i) { vm.apply(e.copy(fx = i)) } }
                    }
                    3 -> HRow { listOf("اصلی" to 0f, "1:1" to 1f, "4:5" to .8f, "9:16" to .5625f, "16:9" to 1.7778f).forEach { (n, r) -> Chip(n, e.crop == r) { vm.apply(e.copy(crop = r)) } } }
                    4 -> { HRow { Chip("+ افزودن متن") { dlg = true } }; Spacer(Modifier.height(8.dp)); ColorRow(col) { col = it } }
                    5 -> {
                        HRow {
                            Chip(if (draw) "نقاشی: روشن" else "نقاشی: خاموش", draw) { draw = !draw }
                            Chip("حذف آخرین خط") { if (e.strokes.isNotEmpty()) vm.apply(e.copy(strokes = e.strokes.dropLast(1))) }
                            Chip("پاک کردن همه") { vm.apply(e.copy(strokes = emptyList())) }
                        }
                        SL("اندازه", bs, .004f..0.04f, { bs = it }) {}
                        ColorRow(col) { col = it }
                    }
                    6 -> {
                        Text("لایه تصویر اصلی", fontSize = 13.sp)
                        e.texts.forEachIndexed { i, t -> Row(verticalAlignment = Alignment.CenterVertically) { Text("متن: ${t.t}", Modifier.weight(1f)); Chip("حذف") { vm.apply(e.copy(texts = e.texts.filterIndexed { j, _ -> j != i })) } } }
                        Text("لایه نقاشی: ${e.strokes.size} خط", fontSize = 13.sp)
                    }
                    7 -> HRow { Chip("باز کردن ابزارهای هوشمند") { nav.navigate("ai") } }
                    8 -> HRow { Lib.tpl.forEachIndexed { i, n -> Chip(n) { vm.apply(e.copy(filter = i % Lib.filters.size, fx = -1, texts = listOf(TextL(n, .5f, .88f, .09f, android.graphics.Color.WHITE)))) } } }
                    9 -> HRow { Chip("انتخاب اندازه شبکه اجتماعی") { nav.navigate("social") } }
                    else -> {}
                }
            }
        }
    }
    if (dlg) AlertDialog(onDismissRequest = { dlg = false }, title = { Text("متن") },
        confirmButton = { TextButton({ vm.apply(e.copy(texts = e.texts + TextL(txt, .5f, .5f, .09f, col.toArgb()))); dlg = false }) { Text("افزودن") } },
        dismissButton = { TextButton({ dlg = false }) { Text("لغو") } },
        text = { OutlinedTextField(txt, { txt = it }) })
}

// ---------- list / grid screens ----------
@Composable fun ThumbGrid(nav: NavController, title: String, names: List<String>, imgs: List<ImageBitmap>, sel: Int, cta: String, onPick: (Int) -> Unit) {
    Page(title, nav) {
        LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(names.size) { i ->
                Column(Modifier.clickable { onPick(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    imgs.getOrNull(i)?.let { Image(it, null, Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(16.dp))
                        .then(if (sel == i) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp)) else Modifier), contentScale = ContentScale.Crop) }
                    Text(names[i], fontSize = 12.sp)
                }
            }
        }
        GradBtn(cta, Modifier.padding(16.dp)) { nav.navigate("editor") { launchSingleTop = true } }
    }
}
@Composable fun FiltersScreen(nav: NavController, vm: EditorVM) {
    val th = rememberThumbs(vm); val e = vm.edit
    ThumbGrid(nav, "فیلترهای حرفه‌ای", Lib.filters.map { it.first }, th.first, e.filter, "اعمال فیلتر ✓") { vm.apply(e.copy(filter = it, fx = -1)) }
}
@Composable fun EffectsScreen(nav: NavController, vm: EditorVM) {
    val th = rememberThumbs(vm); val e = vm.edit
    ThumbGrid(nav, "افکت‌ها", Lib.fx.map { it.name }, th.second, e.fx, "اعمال افکت ✓") { vm.apply(e.copy(fx = it)) }
}
@Composable fun TemplatesScreen(nav: NavController, vm: EditorVM) {
    val th = rememberThumbs(vm)
    ThumbGrid(nav, "قالب‌ها", Lib.tpl, th.first, -1, "باز کردن در ویرایشگر") { i ->
        vm.apply(vm.edit.copy(filter = i % Lib.filters.size, fx = -1, texts = listOf(TextL(Lib.tpl[i], .5f, .88f, .09f, android.graphics.Color.WHITE))))
    }
}
@Composable fun Scroll(nav: NavController, title: String, content: @Composable ColumnScope.() -> Unit) = Page(title, nav) {
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), content = content)
}
@Composable fun DesignScreen(nav: NavController, vm: EditorVM) = Scroll(nav, "ابزارهای طراحی") {
    val t = listOf(Triple("🖌️", "قلم مو", 5), Triple("🖊️", "مداد", 5), Triple("🧽", "پاک‌کن", 5), Triple("🎯", "فیلتر انتخابی", 1), Triple("🪄", "رنگ‌ها", 5),
        Triple("🗂️", "لایه‌ها", 6), Triple("🧬", "ترکیب", 2), Triple("🔤", "متن", 4), Triple("🧩", "قالب", 8), Triple("✂️", "برش", 3))
    t.chunked(3).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            row.forEach { (i, l, k) -> Tile(i, l, Modifier.weight(1f)) { vm.reqTab = k; nav.navigate("editor") } }
            repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}
@Composable fun AiScreen(nav: NavController, vm: EditorVM) {
    var res by remember { mutableStateOf<String?>(null) }; val bm = vm.preview; val cb: (String) -> Unit = { res = it }
    Scroll(nav, "هوش مصنوعی") {
        Text("ابزارهای «آماده» روی دستگاه و بدون اینترنت اجرا می‌شوند.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp))
        RowCard("🔤", Color(0xFF7C4DFF), "OCR لاتین", "ML Kit — فارسی با Tesseract در نسخه بعد", "آماده") { bm?.let { Ai.ocr(it, cb) } }
        RowCard("🙂", Color(0xFFE0489B), "تشخیص چهره", "ML Kit", "آماده") { bm?.let { Ai.faces(it, cb) } }
        RowCard("🏷️", Color(0xFF17B26A), "برچسب‌گذاری تصویر", "Image Labeling", "آماده") { bm?.let { Ai.labels(it, cb) } }
        RowCard("▦", Color(0xFFFF9F1C), "بارکد و QR", "ML Kit", "آماده") { bm?.let { Ai.barcode(it, cb) } }
        listOf("✂️" to "حذف پس‌زمینه واقعی", "🧽" to "حذف شیء (LaMa)", "🔍" to "ارتقا ×۴ (Real-ESRGAN)", "🙂" to "ترمیم چهره (GFPGAN)", "🪄" to "Generative Fill", "🌫️" to "Deblur / Denoise", "🎨" to "رنگی‌سازی")
            .forEach { (i, n) -> RowCard(i, Color.Gray, n, "نیازمند مدل آفلاین", "نیازمند مدل", true) }
    }
    res?.let { r -> AlertDialog(onDismissRequest = { res = null }, confirmButton = { TextButton({ res = null }) { Text("باشه") } }, text = { Text(r) }) }
}
@Composable fun LabScreen(nav: NavController, vm: EditorVM) {
    var pal by remember { mutableStateOf<List<Int>?>(null) }
    Scroll(nav, "آزمایشگاه ابزارها") {
        RowCard("🎯", Color(0xFF17B26A), "استخراج پالت رنگ", "رنگ‌های غالب تصویر", "آماده") { vm.preview?.let { pal = Ai.palette(it) } }
        listOf(11 to "🎭", 12 to "🌈", 13 to "📼", 4 to "🔮", 3 to "🔲", 0 to "🔥").forEach { (i, ic) ->
            RowCard(ic, Color(0xFF6A5CFF), Lib.fx[i].name, Lib.fx[i].sub, "آماده") { vm.apply(vm.edit.copy(fx = i)); nav.navigate("editor") }
        }
        listOf("🧊" to "بوکه عمق‌دار (MiDaS)", "👆" to "انتخاب هوشمند (MobileSAM)", "🖼️" to "انتقال سبک هنری", "☁️" to "جایگزینی آسمان").forEach { (i, n) -> RowCard(i, Color.Gray, n, "نیازمند مدل آفلاین", "نیازمند مدل", true) }
    }
    pal?.let { p -> AlertDialog(onDismissRequest = { pal = null }, confirmButton = { TextButton({ pal = null }) { Text("باشه") } }, title = { Text("پالت رنگ") },
        text = { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { p.forEach { Box(Modifier.size(38.dp).clip(CircleShape).background(Color(it))) } } }) }
}
class Soc(val n: String, val s: String, val i: String, val c: Color, val r: Float)
@Composable fun SocialScreen(nav: NavController, vm: EditorVM) = Scroll(nav, "شبکه‌های اجتماعی") {
    listOf(Soc("اینستاگرام پست", "1:1 · 1080×1080", "📷", Color(0xFFE0489B), 1f), Soc("اینستاگرام استوری", "9:16 · 1080×1920", "📸", Color(0xFFE0489B), .5625f),
        Soc("ریلز / کاور", "9:16", "🎬", Color(0xFFA43DE0), .5625f), Soc("تیک‌تاک", "9:16", "🎵", Color(0xFF222222), .5625f), Soc("تلگرام", "1:1", "✈️", Color(0xFF2F9BE8), 1f),
        Soc("واتس‌اپ استاتوس", "9:16", "💬", Color(0xFF17B26A), .5625f), Soc("یوتیوب تامنیل", "16:9 · 1280×720", "▶️", Color(0xFFE5322D), 1.7778f),
        Soc("پینترست", "2:3", "📌", Color(0xFFE60023), .6667f), Soc("لینکدین", "1.91:1", "💼", Color(0xFF0A66C2), 1.91f), Soc("پوستر", "4:5", "🖼️", Color(0xFF7C4DFF), .8f))
        .forEach { s -> RowCard(s.i, s.c, s.n, s.s) { vm.apply(vm.edit.copy(crop = s.r)); nav.navigate("editor") { launchSingleTop = true } } }
}
@Composable fun ProjectsScreen(nav: NavController, vm: EditorVM) {
    val ctx = LocalContext.current; var list by remember { mutableStateOf(Store.list(ctx)) }
    Page("پروژه‌ها", nav, right = { IconBtn("＋") { vm.setImage(Sample.make()); nav.navigate("editor") } }) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            GradBtn("💾 ذخیره پروژه فعلی") { Store.save(ctx, vm, "پروژه ${list.size + 1}"); list = Store.list(ctx) }
            Spacer(Modifier.height(8.dp))
            if (list.isEmpty()) Text("هنوز پروژه‌ای ندارید.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            list.forEach { p ->
                RowCard("🖼️", Color(0xFF6A5CFF), p.name, p.date) { Store.load(ctx, p.id)?.let { (b, e) -> vm.setImage(b, e); nav.navigate("editor") } }
                Row(Modifier.fillMaxWidth()) { Chip("حذف") { Store.delete(ctx, p.id); list = Store.list(ctx) } }
            }
        }
    }
}
@Composable fun SettingsScreen(nav: NavController, mode: Int, setMode: (Int) -> Unit) = Scroll(nav, "تنظیمات") {
    Text("ظاهر", fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
    HRow { listOf("سیستم", "روشن", "تاریک").forEachIndexed { i, n -> Chip(n, mode == i) { setMode(i) } } }
    Text("عمومی", fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
    listOf("ذخیره خودکار", "اعلان‌ها", "لرزش لمسی", "خطوط راهنما").forEach { l ->
        var on by remember { mutableStateOf(true) }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(l, Modifier.weight(1f)); Switch(on, { on = it }) }
    }
    Chip("ⓘ درباره برنامه") { nav.navigate("about") }
}
@Composable fun ExportScreen(nav: NavController, vm: EditorVM) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var fmt by remember { mutableStateOf("PNG") }; var q by remember { mutableFloatStateOf(93f) }
    var uri by remember { mutableStateOf<Uri?>(null) }; var busy by remember { mutableStateOf(false) }
    Scroll(nav, "خروجی و ذخیره") {
        vm.rendered?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Fit) }
        Spacer(Modifier.height(10.dp))
        HRow { listOf("PNG", "JPG", "WEBP", "PDF").forEach { Chip(it, fmt == it) { fmt = it } } }
        SL("کیفیت ${q.toInt()}%", q, 40f..100f, { q = it }) {}
        GradBtn(if (busy) "در حال ذخیره…" else "ذخیره ⬇", Modifier.padding(top = 12.dp)) {
            if (!busy) {
                busy = true
                scope.launch(Dispatchers.IO) {
                    val u = try { Store.export(ctx, Engine.render(vm.src!!, vm.edit, 4096), fmt, q.toInt()) } catch (x: Exception) { null }
                    withContext(Dispatchers.Main) { busy = false; uri = u; Toast.makeText(ctx, if (u != null) "ذخیره شد" else "خطا در ذخیره", Toast.LENGTH_SHORT).show() }
                }
            }
        }
        uri?.let { u ->
            Spacer(Modifier.height(10.dp))
            Chip("اشتراک‌گذاری") {
                ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = if (fmt == "PDF") "application/pdf" else "image/*"; putExtra(Intent.EXTRA_STREAM, u); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, null))
            }
        }
    }
}
@Composable fun AboutScreen(nav: NavController) = Scroll(nav, "درباره برنامه") {
    Text("ARTAR STUDIO PRO", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    Text("v7.0 · Photo. Design. Create.", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(16.dp))
    Text("✅ ویرایش حرفه‌ای تصویر\n✅ OCR، چهره، برچسب و بارکد آفلاین\n✅ قالب و شبکه‌های اجتماعی\n✅ پروژه، لایه و تاریخچه\n🧠 هوش مصنوعی تولیدی: نیازمند مدل", lineHeight = 28.sp)
    Spacer(Modifier.height(16.dp))
    Text("Created by Adel · © 2026 Artar Studio", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
}
