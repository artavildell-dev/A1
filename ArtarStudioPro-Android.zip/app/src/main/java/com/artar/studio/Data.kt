package com.artar.studio

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max

class Proj(val id: Long, val name: String) {
    val date: String get() = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(id))
}

object Store {
    fun decode(ctx: Context, uri: Uri): Bitmap? = try {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { d, info, _ ->
            d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = max(info.size.width, info.size.height)
            if (m > 3000) d.setTargetSampleSize(ceil(m / 3000.0).toInt())
        }
    } catch (e: Exception) { null }

    @Suppress("DEPRECATION")
    fun export(ctx: Context, bm: Bitmap, fmt: String, q: Int): Uri? {
        val name = "Artar_${System.currentTimeMillis()}"
        val r = ctx.contentResolver
        if (fmt == "PDF") {
            val d = PdfDocument()
            val pg = d.startPage(PdfDocument.PageInfo.Builder(bm.width, bm.height, 1).create())
            pg.canvas.drawBitmap(bm, 0f, 0f, null); d.finishPage(pg)
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.pdf"); put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Artar")
            }
            val u = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            u?.let { r.openOutputStream(it)?.use { o -> d.writeTo(o) } }
            d.close(); return u
        }
        val (ext, mime, cf) = when (fmt) {
            "JPG" -> Triple("jpg", "image/jpeg", Bitmap.CompressFormat.JPEG)
            "WEBP" -> Triple("webp", "image/webp", if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP)
            else -> Triple("png", "image/png", Bitmap.CompressFormat.PNG)
        }
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "$name.$ext"); put(MediaStore.Images.Media.MIME_TYPE, mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Artar")
        }
        val u = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        u?.let { r.openOutputStream(it)?.use { o -> bm.compress(cf, q, o) } }
        return u
    }

    private fun toJ(e: Edit): JSONObject {
        val a = e.adj
        return JSONObject().put("adj", JSONArray(listOf(a.b, a.c, a.s, a.warm, a.hue, a.sharp, a.fade).map { it.toDouble() }))
            .put("f", e.filter).put("fx", e.fx).put("rot", e.rot).put("flip", e.flip).put("crop", e.crop.toDouble())
            .put("tx", JSONArray(e.texts.map { JSONObject().put("t", it.t).put("x", it.x.toDouble()).put("y", it.y.toDouble()).put("s", it.size.toDouble()).put("c", it.color) }))
    }
    private fun fromJ(j: JSONObject): Edit {
        val x = j.getJSONArray("adj"); val a = List(7) { x.getDouble(it).toFloat() }; val tx = j.getJSONArray("tx")
        return Edit(Adj(a[0], a[1], a[2], a[3], a[4], a[5], a[6]), j.getInt("f"), j.getInt("fx"), j.getInt("rot"), j.getBoolean("flip"), j.getDouble("crop").toFloat(),
            List(tx.length()) { i -> tx.getJSONObject(i).let { TextL(it.getString("t"), it.getDouble("x").toFloat(), it.getDouble("y").toFloat(), it.getDouble("s").toFloat(), it.getInt("c")) } })
    }

    fun save(ctx: Context, vm: EditorVM, name: String) {
        val id = System.currentTimeMillis()
        File(ctx.filesDir, "p_$id.jpg").outputStream().use { vm.src?.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        File(ctx.filesDir, "p_$id.json").writeText(JSONObject().put("name", name).put("edit", toJ(vm.edit)).toString())
    }
    fun list(ctx: Context): List<Proj> = (ctx.filesDir.listFiles { f -> f.name.startsWith("p_") && f.name.endsWith(".json") } ?: emptyArray())
        .mapNotNull { f -> try { Proj(f.name.removePrefix("p_").removeSuffix(".json").toLong(), JSONObject(f.readText()).getString("name")) } catch (e: Exception) { null } }
        .sortedByDescending { it.id }
    fun load(ctx: Context, id: Long): Pair<Bitmap, Edit>? {
        return try {
            val b = BitmapFactory.decodeFile(File(ctx.filesDir, "p_$id.jpg").path) ?: return null
            Pair(b, fromJ(JSONObject(File(ctx.filesDir, "p_$id.json").readText()).getJSONObject("edit")))
        } catch (e: Exception) { null }
    }
    fun delete(ctx: Context, id: Long) { File(ctx.filesDir, "p_$id.jpg").delete(); File(ctx.filesDir, "p_$id.json").delete() }
}

/** On-device AI (ML Kit bundled models, works offline). */
object Ai {
    fun ocr(bm: Bitmap, cb: (String) -> Unit) {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(InputImage.fromBitmap(bm, 0))
            .addOnSuccessListener { cb(it.text.ifBlank { "متنی پیدا نشد" }) }.addOnFailureListener { cb("خطا: ${it.message}") }
    }
    fun faces(bm: Bitmap, cb: (String) -> Unit) {
        FaceDetection.getClient().process(InputImage.fromBitmap(bm, 0))
            .addOnSuccessListener { cb("تعداد چهره: ${it.size}") }.addOnFailureListener { cb("خطا: ${it.message}") }
    }
    fun labels(bm: Bitmap, cb: (String) -> Unit) {
        ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS).process(InputImage.fromBitmap(bm, 0))
            .addOnSuccessListener { l -> cb(if (l.isEmpty()) "برچسبی پیدا نشد" else l.joinToString("\n") { "${it.text}  ${(it.confidence * 100).toInt()}%" }) }
            .addOnFailureListener { cb("خطا: ${it.message}") }
    }
    fun barcode(bm: Bitmap, cb: (String) -> Unit) {
        BarcodeScanning.getClient().process(InputImage.fromBitmap(bm, 0))
            .addOnSuccessListener { l -> cb(if (l.isEmpty()) "بارکدی پیدا نشد" else l.joinToString("\n") { it.rawValue ?: "-" }) }
            .addOnFailureListener { cb("خطا: ${it.message}") }
    }
    fun palette(bm: Bitmap): List<Int> {
        val s = Bitmap.createScaledBitmap(bm, 24, 24, true); val m = HashMap<Int, Int>()
        for (y in 0 until 24) for (x in 0 until 24) {
            val p = s.getPixel(x, y)
            val k = (((p shr 16 and 255) / 48 * 48) shl 16) or (((p shr 8 and 255) / 48 * 48) shl 8) or ((p and 255) / 48 * 48) or 0xFF000000.toInt()
            m[k] = (m[k] ?: 0) + 1
        }
        return m.entries.sortedByDescending { it.value }.take(6).map { it.key }
    }
}
