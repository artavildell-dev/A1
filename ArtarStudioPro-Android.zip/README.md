# Artar Studio Pro (Android · Kotlin · Jetpack Compose)

## Build with GitHub Actions
1. Create a new GitHub repo and push this folder (the `.github/workflows/android.yml` file must be included).
2. Open the **Actions** tab → **Android Build** → wait for the run to finish.
3. Download the artifact **ArtarStudioPro-debug-apk** and install `app-debug.apk` on your phone.

## Build locally
Android Studio (Koala+) → Open this folder → Run. Or: `gradle assembleDebug`

## Notes
- minSdk 29, targetSdk 34, package `com.artar.studio`
- Offline AI: ML Kit (OCR Latin, faces, labels, barcode). Persian OCR needs Tesseract (planned).
- Items marked "نیازمند مدل" in the UI are not implemented yet.
