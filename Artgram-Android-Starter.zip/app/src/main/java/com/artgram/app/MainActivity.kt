package com.artgram.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import fi.iki.elonen.NanoHTTPD

private val bg = Color.rgb(17, 20, 38)
private val panel = Color.rgb(28, 33, 57)
private val purple = Color.rgb(102, 87, 245)
private val mint = Color.rgb(25, 199, 181)
private val white = Color.WHITE
private val muted = Color.rgb(166, 174, 202)

class LocalArtgramServer : NanoHTTPD(8765) {
    override fun serve(session: IHTTPSession): Response {
        val data = JSONObject()
            .put("app", "Artgram")
            .put("status", "local-server-online")
            .put("note", "Prototype API only; no public relay or account service configured")
        return newFixedLengthResponse(Response.Status.OK, "application/json; charset=utf-8", data.toString())
    }
}

class MainActivity : Activity() {
    private var server: LocalArtgramServer? = null
    private lateinit var body: LinearLayout
    private var selected = "Chats"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { server = LocalArtgramServer().also { it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false) } } catch (_: Exception) {}
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float, color: Int = white, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun pad(view: View, all: Int = 16) { view.setPadding(dp(all), dp(all), dp(all), dp(all)) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(panel)
        pad(this, 16)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(dp(0), dp(6), dp(0), dp(6))
        layoutParams = lp
    }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label; isAllCaps = false; setTextColor(white)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple))
            setOnClickListener { onClick() }
        }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(14), dp(18), dp(8))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "✦"; textSize = 30f; setTextColor(mint); gravity = Gravity.CENTER
            setBackgroundColor(purple); setPadding(dp(12), dp(4), dp(12), dp(4))
        }
        header.addView(logo)
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        titles.addView(text("Artgram", 25f, white, true))
        titles.addView(text("Chat freely. Connect securely.", 12f, muted))
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(text("●", 14f, mint, true))
        root.addView(header)

        val search = EditText(this).apply {
            hint = "Search chats, people…"; setHintTextColor(muted); setTextColor(white)
            textSize = 15f; singleLine = true
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(panel)
        }
        val searchLp = LinearLayout.LayoutParams(-1, -2); searchLp.setMargins(0, dp(18), 0, dp(10))
        root.addView(search, searchLp)

        val scroll = ScrollView(this)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        listOf("Chats", "Calls", "Contacts", "Settings").forEach { item ->
            val b = TextView(this).apply {
                text = (if (selected == item) "● " else "") + item
                textSize = 12f; gravity = Gravity.CENTER; setTextColor(if (selected == item) mint else muted)
                setPadding(dp(5), dp(12), dp(5), dp(12))
                setOnClickListener { selected = item; render() }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
        showSection()
    }

    private fun showSection() {
        body.removeAllViews()
        when (selected) {
            "Chats" -> {
                body.addView(text("Your conversations", 20f, white, true))
                body.addView(text("A fresh space for your people.", 13f, muted))
                body.addView(button("＋  Start a chat") {
                    Toast.makeText(this, "Contact discovery will be connected in the next build.", Toast.LENGTH_LONG).show()
                })
                val samples = listOf(
                    Triple("Mina", "Sent a photo ✨", "09:41"),
                    Triple("Design Crew", "You: The new logo looks great", "Yesterday"),
                    Triple("Sam", "Voice message · 0:18", "Mon")
                )
                samples.forEachIndexed { i, item ->
                    val c = card()
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    val avatar = TextView(this).apply {
                        text = listOf("M", "D", "S")[i]; textSize = 19f; setTextColor(white); gravity = Gravity.CENTER
                        setBackgroundColor(listOf(purple, mint, Color.rgb(239, 145, 90))[i])
                        setPadding(dp(13), dp(10), dp(13), dp(10))
                    }
                    row.addView(avatar)
                    val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
                    info.addView(text(item.first, 16f, white, true))
                    info.addView(text(item.second, 13f, muted))
                    row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
                    row.addView(text(item.third, 11f, muted))
                    c.addView(row)
                    c.setOnClickListener {
                        Toast.makeText(this, "Demo conversation — messaging transport is not connected yet.", Toast.LENGTH_LONG).show()
                    }
                    body.addView(c)
                }
                val note = card()
                note.addView(text("Prototype status", 15f, mint, true))
                note.addView(text("The on-device API is ${if (server != null) "running on port 8765" else "not available"}. This build is a UI + local-server starter, not yet a live messaging service.", 13f, muted))
                body.addView(note)
            }
            "Calls" -> {
                body.addView(text("Calls", 22f, white, true))
                body.addView(card().apply {
                    addView(text("Voice & video calling", 17f, white, true))
                    addView(text("Call signaling and real-time media are not connected in this prototype.", 14f, muted))
                })
            }
            "Contacts" -> {
                body.addView(text("People", 22f, white, true))
                body.addView(card().apply {
                    addView(text("Find your people", 17f, white, true))
                    addView(text("Contact sync and account discovery will need a defined pairing / identity system.", 14f, muted))
                })
            }
            else -> {
                body.addView(text("Settings", 22f, white, true))
                body.addView(card().apply {
                    addView(text("Privacy & security", 17f, white, true))
                    addView(text("End-to-end encryption is not yet implemented. Do not use this prototype for private or sensitive messages.", 14f, muted))
                })
                body.addView(card().apply {
                    addView(text("On-device server", 16f, white, true))
                    addView(text("HTTP API: 127.0.0.1:8765 (local prototype endpoint). Not exposed to the internet.", 13f, muted))
                })
                body.addView(button("Check local server") {
                    Toast.makeText(this, if (server != null) "Local API started on port 8765" else "Local API could not start", Toast.LENGTH_LONG).show()
                })
            }
        }
    }

    override fun onDestroy() {
        server?.stop()
        server = null
        super.onDestroy()
    }
}
