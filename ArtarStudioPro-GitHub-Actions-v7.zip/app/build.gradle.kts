plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.arda.studio"; compileSdk = 35
    defaultConfig { applicationId = "com.arda.studio"; minSdk = 23; targetSdk = 35; versionCode = 5; versionName = "5.0" }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:face-detection:16.1.7")
    implementation("com.google.mlkit:image-labeling:17.0.9")
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
    implementation("cz.adaptech.tesseract4android:tesseract4android:4.9.0")
}
