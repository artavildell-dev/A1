package com.arai.offline

/** JNI bridge to the bundled llama.cpp native library. */
class LocalLlm {
    external fun loadModel(path: String): Boolean
    external fun generate(prompt: String): String
    external fun unload()
    companion object { init { System.loadLibrary("arai_native") } }
}
