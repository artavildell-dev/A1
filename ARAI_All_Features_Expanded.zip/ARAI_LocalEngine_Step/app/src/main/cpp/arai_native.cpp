#include <jni.h>
#include <string>
#include <mutex>
#include <vector>
#include <cstring>
#include "llama.h"
static llama_model* g_model = nullptr;
static llama_context* g_ctx = nullptr;
static std::mutex g_mutex;
extern "C" JNIEXPORT jboolean JNICALL
Java_com_arai_offline_LocalLlm_loadModel(JNIEnv* env, jobject, jstring path) {
  std::lock_guard<std::mutex> lock(g_mutex);
  if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
  if (g_model) { llama_model_free(g_model); g_model = nullptr; }
  const char* p = env->GetStringUTFChars(path, nullptr);
  llama_backend_init();
  llama_model_params mp = llama_model_default_params();
  mp.n_gpu_layers = 0;
  g_model = llama_model_load_from_file(p, mp);
  env->ReleaseStringUTFChars(path, p);
  if (!g_model) return JNI_FALSE;
  llama_context_params cp = llama_context_default_params();
  cp.n_ctx = 2048;
  cp.n_batch = 512;
  g_ctx = llama_init_from_model(g_model, cp);
  if (!g_ctx) { llama_model_free(g_model); g_model = nullptr; return JNI_FALSE; }
  return JNI_TRUE;
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_arai_offline_LocalLlm_generate(JNIEnv* env, jobject, jstring prompt) {
  std::lock_guard<std::mutex> lock(g_mutex);
  if (!g_model || !g_ctx) return env->NewStringUTF("ابتدا یک مدل GGUF معتبر را بارگذاری کنید.");
  const char* p = env->GetStringUTFChars(prompt, nullptr);
  const llama_vocab* vocab = llama_model_get_vocab(g_model);
  int n = llama_tokenize(vocab, p, (int)strlen(p), nullptr, 0, true, true);
  if (n < 0) n = -n;
  std::vector<llama_token> tokens(n + 8);
  n = llama_tokenize(vocab, p, (int)strlen(p), tokens.data(), (int)tokens.size(), true, true);
  env->ReleaseStringUTFChars(prompt, p);
  if (n <= 0) return env->NewStringUTF("متن ورودی قابل پردازش نیست.");
  tokens.resize(n);
  llama_memory_clear(llama_get_memory(g_ctx), true);
  llama_batch batch = llama_batch_get_one(tokens.data(), (int)tokens.size());
  if (llama_decode(g_ctx, batch) != 0) return env->NewStringUTF("خطا در پردازش ورودی مدل.");
  std::string out;
  for (int i = 0; i < 256; ++i) {
    auto logits = llama_get_logits_ith(g_ctx, -1);
    auto n_vocab = llama_vocab_n_tokens(vocab);
    llama_token tok = 0; float best = -1e30f;
    for (int j = 0; j < n_vocab; ++j) if (logits[j] > best) { best = logits[j]; tok = j; }
    if (llama_vocab_is_eog(vocab, tok)) break;
    char piece[256]; int len = llama_token_to_piece(vocab, tok, piece, sizeof(piece), 0, true);
    if (len > 0) out.append(piece, len);
    llama_token next = tok;
    batch = llama_batch_get_one(&next, 1);
    if (llama_decode(g_ctx, batch) != 0) break;
  }
  return env->NewStringUTF(out.c_str());
}
extern "C" JNIEXPORT void JNICALL Java_com_arai_offline_LocalLlm_unload(JNIEnv*, jobject) {
  std::lock_guard<std::mutex> lock(g_mutex);
  if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
  if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}
