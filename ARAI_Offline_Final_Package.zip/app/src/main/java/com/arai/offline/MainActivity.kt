package com.arai.offline

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private val bg = Color.rgb(3, 7, 22)
    private val cyan = Color.rgb(0, 220, 255)
    private val purple = Color.rgb(163, 57, 255)
    private val white = Color.rgb(242, 247, 255)
    private lateinit var root: LinearLayout
    private lateinit var messages: LinearLayout
    private lateinit var input: EditText
    private val history = mutableListOf<Pair<String, String>>()

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun shape(stroke: Int = cyan, radius: Int = 18): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(10, 28, 65), Color.rgb(18, 10, 48))).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), stroke)
        }
    private fun label(s: String, size: Float, color: Int = white, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(dp(7), dp(6), dp(7), dp(6))
        }
    private fun btn(s: String, action: () -> Unit) = Button(this).apply {
        text = s; textSize = 15f; isAllCaps = false; setTextColor(white)
        background = shape(purple, 25); setOnClickListener { action() }
    }
    private fun newRoot() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
        setPadding(dp(16), dp(12), dp(16), dp(12))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showSplash()
    }

    private fun showSplash() {
        root = newRoot()
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(label("◉", 64f, cyan, true), LinearLayout.LayoutParams(-1, dp(100)))
        root.addView(label("AR.AI", 46f, white, true))
        root.addView(label("OFFLINE  •  هوش مصنوعی آفلاین", 14f, cyan, true))
        root.addView(label("دستیار هوشمند چندمنظوره", 21f, white, true))
        root.addView(label("گفت‌وگو • کدنویسی • دانش • فایل • تصویر • ترجمه", 13f, Color.LTGRAY))
        val filler = View(this)
        root.addView(filler, LinearLayout.LayoutParams(1, 0, 1f))
        val features = listOf(
            "◈ گفت‌وگو و استدلال" to "⌘ کدنویسی و توسعه",
            "▧ تحلیل تصویر و OCR" to "▤ فایل‌ها و اسناد",
            "文 ترجمه چندزبانه" to "♫ ابزارهای صوتی"
        )
        features.forEach { (a, b) ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            listOf(a, b).forEach { v ->
                row.addView(label(v, 14f, white, true).apply { background = shape() },
                    LinearLayout.LayoutParams(0, dp(66), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
            root.addView(row)
        }
        root.addView(btn("شروع  →") { showChat() }, LinearLayout.LayoutParams(-1, dp(58)).apply {
            setMargins(dp(3), dp(20), dp(3), dp(10))
        })
        root.addView(label("نسخه پایه • مدل زبانی محلی هنوز متصل نشده", 11f, Color.LTGRAY))
        setContentView(root)
    }

    private fun showChat() {
        root = newRoot()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("AR.AI", 25f, cyan, true), LinearLayout.LayoutParams(0, dp(52), 1f))
        top.addView(btn("خانه") { showSplash() })
        root.addView(top)
        root.addView(label("دستیار آفلاین", 17f, white, true))
        val scroller = ScrollView(this)
        messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroller.addView(messages)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        if (history.isEmpty()) {
            addBubble("AR.AI", "سلام! من رابط AR.AI هستم. برای پاسخ‌گویی هوشمند واقعی باید مدل زبانی آفلاین به برنامه متصل شود.")
        } else history.forEach { addBubble(it.first, it.second) }
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tools.addView(btn("افزودن فایل") { chooseFile() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        tools.addView(btn("پاک‌کردن") {
            history.clear(); messages.removeAllViews()
            addBubble("AR.AI", "گفت‌وگو پاک شد.")
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(tools)
        input = EditText(this).apply {
            hint = "پیامت را بنویس…"; setHintTextColor(Color.GRAY); setTextColor(white)
            textSize = 16f; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            background = shape(); setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        root.addView(input, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, dp(8), 0, dp(4)) })
        root.addView(btn("ارسال پیام") { send() }, LinearLayout.LayoutParams(-1, dp(52)))
        setContentView(root)
    }

    private fun addBubble(who: String, body: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = shape(if (who == "شما") purple else cyan)
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        box.addView(label(who, 12f, cyan, true))
        box.addView(label(body, 15f, white))
        messages.addView(box, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, dp(5), 0, dp(5))
        })
    }
    private fun send() {
        val s = input.text.toString().trim()
        if (s.isEmpty()) return
        history.add("شما" to s)
        history.add("AR.AI" to "موتور مدل زبانی هنوز در این بسته نصب و متصل نشده است؛ بنابراین پاسخ تولیدشده توسط هوش مصنوعی در دسترس نیست.")
        showChat()
    }
    private fun chooseFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        startActivityForResult(i, 40)
    }
    @Deprecated("Deprecated in Android API, retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 40 && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            uri?.let {
                history.add("AR.AI" to "فایل انتخاب شد: ${it.lastPathSegment ?: "فایل محلی"}. خواندن و تحلیل محتوا نیازمند افزودن موتور پردازش فایل است.")
                showChat()
            }
        }
    }
}
