# Artar Studio Pro v6.4 — Full Fix / Android

This package is the Android project for GitHub Actions.

## Fixed in this build
- Standard Android layout: fixed top bar + scrolling content + fixed bottom navigation.
- Bottom navigation no longer belongs to the HTML preview and cannot move below the tool grid.
- All home tool cards route to a real action. If an image is required, Gallery opens first and the pending action continues after selection.
- Real local image editing engine in `EditorView`: brightness, contrast, saturation, grayscale, cinematic, warm, cool, auto-enhance, rotate, flip, crop, negative, sepia, pixelate, thermal, edge sketch, glitch, kaleidoscope, relight, vignette, film grain, ghost.
- Text layers, brush, eraser, mask overlay, layers list, templates, social crops, batch processing, PNG/JPG/PDF export, project save/load.
- ML Kit: Latin OCR, face detection, image labeling, barcode/QR scanning.
- Offline Persian/English OCR through Tesseract models bundled inside the Android APK (fas + eng), with GitHub workflow validation.
- Offline command parser for the implemented local operations.
- Quick background cut is deliberately labelled as a fast heuristic operation; it is NOT claimed to be generative AI segmentation.
- Welcome artwork is bundled locally as `artar_welcome.png` and is unchanged from the selected project artwork.

## AI engine in v6.4
- **AI Smart Enhance:** on-device ML Kit image labeling + face detection guide a deterministic enhancement pass. It is real on-device ML assistance, not a generative model.
- **AI Image Analysis:** reports detected faces and top image labels with confidence.
- **OCR:** ML Kit Latin OCR plus offline Tesseract Persian/English.
- **Face detection:** on-device ML Kit.
- **Object/image labels:** on-device ML Kit.
- **Barcode/QR:** on-device ML Kit.
- **Offline command assistant:** pure local parser with Persian/English commands and unit tests.

### AI honesty rule
This version does not pretend to have generative fill, true super-resolution, deblur, colorization, or a generative segmentation model. Those require real models and are not silently represented as working AI.

## GitHub APK build
Workflow: `.github/workflows/build-android.yml`

It installs Android SDK 35/build-tools 35.0.0, Java 17 and Gradle 8.11.1, downloads the OCR models, runs the unit tests, then builds debug and unsigned release APKs and uploads them as an artifact.

- **Real PDF export:** uses Android PdfDocument, writes application/pdf to the public Downloads collection on Android 10+; it does not write a PNG with a .pdf extension.

## Trust Rule / قانون اعتماد
Every capability in Artar Studio Pro must carry exactly one visible status:
- **IMPLEMENTED** — implemented in the Android code and intended to work without an external model beyond normal Android APIs.
- **MODEL-DEPENDENT** — implemented in the Android code but depends on a bundled/runtime ML model or ML Kit/Tesseract engine; availability can depend on model initialization and device/runtime conditions.
- **PLANNED** — not implemented yet; the UI/documentation must not imply that it works.

### Current capability inventory
| Capability | Trust status |
|---|---|
| Brightness / Contrast / Saturation / B&W | IMPLEMENTED |
| Warm / Cool / Cinematic / Auto Enhance | IMPLEMENTED |
| Rotate / Flip / Crop / Social crops | IMPLEMENTED |
| Glitch / Kaleidoscope / Relight / Pixelate / Sketch / Thermal / Vignette / Film Grain / Ghost / Negative / Sepia / Invert | IMPLEMENTED |
| Text / Brush / Eraser / Mask / Layers | IMPLEMENTED |
| Templates / Batch / Save-Load Project | IMPLEMENTED |
| PNG / JPG / PDF export | IMPLEMENTED |
| Offline command parser | IMPLEMENTED |
| OCR Latin (ML Kit) | MODEL-DEPENDENT |
| OCR Persian/English (Tesseract bundled models) | MODEL-DEPENDENT |
| Face detection (ML Kit) | MODEL-DEPENDENT |
| Image labeling (ML Kit) | MODEL-DEPENDENT |
| Barcode / QR (ML Kit) | MODEL-DEPENDENT |
| AI Smart Enhance | MODEL-DEPENDENT |
| AI Image Analysis | MODEL-DEPENDENT |
| Quick background cut (heuristic, non-generative) | IMPLEMENTED |
| Generative Fill | PLANNED |
| True Super Resolution | PLANNED |
| Deblur model | PLANNED |
| Colorization model | PLANNED |
| Generative/model-based background segmentation | PLANNED |

The same status labels are shown on tool cards in the Android UI and in the AI tools screen. Planned capabilities are explicitly listed as PLANNED and are not presented as working AI.
