plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.arda.studio"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.arda.studio"
        minSdk = 26
        targetSdk = 35
        versionCode = 50
        versionName = "5.0"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
