# Arda Studio Pro V5 — GitHub Android

این پروژه نسخه Android رابط Arda Studio Pro است و همان UI نسخه قابل مشاهده را داخل WebView اجرا می‌کند.

## ساخت
1. این پوشه را در Android Studio باز کنید.
2. Gradle Sync را اجرا کنید.
3. `app` را Run کنید.

## نکته
برای ساخت APK به Android SDK و Gradle نیاز است. رابط، دکمه‌ها، انتخاب عکس و انتخاب پروژه در این نسخه آماده است.
